#!/bin/bash
version="V1.0.0.0"
platform="hi3798"

expath=$(pwd)
workpath=$(cd `dirname $0`; pwd)

while [ -n "$1" ]
do
    case $1 in
    -p)
        if [ -z "$2" ]; then
            echo "$0: No Platform specified" >&2
            exit 1
        fi
        platform="$2"
        shift
        ;;

    -v)
        if [ -z "$2" ]; then
            echo "$0: No version specified" >&2
            exit 1
        fi
        version="$2"
        shift
        ;;
    *)
        echo "Unsupport args $1"
        exit 1
        ;;
    esac
    shift
done

maven_project=http://maven.zhkj-rd.cn:3303/repository/releases/com/starnet/cpkgs/Aurora/nmproxy/$platform/$version

pushto=$maven_project/nmproxy
echo "Push to $pushto"
curl -v -u developer:developer --upload-file $expath/build/$platform/nmproxy/nmproxy $pushto

pushto=$maven_project/ChangeLog
echo "Push to $pushto"
curl -v -u developer:developer --upload-file $expath/ChangeLog $pushto

echo "push new tag $platform-$version"
git tag --annotate $platform-$version --message $platform-$version
git push origin --tags
