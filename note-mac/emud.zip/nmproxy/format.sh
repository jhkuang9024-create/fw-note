#!/bin/bash

find ./src -name \*.[ch] | xargs astyle -A8 --indent-switches
