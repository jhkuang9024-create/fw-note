--[[
 FROM      :  tcp加速解析脚本apprexrttv1.lua
 FILE NAME :  emu_relay_server_protocol.lua
 AUTHOR    :  xieyusong
 VERSION   :  0.2
 HISTORY   :  xieyusong     2022/11/14  created
			  xieyusong     2022/02/25  完善解析树，协商中分析到的新端口也转用反向连接解析
 官方文档    :  https://www.wireshark.org/docs/wsdg_html_chunked/ 第十章、第十一章
 参考资料    :  https://blog.csdn.net/quniyade0/article/details/115266774
 参考资料    :  https://blog.csdn.net/Brave_boy666/article/details/118900908
 参考资料    :  https://www.runoob.com/lua/lua-tutorial.html
 TODO      :  Connect ID能否在报文之间关联？就像是HTTP那样在wireshark左边画一条会话的线
 TODO      :  前面解析出的会话包含了承载内容是什么协议，将承载内容继续解析（SSH，HTTP）
 TODO      :  报文信息（Info）栏现在显示的还是TCP的风格，考虑考虑要不要改成协议内容
 TODO      :  查看实际报文的时候发现长度的字段和实际的S_DATARELAY大小完全不一致，不知道为什么
 TODO      :  根据上一条，如果还有内容没有解析，把剩余内容标黄报错提示
--]]
do
	local CONNECTION_TYPE_MAP = { [1] = "TCP", [2] = "UDP", }

	local FIELD_LEN_LEN = 4
	local FIELD_LEN_TYPE = 1
	local FIELD_LEN_IP = 8
	-- 留8字节空位但是只用了后面4字节；这协议没考虑IPv6地址是16字节
	local FIELD_LEN_IP_OFFSET = 4
	local FIELD_LEN_PORT = 4
	local FIELD_LEN_PROTOCOL_TYPE = 1
	local FIELD_LEN_CONNECT_TYPE = 1
	local FIELD_LEN_CONNECT_ID = 8
	local FIELD_LEN_CONNECT_ID1 = 8
	
	local PROTOCOL_TYPE_MAP = {
		[1] = "FTP",
		[2] = "TELNET",
		[3] = "SMTP",
		[4] = "POP3",
		[5] = "HTTP",
		[6] = "DNS",
		[7] = "SNMP",
		[8] = "SSH",
	}
	local seg_c_connect_1 = {
		code = 1,
		name = "C_CONNECT_1",
		-- 函数如果写这里，依赖会变成循环，没法用，写到下面；其他对象一样
		-- parse = function(self, buffer, buffer_len, pinfo, tree)
	}
	local seg_c_connect_2 = { code = 2, name = "C_CONNECT_2", }
	local seg_c_heartbeat = { code = 3, name = "C_HEARTBEAT", }
	local seg_c_datarelay = { code = 4, name = "C_DATARELAY", }
	local seg_c_con_close = { code = 5, name = "C_CON_CLOSE", }
	local seg_s_connect_1_reply = { code = 64, name = "S_CONNECT_1_REPLY", }
	local seg_s_connect_2_reply = { code = 65, name = "S_CONNECT_2_REPLY", }
	local seg_s_connect = { code = 66, name = "S_CONNECT", }
	local seg_s_datarelay = { code = 67, name = "S_DATARELAY", }
	local seg_s_con_close = { code = 68, name = "S_CON_CLOSE", }

	local type_name_map = {
		[seg_c_connect_1.code] = seg_c_connect_1.name,
		[seg_c_connect_2.code] = seg_c_connect_2.name,
		[seg_c_heartbeat.code] = seg_c_heartbeat.name,
		[seg_c_datarelay.code] = seg_c_datarelay.name,
		[seg_c_con_close.code] = seg_c_con_close.name,
		[seg_s_connect_1_reply.code] = seg_s_connect_1_reply.name,
		[seg_s_connect_2_reply.code] = seg_s_connect_2_reply.name,
		[seg_s_connect.code] = seg_s_connect.name,
		[seg_s_datarelay.code] = seg_s_datarelay.name,
		[seg_s_con_close.code] = seg_s_con_close.name,
	}

	local type_map = {
		[seg_c_connect_1.code] = seg_c_connect_1,
		[seg_c_connect_2.code] = seg_c_connect_2,
		[seg_c_heartbeat.code] = seg_c_heartbeat,
		[seg_c_datarelay.code] = seg_c_datarelay,
		[seg_c_con_close.code] = seg_c_con_close,
		[seg_s_connect_1_reply.code] = seg_s_connect_1_reply,
		[seg_s_connect_2_reply.code] = seg_s_connect_2_reply,
		[seg_s_connect.code] = seg_s_connect,
		[seg_s_datarelay.code] = seg_s_datarelay,
		[seg_s_con_close.code] = seg_s_con_close,
	}

	-- 定义自己的协议，name和description，未添加字段
	local relay_proto = Proto("EMU_Relay", "Star-Net EMU Relay server Protocol")

	-- 用来定义分析树里的字段名，参见顶上注释连接，官方文档第十一章ProtoField
	local relay_len = ProtoField.uint32("EMU_Relay.len",
		"Length (raw value)", base.DEC, nil, nil,
		'Rule: "length = (type == C_CONNECT_1 || type == C_HEARTBEAT) ? rawvalue : (rawvalue + 4)"')
	local relay_type = ProtoField.uint8("EMU_Relay.type",
		"Type", base.DEC, type_name_map)

	local relay_connect_ip = ProtoField.ipv4("EMU_Relay.connect_ip",
		"Connect IP", "The IP proxied by client")
	local relay_connect_port = ProtoField.uint8("EMU_Relay.connect_port",
		"Connect Port", base.DEC, nil, nil, "The port proxied by client")
	local relay_open_port = ProtoField.uint8("EMU_Relay.open_port",
		"Open Port", base.DEC, nil, nil, "Server replys port for client to connect")
	local relay_protocol_type = ProtoField.uint8("EMU_Relay.protocol_type",
		"Protocol Type", base.DEC, PROTOCOL_TYPE_MAP, nil, "The application layer protocol proxied by client")
	local relay_connect_type = ProtoField.uint8("EMU_Relay.connect_type",
		"Connect Type", base.DEC, CONNECTION_TYPE_MAP, nil, "The transport layer protocol proxied by client")
	local relay_data = ProtoField.bytes("EMU_Relay.data",
		"Data", base.NONE)
	local relay_connect_key = ProtoField.string("EMU_Relay.connect_key",
		"Connect Key", base.ASCII, 'Connection key from server via "CWMP/TR-069"-like private SOAP protocol')
	local relay_connect_id = ProtoField.uint64("EMU_Relay.connect_id",
		"Connect ID", base.HEX, nil, nil, "Session ID for port No.1")
	local relay_connect_id1 = ProtoField.uint64("EMU_Relay.connect_id1",
		"Connect ID1", base.HEX, nil, nil, "Session ID for port No.2")

	-- 上述字段加入协议
	relay_proto.fields = {relay_len, relay_type, relay_connect_key,
		relay_connect_ip, relay_connect_port, relay_protocol_type, relay_connect_type,
		relay_open_port,
		relay_connect_id, relay_connect_id1,
		relay_data}

	-- parse函数
	function seg_c_connect_1.parse(self, buffer, buffer_len, pinfo, tree)
		-- print("seg_c_connect_1 parse", self, buffer, buffer_len, pinfo, tree, "\n")
		tree:add(relay_connect_key, buffer)
	end

	function seg_c_connect_2.parse(self, buffer, buffer_len, pinfo, tree)
		local pos = 0

		tree:add(relay_connect_ip, buffer(pos + FIELD_LEN_IP_OFFSET, FIELD_LEN_IP - FIELD_LEN_IP_OFFSET))
		pos = pos + FIELD_LEN_IP
		tree:add(relay_connect_port, buffer(pos, FIELD_LEN_PORT))
		pos = pos + FIELD_LEN_PORT
		tree:add(relay_protocol_type, buffer(pos, FIELD_LEN_PROTOCOL_TYPE))
		pos = pos + FIELD_LEN_PROTOCOL_TYPE
		tree:add(relay_connect_type, buffer(pos, FIELD_LEN_CONNECT_TYPE))
		pos = pos + FIELD_LEN_CONNECT_TYPE
	end

	function seg_c_heartbeat.parse(self, buffer, buffer_len, pinfo, tree)
		return
	end

	function seg_c_datarelay.parse(self, buffer, buffer_len, pinfo, tree)
		local pos = 0

		tree:add(relay_connect_id, buffer(pos, FIELD_LEN_CONNECT_ID))
		pos = pos + FIELD_LEN_CONNECT_ID
		tree:add(relay_connect_id1, buffer(pos, FIELD_LEN_CONNECT_ID1))
		pos = pos + FIELD_LEN_CONNECT_ID1
		tree:add(relay_data, buffer(pos))
	end

	function seg_c_con_close.parse(self, buffer, buffer_len, pinfo, tree)
		local pos = 0

		tree:add(relay_connect_id, buffer(pos, FIELD_LEN_CONNECT_ID))
		pos = pos + FIELD_LEN_CONNECT_ID
		tree:add(relay_connect_id1, buffer(pos, FIELD_LEN_CONNECT_ID1))
		pos = pos + FIELD_LEN_CONNECT_ID1
	end

	function seg_s_connect_1_reply.parse(self, buffer, buffer_len, pinfo, tree)
		tree:add(relay_open_port, buffer)

		-- 解析到的新的交互端口也改为用本协议解析
		DissectorTable.get("tcp.port"):add(buffer(0, FIELD_LEN_PORT):uint(), relay_proto)
	end

	function seg_s_connect_2_reply.parse(self, buffer, buffer_len, pinfo, tree)
		tree:add(relay_open_port, buffer)

		-- 解析到的新的交互端口也改为用本协议解析；但好像实际没用上这个端口
		DissectorTable.get("tcp.port"):add(buffer(0, FIELD_LEN_PORT):uint(), relay_proto)
	end

	function seg_s_connect.parse(self, buffer, buffer_len, pinfo, tree)
		local pos = 0

		tree:add(relay_connect_id, buffer(pos, FIELD_LEN_CONNECT_ID))
		pos = pos + FIELD_LEN_CONNECT_ID
		tree:add(relay_connect_id1, buffer(pos, FIELD_LEN_CONNECT_ID1))
		pos = pos + FIELD_LEN_CONNECT_ID1
		tree:add(relay_connect_ip, buffer(pos + FIELD_LEN_IP_OFFSET, FIELD_LEN_IP - FIELD_LEN_IP_OFFSET))
		pos = pos + FIELD_LEN_IP
		tree:add(relay_connect_port, buffer(pos, FIELD_LEN_PORT))
		pos = pos + FIELD_LEN_PORT
		tree:add(relay_connect_type, buffer(pos, FIELD_LEN_CONNECT_TYPE))
		pos = pos + FIELD_LEN_CONNECT_TYPE
	end

	function seg_s_datarelay.parse(self, buffer, buffer_len, pinfo, tree)
		local pos = 0

		tree:add(relay_connect_id, buffer(pos, FIELD_LEN_CONNECT_ID))
		pos = pos + FIELD_LEN_CONNECT_ID
		tree:add(relay_connect_id1, buffer(pos, FIELD_LEN_CONNECT_ID1))
		pos = pos + FIELD_LEN_CONNECT_ID1
		tree:add(relay_data, buffer(pos))
	end

	function seg_s_con_close.parse(self, buffer, buffer_len, pinfo, tree)
		local pos = 0

		tree:add(relay_connect_id, buffer(pos, FIELD_LEN_CONNECT_ID))
		pos = pos + FIELD_LEN_CONNECT_ID
		tree:add(relay_connect_id1, buffer(pos, FIELD_LEN_CONNECT_ID1))
		pos = pos + FIELD_LEN_CONNECT_ID1
	end

	-- 解析封装的内部内容
	dis_tcp = Dissector.get("tcp")
	dis_data = Dissector.get("data")

	-- 每点击一次报文条目进到这个函数里
	-- buffer：包的数据
	-- pinfo: 显示的信息
	-- tree：包结构的关系
	function relay_proto.dissector(buffer, pinfo, tree)
		-- print("relay_proto.dissector", buffer, pinfo, tree, "\n")
		local len = buffer:len()
		local pos = 0
		
		-- 设置在报文列表protocol列的名字
		pinfo.cols.protocol = relay_proto.name
		-- pinfo.cols.protocol:set(relay_proto.name)

		if len >= 5 then
			-- 设置报文数据下拉列表里的协议树这一行名字
			local relay_tree = tree:add(relay_proto, buffer(pos, len))

			local msglenbuf = buffer(pos, FIELD_LEN_LEN)
			pos = pos + FIELD_LEN_LEN

			local typebuf = buffer(pos, FIELD_LEN_TYPE)
			pos = pos + FIELD_LEN_TYPE

			if type_name_map[typebuf:uint()] == nil or msglenbuf:uint() > len then
				pinfo.cols.protocol:append(" Fragment")
				relay_tree:append_text(" Fragment")

				-- 放弃自己解析，用其他解析器
				-- dis_data:call(buffer, pinfo, tree)
				relay_tree:add(relay_data, buffer(0))
				return
			end

			-- type和length一起分析：因为C_CONNECT_1, C_HEARTBEAT的长度都算上开头
			-- length 4个字节，但是C_CONNECT_2, S_CONNECT_1_R, S_CONNECT_2_R,
			-- C_DATARELAY, S_DATARELAY, C_CON_CLOSE, S_CON_CLOSE, S_CONNECT都不含
			local msglen = msglenbuf:int()
			if typebuf:uint() ~= seg_c_connect_1.code and typebuf:uint() ~= seg_c_heartbeat.code then
				msglen = msglen + FIELD_LEN_LEN
			end

			-- relay_tree 协议这一行加字
			-- concat: StringA .. StringB
			relay_tree:append_text(", Type: "..type_name_map[typebuf:uint()])
			relay_tree:append_text(", Len: "..len.." bytes")

			-- 协议加字段（叶子节点），叶子节点也可以继续附加文字
			-- local relay_tree_len = relay_tree:add(relay_len, msglenbuf:int()) 和下面等效
			relay_tree:add(relay_len, msglenbuf):append_text(" ("..msglen.." bytes)")
			relay_tree:add(relay_type, typebuf)

			type_map[typebuf:uint()]:parse(buffer(pos), len - FIELD_LEN_LEN - FIELD_LEN_TYPE, pinfo, relay_tree)
		else
			-- 放弃自己解析，用其他解析器
			dis_data:call(buffer, pinfo, tree)
			-- concat: StringA .. StringB
			pinfo.cols.protocol:prepend(relay_proto.name .. " Fragment")
			return
		end

	end

	-- EMU协议里端口可变，需要手工指定端口；添加后可以decode as设置报文解析协议
	local tcp_encap_table = DissectorTable.get("tcp.port") --如果获取tcp就是tcp.port
	tcp_encap_table:add(19100, relay_proto)
end
