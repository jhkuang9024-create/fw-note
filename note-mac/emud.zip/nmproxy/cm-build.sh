#!/bin/bash

if [ $# == 0 ] ; then
echo "USAGE: $0 [platform] [-g] [-Dxxx=xxx] ..."
echo " e.g.: $0 android"
exit 1;
fi

project=`dirname $0`

function check_compile_result {
    if [ $? -eq 0 ]; then
        echo "$1 compile succeed"
    else
        echo "$1 compile failed"
        exit 1;
    fi
}

function build_platform {
    cm-build -s git@git.zhkj-rd.cn:stclib/runtime.git -b develop -j -i -p $@
    check_compile_result runtime_master

    cm-build -s .                                      -j -i -p $@
    check_compile_result $project
}

build_platform $@
