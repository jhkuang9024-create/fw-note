#include <sys/time.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <netdb.h>
#include <ctype.h>
#include <sys/stat.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <inttypes.h>

#ifndef VSUREOS
#include "nmproxy_build_info.h"
#endif
#include "proxy.h"
//#include <st_log.h>

#define HTTP_PORT 80
#define NAT_SERVER_TIMEOUT 20

pthread_mutex_t __mallocMutex;
pthread_mutexattr_t __mallocMutexAttr;

pthread_mutex_t localSocketListMutex;
pthread_mutexattr_t localSocketListMutexAttr;

sProxyConfig proxyConfig;
sLocalSocket *localSocketListHead = NULL;
int32_t localSocketListNum = 0;
int32_t remoteFd1 = -1;
int32_t remoteFd2 = -1;
fd_set remoteFds, localFds;
bool allowToPrint = TRUE;	// 由于errno 32等错误可以能一直打印，
// 所以在这里做出打印限制

/* ============================================== */
typedef struct _node {
    void* addr;
    uint32_t size;
    struct _node * next;
} Node;

Node *listHead = NULL;
Node *listTail = NULL;
#ifdef LIST_PRINT
static uint32_t listLen = 0;
#endif

void __mallocListAdd(void* addr, uint32_t size)
{
#ifdef LIST_PRINT
    Node * p = (Node *)malloc(sizeof(Node));

    NM_INFO("enter\n");

    p->addr = addr;
    p->size = size;
    p->next = NULL;

    if(listHead == NULL) {
        listHead = p;
        listTail = p;
    } else {
        listTail->next = p;
        listTail = listTail->next;
    }

    listLen ++;
    NM_DEBUG("listLen is %d\n", listLen);

    NM_INFO("current list len is %d, leave\n", listLen);
#endif
}

void __mallocListDel(void* addr)
{
#ifdef LIST_PRINT
    Node * p = NULL, *found = NULL;
    bool find = FALSE;
    uint32_t i = 0;
    NM_INFO("enter\n");

    for(p = listHead; p != NULL; p = p->next, i++) {
        NM_INFO("i=%d\n", i);
        if(listHead == listTail) {
            if(p->addr == addr) {
                listHead = NULL;
                listTail = NULL;
                free(p);
                p = NULL;
                find = TRUE;
                break;
            }
        } else if(listHead->addr == addr) {
            found = listHead;
            listHead = listHead->next;
            free(found);
            found = NULL;
            find = TRUE;
            break;
        } else if(p->next->addr == addr) {
            if(p->next == listTail) {
                free(p->next);
                p->next = NULL;
                listTail = p;
            } else {
                found = p->next;
                p->next = found->next;
                free(found);
                found = NULL;
            }
            find = TRUE;
            break;
        }
    }

    if(find) {
        listLen --;
        NM_DEBUG("listLen is %d\n", listLen);
        NM_DEBUG("find addr %p\n", addr);
    } else {
        NM_DEBUG("not find addr %p\n", addr);
    }

    NM_INFO("leave\n");
#endif
}

void __mallocListPrint(void)
{
#ifdef LIST_PRINT
    Node *p = listHead;
    uint32_t num = 0;

    NM_ERROR("\nmalloc info[%d]:\n", listLen);

    if(listHead) {
        NM_ERROR("    %p(%u)", listHead->addr, listHead->size);
        p = listHead->next;
        num ++;
    }
    for(; p != NULL; p = p->next) {
        NM_ERROR(" -> %p(%u)", p->addr, p->size);
        num ++;
        if(num % 5 == 0) {
            NM_ERROR("\n");
        }
    }
    NM_ERROR("\n\nmalloc num %d, socket num %d\n", num, localSocketListNum);
    NM_ERROR("\n\n");
#endif
}

static void __dataPrint(void *start, uint32_t len)
{
#ifdef DATA_PRINT
    int i = 0;
    char buf[128] = {};
    int buflen = 0;

    NM_ERROR("\n");
    NM_ERROR("-----------------------------------------------------------\n");
    for(i = 0; i < len; i++) {
        if(i % 16 == 0) {
            if(i == 0) {
                buflen += snprintf(buf + buflen, sizeof(buf) - buflen, "0x%#4.4x", i);
            } else {
                buflen += snprintf(buf + buflen, sizeof(buf) - buflen, "%#4.4x", i);
            }
        }
        if(i % 8 == 0) {
            buflen += snprintf(buf + buflen, sizeof(buf) - buflen, "   ");
        } else {
            buflen += snprintf(buf + buflen, sizeof(buf) - buflen, " ");
        }

        buflen += snprintf(buf + buflen, sizeof(buf) - buflen, "%2.2x", ((unsigned char *)start)[i]);
        if(i % 16 == 15) {
            buflen += snprintf(buf + buflen, sizeof(buf) - buflen, "\n");
            NM_ERROR("%s", buf);
            memset(buf, 0, sizeof(buf));
            buflen = 0;
        }
    }
    // last line
    if (len % 16 != 15) {
        NM_ERROR("%s\n", buf);
    }
    NM_ERROR("-----------------------------------------------------------\n");
    NM_ERROR("\n");
#endif
}

static void __dataAction(uint8_t dataType)
{
    NM_WARN("---------------\n");
    switch(dataType) {
        case C_CONNECT_1:
            NM_WARN("send C_CONNECT_1 to remote\n");
            break;
        case C_CONNECT_2:
            NM_WARN("send C_CONNECT_2 to remote\n");
            break;
        case C_HEARTBEAT:
            NM_WARN("send C_HEARTBEAT to remote\n");
            break;
        case C_DATARELAY:
            NM_WARN("send C_DATARELAY to remote\n");
            break;
        case C_CON_CLOSE:
            NM_WARN("send C_CON_CLOSE to remote\n");
            break;
        case S_CONNECT_1_R:
            NM_WARN("receive S_CONNECT_1_R from remote\n");
            break;
        case S_CONNECT_2_R:
            NM_WARN("receive S_CONNECT_2_R from remote\n");
            break;
        case S_CONNECT:
            NM_WARN("receive S_CONNECT from remote\n");
            break;
        case S_DATARELAY:
            NM_WARN("receive S_DATARELAY from remote\n");
            break;
        case S_CON_CLOSE:
            NM_WARN("receive S_CON_CLOSE from remote\n");
            break;
        default:
            break;
    }
}

void __proxyMemcpy(void *dst, const void *src, uint32_t size)
{
    if(src == NULL || dst == NULL) {
        return;
    }

    memcpy(dst, src, size);
}

void  *__proxyMalloc(uint32_t size)
{
    void *ptr = NULL;

    //NM_INFO("enter\n");

    LOCK_MALLOC(__mallocMutex);
    ptr = malloc(size);
    UNLOCK_MALLOC(__mallocMutex);

    if(ptr != NULL) {
        memset(ptr, 0, size);
        __mallocListAdd(ptr, size);
        NM_DEBUG("malloc %p(%u)\n", ptr, size);
    }

    //NM_INFO("leave\n");
    return ptr;
}

void  __proxyFree(void **ptr)
{
    //NM_INFO("enter\n");
    if(ptr != NULL && *ptr != NULL) {
        __mallocListDel(*ptr);
        LOCK_MALLOC(__mallocMutex);
        NM_DEBUG("free %p\n", *ptr);
        free(*ptr);
        UNLOCK_MALLOC(__mallocMutex);
        *ptr = NULL;
    }
    //NM_INFO("leave\n");
}

int32_t __proxySend(int32_t fd, const void *buf, uint32_t len, int32_t flags)
{
    if(buf == NULL || len < 0) {
        NM_ERROR("content error\n");
        return -1;
    }

    return	send(fd, buf, len, flags);
}

int32_t __proxyRead(int32_t fd, void *buf, int32_t len)
{
    void *pRemain = NULL;
    int32_t rc = 0;
    uint32_t recvLen = 0;

    if(buf == NULL) {
        NM_ERROR("buf is NULL\n");
        return recvLen;
    }

    if(fd < 0) {
        NM_ERROR("fd %d, error\n", fd);
        return recvLen;
    }

    if(len < 0) {
        NM_ERROR("length should be bigger than 0\n");
        return recvLen;
    }

    for(recvLen = 0, pRemain = buf; len - recvLen > 0; pRemain += rc) {
        rc = read(fd, pRemain, len - recvLen);
        recvLen += rc;
        if(rc == 0) {
            if(allowToPrint) {
                allowToPrint = FALSE;
                NM_ERROR("broken connection, errno %d,%s\n", errno, strerror(errno));
            }
            return -1;
        } else if (rc > 0 && (errno == EINTR || rc != (len - recvLen))) {
            continue;
        } else if(rc < 0) {
            if(allowToPrint) {
                allowToPrint = FALSE;
                NM_ERROR("bad read, rc %d, errno %d,%s\n", rc, errno, strerror(errno));
            }
            return -1;
        }
    }

    return recvLen;
}

void __mutexInit(void)
{
    pthread_mutexattr_init(&__mallocMutexAttr);
    pthread_mutexattr_settype(&__mallocMutexAttr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&__mallocMutex, &__mallocMutexAttr);

    pthread_mutexattr_init(&localSocketListMutexAttr);
    pthread_mutexattr_settype(&localSocketListMutexAttr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&localSocketListMutex, &localSocketListMutexAttr);
}

uint64_t htonll(uint64_t val)
{
    return (((uint64_t) htonl(val)) << 32) + htonl(val >> 32);
}

uint64_t ntohll(uint64_t val)
{
    return (((uint64_t) ntohl(val)) << 32) + ntohl(val >> 32);
}


static void __heartBeat()
{
    NM_INFO("enter\n");

    __mallocListPrint();
    sendToRemote(remoteFd1, C_HEARTBEAT, NULL, 0, 0, 0);
    localSocketListPrint();

    NM_INFO("leave\n");
}

void proxyInit(void)
{
    NM_INFO("enter\n");

    __mutexInit();

    /* 创建线程用于接收本地web服务的回复报文，并发送给远端 */
    threadInit();

    remoteFdInit();

    sendToRemote(remoteFd1, C_CONNECT_1, proxyConfig.connectKey,
                 strlen(proxyConfig.connectKey), 0, 0);

    /* 初始化心跳相关定时器 */
    //heartBeatInit();
    __heartBeat();

    NM_INFO("leave\n");
}

void proxyProcess(void)
{
    int32_t ret;
    struct timeval tv;

    NM_INFO("enter\n");

    if (remoteFd1 == -1 || remoteFd2 == -1) {
        NM_WARN("remoteFd1=%d, remoteFd2=%d\n", remoteFd1, remoteFd2);
    }

    /* 监听socket，接收到报文进行转发 */
    while(1) {
        FD_ZERO(&remoteFds);
        FD_SET(remoteFd1, &remoteFds);

        tv.tv_sec = REMOTE_FD_SEL_TIMEOUT;
        tv.tv_usec = 0;

        if((ret = select(FD_SETSIZE, &remoteFds, NULL, NULL, &tv)) <= 0) {
            continue;
        }

        NM_DEBUG("select return %d\n", ret);

        if(FD_ISSET(remoteFd1, &remoteFds)) {
            recvFromRemote(remoteFd1);
        } else if(FD_ISSET(remoteFd2, &remoteFds)) {
            recvFromRemote(remoteFd2);
        }
    }

    NM_INFO("leave\n");
}

void proxyExit(void)
{
    NM_INFO("enter\n");

    NM_ERROR("process exit\n");

    NM_INFO("leave\n");
}

bool waitForData(int32_t fd, uint32_t timeOut)
{
    struct timeval tv;
    fd_set readFds;
    int32_t ret = 0;

    NM_INFO("enter\n");

    FD_ZERO(&readFds);
    FD_SET(fd, &readFds);

    tv.tv_sec = timeOut;
    tv.tv_usec = 0;

    if((ret = select(fd+1, &readFds, NULL, NULL, &tv)) > 0) {
        if(FD_ISSET(fd, &readFds)) {
            NM_DEBUG("ret is %d, receive from local fd %d success, leave\n", ret, fd);
            return TRUE;
        }
    }

    NM_DEBUG("ret is %d, receive from fd %d failed, leave\n", ret, fd);

    NM_INFO("leave\n");
    return FALSE;
}

uint16_t recvRemoteHeader(int32_t fd, void **headerMallocN)
{
    void *pData = NULL;
    uint16_t ret = HEAD_ERR;
    int32_t rc = 0;
    uint8_t dataType = 0;
    void *headerWithoutIdMallocC = NULL;
    // uint32_t remainLen = 0;
    // void *pRemain = NULL;

    NM_INFO("enter\n");

    if((headerWithoutIdMallocC = __proxyMalloc(HEADER_WITHOUT_ID_LEN)) == NULL) {
        NM_ERROR("header malloc error\n");
        goto TAG_OUT;
    }

    /* 先读取dataLen和dataType，判断是该类型报文否带有id */
    rc = __proxyRead(fd, headerWithoutIdMallocC, HEADER_WITHOUT_ID_LEN);
    if(rc <= 0) {
        ret = HEAD_ERR;
        goto TAG_OUT;
    }

    pData = headerWithoutIdMallocC + HEADER_LEN_LEN;
    __proxyMemcpy(&dataType, pData, sizeof(uint8_t));
    __dataPrint(headerWithoutIdMallocC, HEADER_LEN_LEN);

    /* 对携带id的报文重新分配空间，获取报文头的内容
    	对不携带id的报文就直接返回之前获得的值 */
    NM_DEBUG("dataType is %d\n", dataType);
    switch(dataType) {
        case S_CONNECT:
        case S_DATARELAY:
        case S_CON_CLOSE:
            if((*headerMallocN = __proxyMalloc(HEADER_WITH_ID_LEN)) == NULL) {
                NM_ERROR("header malloc error\n");
                goto TAG_OUT;
            }

            pData = *headerMallocN;
            __proxyMemcpy(pData, headerWithoutIdMallocC, HEADER_WITHOUT_ID_LEN);
            __proxyFree(&headerWithoutIdMallocC);
            pData += HEADER_WITHOUT_ID_LEN;
            rc = __proxyRead(fd, pData, HEADER_ID_LEN);
            if(rc <= 0) {
                ret = HEAD_ERR;
                goto TAG_OUT;
            }

            ret = HEAD_WITH_ID;
            break;
        case S_CONNECT_1_R:
        case S_CONNECT_2_R:
            *headerMallocN = headerWithoutIdMallocC;
            ret = HEAD_WITHOUT_ID;

            break;
        default:
            ret = HEAD_UNKNOWN;
            NM_ERROR("dataType %d(0x%X) is unknown\n", dataType, dataType);
            break;
    }

TAG_OUT:
    if(ret == HEAD_ERR || ret == HEAD_UNKNOWN) {
        __proxyFree(&headerWithoutIdMallocC);
    }

    NM_INFO("leave\n");
    return ret;
}

bool recvRemoteContent(int32_t fd, void *pData, uint32_t contentLen)
{
    uint32_t readDataLen = 0;
    int32_t remainDataLen = contentLen;
    int32_t rc = 0;

    NM_INFO("enter\n");

    while(readDataLen < remainDataLen) {
        rc = __proxyRead(fd, pData, remainDataLen);

        if(rc < 0) {
            NM_ERROR("read %d, remain %d\n", readDataLen, remainDataLen);
            return FALSE;
        } else if(rc == 0) {
            if(!waitForData(fd, REMOTE_FD_SEL_TIMEOUT)) {
                NM_ERROR("receive remote data timeout, readDataLen %d, remainDataLen %d\n",
                         readDataLen, remainDataLen);
                return FALSE;
            }
        } else {
            pData += rc;
            readDataLen += rc;
            remainDataLen -= rc;

            NM_DEBUG("reading segment: read %d, remain %d\n", readDataLen, remainDataLen);
        }
    }

    NM_INFO("leave\n");
    return TRUE;
}

/* 读取从remote发来的数据，这里统一头部格式：
	头部长度+消息类型+ID
	若不携带ID，则填充0 */
uint32_t recvRemoteData(int32_t fd, void **bufMallocN)
{
    bool ret = FALSE;
    void *headerMalloc = NULL;
    void *dataMallocN = NULL;
    void *pData = NULL;
    // int32_t rc = 0;
    uint32_t dataLen = 0;
    uint32_t contentLen = 0;
    uint32_t headerLen = 0;
    uint64_t id1st = 0;
    uint64_t id2nd = 0;
    uint8_t dataType = 0;
    uint16_t headerType = HEAD_ERR;
    void *pDest = NULL, *pSrc = NULL;

    NM_INFO("enter\n");

    if(fd <= 0) {
        NM_ERROR("fd error\n");
        goto TAG_OUT;
    }

    if(bufMallocN == NULL) {
        NM_ERROR("bufMallocN is NULL\n");
        goto TAG_OUT;
    }

    /* 首先获取头部信息，方便后续分配接收空间 */
    headerType = recvRemoteHeader(fd, &headerMalloc);

    if(headerType == HEAD_UNKNOWN) {
        NM_ERROR("headerType is unknown\n");
        goto TAG_OUT;
    }

    if(headerType == HEAD_ERR) {
        if(allowToPrint) {
            NM_ERROR("headerType error\n");
        }
        goto TAG_OUT;
    }

    if(headerMalloc == NULL) {
        NM_ERROR("headerMalloc is NULL\n");
        goto TAG_OUT;
    }

    NM_DEBUG("headerType is %d\n", headerType);
    switch(headerType) {
        case HEAD_WITH_ID:
            getInfoFromRemoteHeaderWithId(headerMalloc, &dataLen, &dataType, &id1st, &id2nd);
            __dataPrint(headerMalloc, HEADER_WITH_ID_LEN);

            headerLen = HEADER_WITH_ID_LEN;
            contentLen = WITH_ID_CONTENT_LEN(dataLen);
            break;
        case HEAD_WITHOUT_ID:
            pData = headerMalloc;
            __proxyMemcpy(&dataLen, pData, sizeof(uint32_t));
            dataLen = ntohl(dataLen) + HEADER_LEN_LEN;

            pData += sizeof(uint32_t);
            __proxyMemcpy(&dataType, pData, sizeof(uint8_t));

            headerLen = HEADER_WITHOUT_ID_LEN;
            contentLen = WITHOUT_ID_CONTENT_LEN(dataLen);

            /* 消息不带ID时，data也要补充ID字节，否则接收信息时会出现内存写越界 */
            dataLen += HEADER_ID_LEN;
            break;
        default:
            goto TAG_OUT;
    }

    NM_DEBUG("dataLen %d, headerLen %d， contentLen %d\n", dataLen, headerLen, contentLen);

    /* 根据头部重新分配空间，接收报文剩余部分，组成完整报文 */
    pSrc = headerMalloc;

    /* 从远端发送来的数据中，dataLen不包括头部长度
    	这里统一头部格式：头部长度+消息类型+ID；若
    	不携带ID，则填充0 */
    if((dataMallocN = __proxyMalloc(dataLen)) == NULL) {
        NM_ERROR("data malloc error\n");
        goto TAG_OUT;
    }
    pDest = dataMallocN;

    /* 拷贝头部 */
    if(headerMalloc != NULL) {
        NM_DEBUG("copy header:\n");
        __proxyMemcpy(pDest, pSrc, headerLen);
        pDest += headerLen;
        pSrc += headerLen;
    }

    /* 拷贝ID，若不带ID跳过这几位 */
    if(headerType == HEAD_WITHOUT_ID) {
        NM_DEBUG("jump id\n");
        pDest += HEADER_ID_LEN;
    }

    if(!recvRemoteContent(fd, pDest, contentLen)) {
        goto TAG_OUT;
    }

    __dataAction(dataType);
    if(headerType == HEAD_WITHOUT_ID) {
        __dataPrint(dataMallocN, dataLen + HEADER_ID_LEN);
    } else {
        __dataPrint(dataMallocN, dataLen);
    }

    ret = TRUE;

TAG_OUT:
    __proxyFree(&headerMalloc);

    if(!ret) {
        if(allowToPrint) {
            NM_ERROR("receive from remote error\n");
        }
        __proxyFree(&dataMallocN);
        dataLen = 0;
    } else {
        NM_DEBUG("receive from remote success\n");
        *bufMallocN = dataMallocN;
    }

    NM_INFO("leave\n");
    return dataLen;
}

void constructCConnect2(void *contentMallocN, uint32_t mallocLen)
{
    uint32_t remainLen = mallocLen;
    sContentCConnect2 info;
    void *pContent = contentMallocN;

    NM_INFO("enter\n");

    info.localAddr = inet_addr(proxyConfig.localAddr);
    info.localPort = htonl(proxyConfig.localPort);
    info.proType = PRO_HTTP;
    info.connectType = TYPE_TCP;

    if(contentMallocN == NULL) {
        NM_ERROR("contentMalloc is NULL\n");
    }

    remainLen -= sizeof(uint32_t);
    pContent += sizeof(uint32_t);

    if(remainLen < sizeof(uint32_t)) {
        NM_ERROR("mallocLen is too small\n");
        goto TAG_OUT;
    }
    __proxyMemcpy(pContent, &(info.localAddr), sizeof(uint32_t));
    remainLen -= sizeof(uint32_t);
    pContent += sizeof(uint32_t);

    if(remainLen < sizeof(uint32_t)) {
        NM_ERROR("mallocLen is too small\n");
        goto TAG_OUT;
    }
    __proxyMemcpy(pContent, &(info.localPort), sizeof(uint32_t));
    remainLen -= sizeof(uint32_t);
    pContent += sizeof(uint32_t);

    if(remainLen < sizeof(uint8_t)) {
        NM_ERROR("mallocLen is too small\n");
        goto TAG_OUT;
    }
    __proxyMemcpy(pContent, &(info.proType), sizeof(uint8_t));
    remainLen -= sizeof(uint8_t);
    pContent += sizeof(uint8_t);

    if(remainLen < sizeof(uint8_t)) {
        NM_ERROR("mallocLen is too small\n");
        goto TAG_OUT;
    }
    __proxyMemcpy(pContent, &(info.connectType), sizeof(uint8_t));

TAG_OUT:
    NM_INFO("leave\n");
    return;
}

void constructContent(void *contentMallocN, uint32_t mallocLen, uint8_t dataType)
{
    NM_INFO("enter\n");

    switch(dataType) {
        case C_CONNECT_2:
            constructCConnect2(contentMallocN, mallocLen);
            break;
        default:
            break;
    }

    NM_INFO("leave\n");

    return;
}

void processRemoteConect(uint64_t id1st, uint64_t id2nd)
{
    localSocketCreateById(id1st, id2nd);
}

void processRemoteConectClose(uint64_t id1st, uint64_t id2nd)
{
    localSocketCloseById(id1st, id2nd);
}

void processRemoteDataRelay(void *dataMalloc)
{
    sendContentToLocal(dataMalloc);
}

void processRemoteConect1R(void *dataMallocN, uint32_t dataLen)
{
    struct sockaddr_in remoteAddr;
    uint32_t remotePort = 0;
    char portString[PORT_LEN * 2 + 1] = {0};
    void *pData = dataMallocN + HEADER_WITH_ID_LEN;
    // uint64_t id1st = 0, id2nd = 0;
    sContentCConnect2 *contentMalloc = NULL;

    NM_INFO("enter\n");

    FD_SET(remoteFd2, &remoteFds);

    snprintf(portString, PORT_LEN * 2 + 1, "%02x%02x%02x%02x",
             ((unsigned char *)pData)[0], ((unsigned char *)pData)[1],
             ((unsigned char *)pData)[2], ((unsigned char *)pData)[3]);

    sscanf(portString, "%x", &remotePort);

    remoteAddr.sin_family = AF_INET;
    remoteAddr.sin_port = htons(remotePort);
    remoteAddr.sin_addr.s_addr = inet_addr(proxyConfig.remoteAddr);
    memset(&(remoteAddr.sin_zero), '\0', sizeof(remoteAddr.sin_zero));

    if(connect(remoteFd2, (struct sockaddr *)&remoteAddr, sizeof(struct sockaddr)) < 0) {
        NM_ERROR("failed to connect to server %s:%d (errono %d,%s)\n",
                 proxyConfig.remoteAddr, remotePort, errno, strerror(errno));
        close(remoteFd2);
        return;
    }
    NM_DEBUG("connect to server %s:%d\n", proxyConfig.remoteAddr, remotePort);

    if((contentMalloc = __proxyMalloc(CONTENT_C_CONNECT_2_LEN)) == NULL) {
        NM_ERROR("contentMalloc malloc error\n");
        NM_INFO("leave\n");
        return;
    }

    constructContent(contentMalloc, CONTENT_C_CONNECT_2_LEN, C_CONNECT_2);
    sendToRemote(remoteFd2, C_CONNECT_2, (char*) contentMalloc, CONTENT_C_CONNECT_2_LEN, 0, 0);

    __proxyFree((void**) &contentMalloc);

    NM_INFO("leave\n");
}

/* 将local fd加入set集合 */
void localFdSet(void)
{
    sLocalSocket *pSocket = localSocketListHead;

    while(NULL != pSocket) {
        FD_SET(pSocket->localFd, &localFds);
        pSocket = pSocket->next;
    }
}

void processLocalData(int32_t fd, uint64_t id1st, uint64_t id2nd)
{
    int32_t ret = 0;
    int32_t recvDataLen = 0;
    char *dataMalloc = NULL;
    uint32_t bufLen = RECV_LEN_MAX;

    NM_INFO("enter\n");

    if((dataMalloc = (char *)__proxyMalloc(bufLen)) == NULL) {
        NM_ERROR("data malloc size %d error\n", bufLen);
        NM_INFO("leave\n");
        goto TAG_OUT;
    }

    /* 接收local数据 */
    if(proxyConfig.socketType == 0) {
        /* TCP */
        recvDataLen = recv(fd, dataMalloc, bufLen, 0);
    } else {
        /* UDP */
        struct sockaddr_in sa;
        socklen_t salen = sizeof(sa);
        recvDataLen = recvfrom(fd, dataMalloc, bufLen, 0, (struct sockaddr *)&sa, &salen);
    }

    NM_DEBUG("receive %d byte from local[%d]\n", recvDataLen, fd);

    /* 向remote转发 */
    if(recvDataLen > 0) {
        __dataPrint(dataMalloc, recvDataLen);

        ret = sendToRemote(remoteFd1, C_DATARELAY, dataMalloc, recvDataLen, id1st, id2nd);
        if(!ret) {
            NM_ERROR("send to remote error: %d(%s)\n", errno, strerror(errno));
        } else {
            NM_DEBUG("send to remote success\n");
        }
    } else if(recvDataLen == 0) {
        NM_DEBUG("maybe receive a fin\n");
        localSocketAndRemoteSocketClose(&fd, remoteFd1, id1st, id2nd);
    } else {
        NM_ERROR("receive error, errno %d,%s\n", errno, strerror(errno));
        if (errno != EINTR) {
            localSocketAndRemoteSocketClose(&fd, remoteFd1, id1st, id2nd);
        }
    }

TAG_OUT:
    __proxyFree((void **) &dataMalloc);

    NM_INFO("leave\n");
}

void recvFromLocal(void)
{
    pthread_mutex_lock(&localSocketListMutex);
    sLocalSocket *pSocket = localSocketListHead;
    sLocalSocket *pSocketNext = NULL;

    while (NULL != pSocket) {
        /* 当接收数据长度为0时，processLocalData()会释放socket，需预先缓存next节点 */
        pSocketNext = pSocket->next;

        if (pSocket->localFd == -1) {
            NM_WARN("pSocket->localFd == -1, continue\n");
        } else if(FD_ISSET(pSocket->localFd, &localFds)) {
            processLocalData(pSocket->localFd, pSocket->id1st, pSocket->id2nd);
        }
        pSocket = pSocketNext;
    }
    pthread_mutex_unlock(&localSocketListMutex);
}

void listenToLocalData(void *arg)
{
    int32_t ret;
    struct timeval tv;

    NM_INFO("enter\n");

    pthread_detach(pthread_self());

    /* 监听socket，接收到本地报文向服务器转发 */
    while(1) {
        FD_ZERO(&localFds);
        pthread_mutex_lock(&localSocketListMutex);
        localFdSet();
        pthread_mutex_unlock(&localSocketListMutex);

        tv.tv_sec = 0;
        tv.tv_usec = LOCAL_FD_SEL_TIMEOUT;

        if((ret = select(FD_SETSIZE, &localFds, NULL, NULL, &tv)) <= 0) {
            continue;
        }
        NM_DEBUG("select return %d\n", ret);

        recvFromLocal();
    }

    NM_INFO("leave\n");
}

void threadInit(void)
{
    int32_t ret = 0;
    pthread_t tid = 0;

    NM_INFO("enter\n");

    ret = pthread_create(&tid, NULL, (void *)listenToLocalData, NULL);
    if(ret != 0) {
        NM_ERROR("pthread_create failed:[%d][%s]\n", ret, strerror(ret));
    } else {
        NM_DEBUG("thread create success\n");
    }

    NM_INFO("leave\n");
}

void remoteFdInit(void)
{
    struct sockaddr_in remoteAddr;

    NM_INFO("enter\n");

    if((remoteFd1 = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        NM_ERROR("failed to create SOCK_STREAM socket for remoteFd1: errno %d,%s, exit\n",
                 errno, strerror(errno));
        exit(1);
    }

    if((remoteFd2 = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        NM_ERROR("failed to create SOCK_STREAM socket for remoteFd2: errno %d,%s, exit\n",
                 errno, strerror(errno));
        exit(1);
    }

    remoteAddr.sin_family = AF_INET;
    remoteAddr.sin_port = htons(proxyConfig.remotePort);
    remoteAddr.sin_addr.s_addr = inet_addr(proxyConfig.remoteAddr);
    memset(&(remoteAddr.sin_zero), '\0', sizeof(remoteAddr.sin_zero));

    if(connect(remoteFd1, (struct sockaddr *)&remoteAddr, sizeof(struct sockaddr)) < 0) {
        NM_ERROR("failed to connect to server(errono %d,%s). exit\n",
                 errno, strerror(errno));
        close(remoteFd1);
        exit(1);
    }
    NM_DEBUG("connect to server %s:%d\n", proxyConfig.remoteAddr, proxyConfig.remotePort);

    NM_INFO("leave\n");
}

void processRemoteData(void *dataMalloc)
{
    uint8_t dataType = 0;
    uint32_t dataLen = 0;
    uint64_t id1st = 0, id2nd = 0;

    NM_INFO("enter\n");

    if(dataMalloc == NULL) {
        NM_ERROR("dataMalloc is NULL\n");
        NM_INFO("leave\n");
        return;
    }

    getInfoFromRemoteHeaderWithId(dataMalloc, &dataLen, &dataType, &id1st, &id2nd);
    NM_WARN("receive data(len %d(0x%X) type %d(0x%X), id1st 0x%"PRIX64", id2nd 0x%"PRIX64") from remote\n",
            dataLen, dataLen, dataType, dataType, id1st, id2nd);

    switch(dataType) {
        case S_CONNECT_1_R:
            processRemoteConect1R(dataMalloc, dataLen);
            break;
        case S_CONNECT_2_R:
            break;
        case S_CONNECT:
            /* socket在收到服务器发来S_CONNECT时创建，
            	若创建失败，在localFdGetById时会再次创建，
            	在收到服务器发来S_CON_CLOSE时删除 */
            processRemoteConect(id1st, id2nd);
            break;
        case S_CON_CLOSE:
            processRemoteConectClose(id1st, id2nd);
            break;
        case S_DATARELAY:
            processRemoteDataRelay(dataMalloc);
            break;
        default:
            break;
    }

    __proxyFree(&dataMalloc);

    NM_INFO("leave\n");
    return;
}

void recvFromRemote(int32_t fd)
{
    void *dataMallocN = NULL;
    uint32_t dataLen = 0;

    NM_INFO("enter\n");
    NM_DEBUG("receive from fd %d, remoteFd1=%d, remoteFd2=%d\n", fd, remoteFd1, remoteFd2);

    if(fd != remoteFd1 && fd != remoteFd2) {
        NM_ERROR("data is not from remoteFd1 or remoteFd2\n");
    }

    if((dataLen = recvRemoteData(fd, &dataMallocN)) > 0) {
        processRemoteData(dataMallocN);
    }

    NM_INFO("leave\n");
    return;
}

sLocalSocket *localSocketGetFromListById(uint64_t id1st, uint64_t id2nd)
{
    pthread_mutex_lock(&localSocketListMutex);
    sLocalSocket *pSocket = localSocketListHead;

    NM_INFO("enter\n");
    while(NULL != pSocket) {
        if(pSocket->id1st == id1st && pSocket->id2nd == id2nd) {
            NM_INFO("found socket(fd %d), leave\n", pSocket->localFd);
            pthread_mutex_unlock(&localSocketListMutex);
            return pSocket;
        }
        pSocket = pSocket->next;
    }

    NM_INFO("not found socket, leave\n");
    pthread_mutex_unlock(&localSocketListMutex);
    return NULL;
}

void localSocketListPrint(void)
{
#ifdef LIST_PRINT
    sLocalSocket *ptr;

    printf("=============================\n");
    pthread_mutex_lock(&localSocketListMutex);
    ptr = localSocketListHead;

    while(ptr) {
        printf("socket %d, id1st 0x%"PRIX64", id2nd 0x%"PRIX64"\n", ptr->localFd, ptr->id1st, ptr->id2nd);
        ptr = ptr->next;
    }
    printf("=============================\n\n");

    NM_DEBUG("localSocketListNum is %d\n", localSocketListNum);
    pthread_mutex_unlock(&localSocketListMutex);
#endif
}

void localSocketDelFromList(const int32_t localFd)
{
    sLocalSocket *ptr = NULL, *found = NULL;

    NM_INFO("enter\n");

    pthread_mutex_lock(&localSocketListMutex);
    ptr = localSocketListHead;
    if(ptr == NULL) {
        NM_DEBUG("localSocketList is empty\n");
    } else if(ptr->localFd == localFd) {
        found = ptr;
        NM_DEBUG("delete local socket(fd %d) from list\n", found->localFd);
        localSocketListHead = ptr->next;
        __proxyFree((void **) &found);
        localSocketListNum --;
    } else {
        while(ptr->next != NULL && ptr->next->localFd != localFd) {
            NM_DEBUG("ptr->next->localFd %d\n", ptr->next->localFd);
            ptr = ptr->next;
        }

        if(ptr->next == NULL) {
            NM_ERROR("socket could not find socket\n");
        } else {
            found = ptr->next;
            NM_DEBUG("delete local socket(fd %d) from list\n", found->localFd);
            ptr->next = ptr->next->next;
            __proxyFree((void**) &found);
            localSocketListNum --;
        }
    }

    NM_WARN("localSocketListNum is %d\n", localSocketListNum);
    pthread_mutex_unlock(&localSocketListMutex);
    NM_INFO("leave\n");
}

sLocalSocket *localSocketAddToList(const uint64_t id1st, uint64_t id2nd, const int32_t localFd)
{
    sLocalSocket *curSocket, *prevSocket;

    NM_INFO("enter\n");

    pthread_mutex_lock(&localSocketListMutex);
    prevSocket = NULL;
    curSocket = localSocketListHead;

    if(curSocket != NULL) {
        prevSocket = curSocket;
        curSocket = curSocket->next;
    }

    if((curSocket = __proxyMalloc(sizeof(sLocalSocket))) == NULL) {
        NM_ERROR("sLocalSocket malloc error\n");
        NM_INFO("leave\n");
        return NULL;
    }

    curSocket->id1st = id1st;
    curSocket->id2nd = id2nd;
    curSocket->localFd = localFd;

    NM_DEBUG("new node(%p) localFd %d, id1st 0x%"PRIX64", id2nd 0x%"PRIX64"\n", curSocket, localFd, id1st, id2nd);

    NM_DEBUG("add local socket(fd %d) to list\n", localFd);

    if(prevSocket == NULL) {
        localSocketListHead = curSocket;
    } else {
        curSocket->next = prevSocket->next;
        prevSocket->next = curSocket;
    }

    localSocketListNum ++;
    NM_WARN("localSocketListNum is %d\n", localSocketListNum);

    localSocketListPrint();

    NM_INFO("localSocketListNum is %d, leave\n", localSocketListNum);
    pthread_mutex_unlock(&localSocketListMutex);
    return curSocket;
}

bool localFdClose(int32_t *localFd)
{
    bool ret = FALSE;

    NM_INFO("enter\n");

    if (close(*localFd) == 0) {
        NM_WARN("close fd %d success\n", *localFd);
        localSocketDelFromList(*localFd);
        *localFd = -1;
        ret = TRUE;
    } else {
        NM_DEBUG("close fd %d failure\n", *localFd);
    }

    NM_INFO("leave\n");

    return ret;
}

bool localSocketAndRemoteSocketClose(int32_t *localFd, int32_t remoteSocket, uint64_t id1st, uint64_t id2nd)
{
    bool ret;
    NM_INFO("enter\n");
    localFdClose(localFd);

    ret = sendToRemote(remoteSocket, C_CON_CLOSE, NULL, 0, id1st, id2nd);
    if(!ret) {
        NM_ERROR("send to remote error: %d(%s)\n", errno, strerror(errno));
    } else {
        NM_DEBUG("send to remote success\n");
    }

    NM_INFO("leave\n");
    return ret;
}

int32_t localFdCreate(void)
{
    int32_t localFd = -1;
    struct sockaddr_in localSockaddr;

    NM_INFO("enter\n");

    if((localFd = socket(AF_INET,
                         proxyConfig.socketType == 0 ? SOCK_STREAM : SOCK_DGRAM, 0)) < 0) {
        NM_ERROR("failed to create a local socket: errno %d,%s\n", errno, strerror(errno));
        NM_INFO("leave\n");
        return -1;
    }

    NM_WARN("open fd %d success\n", localFd);

    localSockaddr.sin_family = AF_INET;
    localSockaddr.sin_port = htons(proxyConfig.localPort);
    localSockaddr.sin_addr.s_addr  = inet_addr(proxyConfig.localAddr);
    memset(&(localSockaddr.sin_zero), '\0', sizeof(localSockaddr.sin_zero));

    if(proxyConfig.socketType == 0) {
        if(connect(localFd, (struct sockaddr *)&localSockaddr, sizeof(struct sockaddr)) < 0) {
            NM_ERROR("failed to connect server %s:%d (errno %d,%s)\n",
                     proxyConfig.localAddr, proxyConfig.localPort, errno, strerror(errno));
            close(localFd);
            NM_INFO("leave\n");
            return -1;
        }
    } else {
        if(bind(localFd, (struct sockaddr *)&localSockaddr, sizeof(struct sockaddr)) < 0) {
            NM_ERROR("failed to bind server %s:%d (errno %d,%s)",
                     proxyConfig.localAddr, proxyConfig.localPort, errno, strerror(errno));
            close(localFd);
            NM_INFO("leave\n");
            return -1;
        }
    }

    NM_INFO("leave\n");
    return localFd;
}

int32_t localSocketCreateById(uint64_t id1st, uint64_t id2nd)
{
    int32_t localFd = -1;

    localFd = localFdCreate();

    if(localFd >= 0) {
        NM_DEBUG("create new local socket(fd %d)\n", localFd);
        if(localSocketAddToList(id1st, id2nd, localFd) == NULL) {
            NM_ERROR("fail to add socket(fd %d) to list, delete this socket\n", localFd);
            localSocketAndRemoteSocketClose(&localFd, remoteFd1, id1st, id2nd);
        }
    }

    return localFd;
}

void localSocketCloseById(uint64_t id1st, uint64_t id2nd)
{
    int32_t localFd = -1;
    int32_t localFdForPrint;

    NM_INFO("enter\n");

    localFd = localSocketGetById(id1st, id2nd, FALSE);
    localFdForPrint = localFd;

    if(!localFdClose(&localFd)) {
        NM_DEBUG("close socket(fd %d) error\n", localFdForPrint);
    } else {
        NM_DEBUG("close socket(fd %d) success\n", localFdForPrint);
    }
    //这里加个赋值，解决编译器变量未使用警告
    localFd = localFdForPrint;

    NM_INFO("leave\n");
}

int32_t localSocketGetById(uint64_t id1st, uint64_t id2nd, bool createSocket)
{
    int32_t localFd = -1;
    sLocalSocket *socket = NULL;

    NM_INFO("enter\n");

    socket = localSocketGetFromListById(id1st, id2nd);
    if(socket != NULL) {
        NM_DEBUG("find: id1st 0x%"PRIX64", id2nd 0x%"PRIX64", localFd %d\n", id1st, id2nd, socket->localFd);
        if(socket->localFd < 0) {
            NM_DEBUG("socket(fd %d) error, delete this socket\n", socket->localFd);
            localFdClose(&(socket->localFd));
            NM_DEBUG("renew: localFd[%d]\n", socket->localFd);
            socket->localFd = localFdCreate();
        }

        localFd = socket->localFd;
    } else if(createSocket) {
        localFd = localSocketCreateById(id1st, id2nd);
    }

    NM_INFO("leave\n");
    return localFd;
}

void getInfoFromRemoteHeaderWithId(void *headerWithId, uint32_t *dataLen,
                                   uint8_t *dataType, uint64_t *id1st, uint64_t *id2nd)
{
    void *pData = NULL;

    NM_INFO("enter\n");

    pData = headerWithId;
    __proxyMemcpy(dataLen, pData, sizeof(uint32_t));
    *dataLen = ntohl(*dataLen) + HEADER_LEN_LEN;

    pData += sizeof(uint32_t);
    __proxyMemcpy(dataType, pData, sizeof(uint8_t));

    pData += sizeof(uint8_t);
    __proxyMemcpy(id1st, pData, sizeof(uint64_t));
    *id1st = ntohll(*id1st);

    pData += sizeof(uint64_t);
    __proxyMemcpy(id2nd, pData, sizeof(uint64_t));
    *id2nd = ntohll(*id2nd);

    NM_DEBUG("dataLen %d(0x%X), dataType %d, id1st 0x%"PRIX64", id2nd 0x%"PRIX64"\n",
             *dataLen, *dataLen, *dataType, *id1st, *id2nd);
    NM_INFO("leave\n");
    return;
}

uint32_t contentEncode(uint8_t dataType, char* content, uint32_t contentLen,
                       void **dataMallocN, uint64_t id1st, uint64_t id2nd)
{
    int32_t dataLen = 0;
    void *pData = NULL;
    uint32_t nDataLen = 0;
    uint8_t nDataType = 0;
    uint64_t nId1st = 0;
    uint64_t nId2nd = 0;

    NM_INFO("enter\n");

    switch(dataType) {
        case C_DATARELAY:
        case C_CON_CLOSE:
            nDataLen = htonl(HEADER_WITH_ID_LEN - HEADER_LEN_LEN + contentLen);
            nDataType = dataType;
            nId1st = htonll(id1st);
            nId2nd = htonll(id2nd);
            dataLen = HEADER_WITH_ID_LEN + contentLen;

            if((*dataMallocN = __proxyMalloc(dataLen)) == NULL) {
                NM_ERROR("data malloc error\n");
                goto TAG_OUT;
            }
            pData = *dataMallocN;

            __proxyMemcpy(pData, &nDataLen, sizeof(uint32_t));
            pData += sizeof(uint32_t);

            __proxyMemcpy(pData, &nDataType, sizeof(uint8_t));
            pData += sizeof(uint8_t);

            __proxyMemcpy(pData, &nId1st, sizeof(uint64_t));
            pData += sizeof(uint64_t);

            __proxyMemcpy(pData, &nId2nd, sizeof(uint64_t));
            pData += sizeof(uint64_t);

            if(content != NULL) {
                __proxyMemcpy(pData, content, contentLen);
            }

            break;
        default:
            dataLen = HEADER_WITHOUT_ID_LEN + contentLen;

            if((*dataMallocN = __proxyMalloc(dataLen)) == NULL) {
                NM_ERROR("data malloc error\n");
                goto TAG_OUT;
            }
            pData = *dataMallocN;

            if(dataType == C_CONNECT_2) {
                nDataLen = htonl(HEADER_TYPE_LEN + contentLen);
            } else {
                nDataLen = htonl(HEADER_WITHOUT_ID_LEN + contentLen);
            }
            nDataType = dataType;

            __proxyMemcpy(pData, &nDataLen, sizeof(uint32_t));
            pData += sizeof(uint32_t);

            __proxyMemcpy(pData, &nDataType, sizeof(uint8_t));
            pData += sizeof(uint8_t);

            if(content != NULL) {
                __proxyMemcpy(pData, content, contentLen);
            }

            break;
    }

TAG_OUT:
    NM_INFO("leave\n");
    return dataLen;
}

bool sendToRemote(int32_t fd, uint8_t dataType, char* content, int32_t contentLen,
                  uint64_t id1st, uint64_t id2nd)
{
    void *dataMalloc = NULL;
    uint32_t dataLen = 0;
    uint32_t sendLen = 0;
    bool ret = FALSE;

    NM_INFO("enter\n");

    if(fd <= 0) {
        NM_ERROR("fd error\n");
        ret = FALSE;
        goto TAG_OUT;
    }

    dataLen = contentEncode(dataType, content, contentLen, &dataMalloc, id1st, id2nd);

    __dataAction(dataType);
    __dataPrint(dataMalloc, dataLen);

    sendLen = __proxySend(fd, dataMalloc, dataLen, 0);

    NM_WARN("data(len %d(0x%X) type %d(0x%X), id1st 0x%"PRIX64", id2nd 0x%"PRIX64") has been sent to remote, sent %d byte\n",
            dataLen, dataLen, dataType, dataType, id1st, id2nd, sendLen);

    if(sendLen == dataLen) {
        NM_DEBUG("send message success\n");
        ret = TRUE;
    }

TAG_OUT:
    __proxyFree(&dataMalloc);

    NM_INFO("leave\n");
    return ret;
}

/* 把data中的content部分提取出来，发送给local */
void sendContentToLocal(void *data)
{
    int32_t contentLen = 0;
    int32_t sendLen = 0;
    uint8_t dataType = 0;
    char *pContent = NULL;
    uint32_t dataLen = 0;
    // void *pData = NULL;
    bool createSocket = FALSE;
    int32_t localFd = 0;
    uint64_t id1st = 0, id2nd = 0;

    NM_INFO("enter\n");

    if(data == NULL) {
        NM_ERROR("data is NULL, error\n");
        goto TAG_OUT;
    }

    /* 获取content内容，发送给local的只是content部分 */
    getInfoFromRemoteHeaderWithId(data, &dataLen, &dataType, &id1st, &id2nd);

    /* 只有收到S_CONNECT或S_DATARELAY，才允许无法根据id在socket链表中查询
    	到socket时，创建新的socket用于与本地web服务通信 */
    if(dataType == S_CONNECT||dataType == S_DATARELAY) {
        createSocket = TRUE;
    }

    pContent = data + HEADER_WITH_ID_LEN;
    contentLen = WITH_ID_CONTENT_LEN(dataLen);
    if(contentLen < 0) {
        NM_ERROR("content length %d error\n", contentLen);
        goto TAG_OUT;
    }

    localFd = localSocketGetById(id1st, id2nd, createSocket);
    if(localFd < 0) {
        goto TAG_OUT;
    }

    sendLen = __proxySend(localFd, pContent, contentLen, 0);

    /* 处理通信的fd，在content未完全发送前，该fd需要保存 */
    if(sendLen > 0) {
        NM_WARN("data(fd %d, len %u(0x%X) type %u(0x%X), id1st 0x%"PRIX64", id2nd 0x%"PRIX64") has been sent to local, sent %d byte\n",
                localFd, dataLen, dataLen, dataType, dataType, id1st, id2nd, sendLen);
    } else {
        NM_ERROR("data(fd %d, len %u(0x%X) type %u(0x%X), id1st 0x%"PRIX64", id2nd 0x%"PRIX64") send data to local error, sent %d byte: %d(%s)\n",
                 localFd, dataLen, dataLen, dataType, dataType, id1st, id2nd, sendLen, errno, strerror(errno));
    }

TAG_OUT:
    NM_INFO("leave\n");
}

// 建立信号处理机制
void sigactionInit(void *action)
{
    struct sigaction tact;

    NM_INFO("enter\n");
    /*信号到了要执行的任务处理函数为__heartBeat*/
    tact.sa_handler = action;
    tact.sa_flags = 0;

    /*初始化信号集*/
    sigemptyset(&tact.sa_mask);
    /*建立信号处理机制*/
    sigaction(SIGALRM, &tact, NULL);
    NM_INFO("leave\n");
}

void timerInit(struct itimerval value)
{
    //struct itimerval value;

    NM_INFO("enter\n");
    /*
    value.it_value.tv_usec = 0;

    // 设定执行任务的时间间隔
    value.it_interval.tv_sec = setValue.it_interval.tv_sec;
    value.it_interval.tv_usec = setValue.it_interval.tv_usec;

    // 首次执行任务时间延迟
    value.it_value.tv_sec = setValue.it_value.tv_sec;
    value.it_value.tv_usec = setValue.it_value.tv_usec;*/

    // 设置计时器ITIMER_REAL
    setitimer(ITIMER_REAL, &value, NULL);
    NM_INFO("leave\n");
}

void heartBeatInit(void)
{
    struct itimerval value;

    NM_INFO("enter\n");

    /* 设定执行任务的时间间隔 */
    value.it_interval.tv_sec = HEARTBEAT_INVL_S;
    value.it_interval.tv_usec = 0;

    /* 首次执行任务时间延迟 */
    value.it_value.tv_sec = 0;
    value.it_value.tv_usec = HEARTBEAT_DELAY_US;

    sigactionInit(__heartBeat);
    timerInit(value);
    NM_INFO("leave\n");
}

int32_t __getOpt(int32_t argc, char ** argv)
{
    char c = 0;

    NM_INFO("enter\n");
    while((c = getopt(argc, argv, "d:r:s:l:t:k:")) != EOF && c != OPT_END) {
        switch(c) {
            case 'd':
                snprintf(proxyConfig.remoteAddr, sizeof(proxyConfig.remoteAddr), "%s", optarg);
                break;

            case 'r':
                proxyConfig.remotePort = atoi(optarg);
                break;

            case 's':
                snprintf(proxyConfig.localAddr, sizeof(proxyConfig.localAddr), "%s", optarg);
                break;

            case 'l':
                proxyConfig.localPort = atoi(optarg);
                break;

            case 't':
                proxyConfig.socketType = atoi(optarg);
                break;

            case 'k':
                snprintf(proxyConfig.connectKey, sizeof(proxyConfig.connectKey), "%s", optarg);
                break;

            default:
                printf("unrecongnized option :%c\n", c);
                printf("%s version %s build by %s on: %s\n",
                       argv[0], NMPROXY_VERSION, NMPROXY_BUILDER, NMPROXY_BUILD_TIME);
                printf("Usage: %s\n", argv[0]);
                printf("    -d     dest(remote server) address\n");
                printf("    -r     remote port\n");
                printf("    -s     source(device local) address\n");
                printf("    -l     local port\n");
                printf("    -t     socket type: 0=SOCK_STREAM, 1=SOCK_DGRAM\n");
                printf("    -k     connection key\n");
                return -1;
        }
    }

    NM_DEBUG("proxyConfig:\n"
             "\tsrvAddr: %s\n"
             "\tsrvPort: %d\n"
             "\tdestAddr: %s\n"
             "\tdestPort: %d\n"
             "\tsocketType: %s\n"
             "\tconnectKey: %s\n",
             proxyConfig.remoteAddr, proxyConfig.remotePort, proxyConfig.localAddr,
             proxyConfig.localPort, proxyConfig.socketType==0?"SOCK_STREAM":"SOCK_DGRAM",
             proxyConfig.connectKey);

    NM_INFO("leave\n");
    return 0;
}

int32_t main (int32_t argc, char **argv)
{
    //st_char_t* dir = getenv("DATA_DIRECTORY");
    //st_char_t buf[128] = {};

    // st_initialize();
    // st_log_init("nmproxy");

    // snprintf(buf, sizeof(buf), "%s/log", dir);
    // mkdir(buf, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    // chmod(buf, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    // st_logfile_setdir(buf);

    // st_log_setlevel(NM_ST_LOG_LOGLEVEL);

    memset(&proxyConfig, 0, sizeof(sProxyConfig));

    /* 设置参数 */
    if(__getOpt(argc, argv) < 0) {
        NM_ERROR("require arguments, exit\n");
        exit(1);
    }

    proxyInit();
    proxyProcess();
    proxyExit();

    return 0;
}
