#define LOG_TAG "nmproxy"

#ifndef __NM_PROXY__
#define __NM_PROXY__

#include <pthread.h>

#define __LOG_ERROR
//#define __LOG_WARN
//#define __LOG_INFO
//#define __LOG_DEBUG
//#define DATA_PRINT
//#define LIST_PRINT /* FIXME 目前打开这个会发生崩溃 */
#define NM_ST_LOG_LOGLEVEL ST_LOGLEVEL_INFO

#define OPT_END	255
#define REMOTE_FD_SEL_TIMEOUT	5
#define LOCAL_FD_SEL_TIMEOUT	10 * 1000
#define HEARTBEAT_DELAY_US	(20*1000)
#define HEARTBEAT_INVL_S	60
#define RECV_TIMEOUT_US	(5*1000*1000)
#define MSECS_IN_SEC	1000
#define USECS_IN_MSEC	1000
#define RECV_LEN_MAX	3072

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define LOCK_MALLOC(mutex) do { \
	pthread_mutex_lock(&mutex); \
} while (0)

#define UNLOCK_MALLOC(mutex) do { \
	pthread_mutex_unlock(&mutex); \
} while (0)


#ifdef __LOG_INFO
#define NM_INFO(format,...) do { \
	printf(LOG_TAG "[%s:%d][0x%lX]" format, __FUNCTION__, __LINE__, (long unsigned int)pthread_self(), ##__VA_ARGS__); \
} while (0)
#else
#define NM_INFO(format,...)
#endif

#ifdef __LOG_WARN
#define NM_WARN(format,...) do { \
	printf(LOG_TAG "[%s:%d][0x%lX]" format, __FUNCTION__, __LINE__, (long unsigned int)pthread_self(), ##__VA_ARGS__); \
} while (0)
#else
#define NM_WARN(format,...)
#endif

#ifdef __LOG_DEBUG
#define NM_DEBUG(format,...) do { \
	printf(LOG_TAG "[%s:%d][0x%lX]" format, __FUNCTION__, __LINE__, (long unsigned int)pthread_self(), ##__VA_ARGS__); \
} while (0)
#else
#define NM_DEBUG(format,...)
#endif

#ifdef __LOG_ERROR
#define NM_ERROR(format,...) do { \
	printf(LOG_TAG "[%s:%d][0x%lX]" format, __FUNCTION__, __LINE__, (long unsigned int)pthread_self(), ##__VA_ARGS__); \
} while (0)
#else
#define NM_ERROR(format,...)
#endif


typedef uint8_t bool;

typedef enum {
    C_CONNECT_1		= 1,
    C_CONNECT_2,
    C_HEARTBEAT,
    C_DATARELAY,
    C_CON_CLOSE,
    S_CONNECT_1_R	= 64,
    S_CONNECT_2_R,
    S_CONNECT,
    S_DATARELAY,
    S_CON_CLOSE
} tDataTyep;

typedef enum {
    PRO_FTP = 1,
    PRO_TELNET,
    PRO_SMTP,
    PRO_POP3,
    PRO_HTTP,
    PRO_DNS,
    PRO_SNMP,
    PRO_SSH
} tProType;

typedef enum {
    TYPE_TCP = 1,
    TYPE_UDP
} tConnectType;

typedef enum {
    HEAD_ERR = 0,
    HEAD_UNKNOWN,
    HEAD_WITH_ID,
    HEAD_WITHOUT_ID,
} tDataHeadType;

typedef struct _sLocalSocket {
    uint64_t id1st;
    uint64_t id2nd;
    int32_t localFd;
    struct _sLocalSocket *next;
} sLocalSocket;

typedef struct {
    char remoteAddr[32];	// 与设备交互的服务器地址，对应节点中的ServerAddress
    uint32_t remotePort;	// 与设备交互的服务器端口，对应节点中的ServerPort
    char localAddr[32];		// 设备web地址,对应节点中的DestAddress
    uint32_t localPort;		// 设备web端口,对应节点中的DestPort
    uint32_t socketType;	// 连接类型，如SOCK_STREAM
    char connectKey[64];	// 对应节点中的ConnectKey
} sProxyConfig;

/* 由于交互过程中头部长度不统一，定义了两种数据结构 */
typedef struct {
    uint32_t dataLen;		// ToRemote包含dataLen自身4 byte；FromRemote不包含dataLen自身4 byte
    uint8_t dataType;		// 消息类型
    uint64_t id1st;			// 标识连接
    uint64_t id2nd;
} sHeaderWithId;

typedef struct {
    uint32_t dataLen;
    uint8_t dataType;
} sHeaderWithoutId;

typedef struct {
    uint32_t localAddr;		// 设备web地址,对应节点中的DestAddress
    uint32_t localPort;		// 设备web端口,对应节点中的DestPort
    uint8_t proType;		// 协议类型
    uint8_t connectType;	// TCP或UDP
} sContentCConnect2;

#define HEADER_ID_PART_LEN	8
#define HEADER_ID_LEN	(HEADER_ID_PART_LEN * 2)
#define HEADER_LEN_LEN	4
#define HEADER_TYPE_LEN	1

/* 由于结构体字节对齐问题，这里直接定义结构体的长度 */
#define HEADER_WITHOUT_ID_LEN	(HEADER_LEN_LEN + HEADER_TYPE_LEN)
#define HEADER_WITH_ID_LEN		(HEADER_WITHOUT_ID_LEN + HEADER_ID_LEN)

/* 这里把收到的tcp报文中携带的内容称为data，
	data由header和content组成，
	header包括dataHeaderLen和dataType */
#define WITH_ID_CONTENT_LEN(dataLen)	\
	((dataLen) - HEADER_ID_LEN - HEADER_TYPE_LEN - HEADER_LEN_LEN)
#define WITHOUT_ID_CONTENT_LEN(dataLen)	\
	((dataLen) - HEADER_TYPE_LEN  - HEADER_LEN_LEN)

#define PORT_LEN	4
#define CONTENT_C_CONNECT_2_LEN	14


void timerInit(struct itimerval value);
void sigactionInit(void *action);
void threadInit(void);
void remoteFdInit(void);
void heartBeatInit(void);


void proxyInit(void);
void proxyProcess(void);
void proxyExit(void);


void recvFromRemote(int32_t fd);

uint32_t recvRemoteData(int32_t fd, void **data);
uint16_t recvRemoteHeader(int32_t fd, void **dataHeaderMalloc);
void getInfoFromRemoteHeaderWithId(void *dataHeaderWithId, uint32_t *dataLen,
                                   uint8_t *dataType, uint64_t *id1st, uint64_t *id2nd);
bool recvRemoteContent(int32_t fd, void *pData, uint32_t contentLen);

void processRemoteData(void *dataMalloc);
void processRemoteConect1R(void *dataMalloc, uint32_t dataLen);
void processRemoteConect(uint64_t id1st, uint64_t id2nd);
void processRemoteConectClose(uint64_t id1st, uint64_t id2nd);
void processRemoteDataRelay(void *dataMalloc);

void sendContentToLocal(void *data);


void listenToLocalData(void *arg);
void recvFromLocal(void);

void processLocalData(int32_t fd, uint64_t id1st, uint64_t id2nd);

bool sendToRemote(int32_t fd, uint8_t dataType, char* data,
                  int32_t dataLen, uint64_t id1st, uint64_t id2nd);


void constructContent(void *contentMalloc, uint32_t contentLen, uint8_t dataType);
void constructCConnect2(void *contentMalloc, uint32_t mallocLen);
uint32_t contentEncode(uint8_t dataType, char* data, uint32_t dataLen, void **dataMalloc,
                       uint64_t id1st, uint64_t id2nd);

bool waitForData(int32_t fd, uint32_t timeout);

int32_t localFdCreate(void);
bool localFdClose(int32_t *localFd);

/**
 * @brief 本地连接主动断开时通知远端
 *
 * @param localFd
 * @param remoteSocket
 * @param id1st
 * @param id2nd
 * @return true
 * @return false
 */
bool localSocketAndRemoteSocketClose(int32_t *localFd, int32_t remoteSocket, uint64_t id1st, uint64_t id2nd);

int32_t localSocketCreateById(uint64_t id1st, uint64_t id2nd);
void localSocketCloseById(uint64_t id1st, uint64_t id2nd);
int32_t localSocketGetById(uint64_t id1st, uint64_t id2nd, bool createSocket);
void localSocketListPrint(void);
sLocalSocket *localSocketGetFromListById(uint64_t id1st, uint64_t id2nd);
sLocalSocket *localSocketAddToList(const uint64_t id1st, uint64_t id2nd, const int32_t localFd);
void localSocketDelFromList(const int32_t localFd);

uint64_t htonll(uint64_t val);
uint64_t ntohll(uint64_t val);



#endif