from conans import ConanFile, CMake, tools
import os


class NmproxyConan(ConanFile):
    name = "nmproxy"
    version = "1.0.7"
    license = "<Put the package license here>"
    author = "Yusong Xie <xieyusong@star-net.cn>"
    url = "http://git.zhkj-rd.cn:8010/stclib/nmproxy"
    description = "Allows EMS to connect devices by SSH or web"
    topics = ("network", "management", "tr069")
    settings = "os", "compiler", "build_type", "arch"
    options = {"shared": [True, False], "fPIC": [True, False]}
    default_options = {"shared": False, "fPIC": True}
    generators = "cmake"

    def config_options(self):
        if self.settings.os == "Windows":
            del self.options.fPIC

    def source(self):
        # self.run("git clone https://github.com/conan-io/hello.git")
        # This small hack might be useful to guarantee proper /MT /MD linkage
        # in MSVC if the packaged project doesn't have variables to set it
        # properly
#         tools.replace_in_file("hello/CMakeLists.txt", "PROJECT(HelloWorld)",
#                               '''PROJECT(HelloWorld)
# include(${CMAKE_BINARY_DIR}/conanbuildinfo.cmake)
# conan_basic_setup()''')
        project_dir = os.environ.get('CONAN_PROJECT_DIR')
        self.run("ln -s " + project_dir + " .")

    def build(self):
        # cmake = CMake(self)
        # cmake.configure(source_folder="hello")
        # cmake.build()

        # Explicit way:
        # self.run('cmake %s/hello %s'
        #          % (self.source_folder, cmake.command_line))
        # self.run("cmake --build . %s" % cmake.build_config)
        platform = os.environ.get('CONAN_CMAKE_PLATFORM', 'x86')
        args = os.environ.get('CONAN_EXTRA_ARGS', '')
        if (args != ''):
            args = ' ' + args
        print('running command with extra args: [' + args + ']')
        self.run("cp conanbuildinfo.cmake " + self.name + "/conanbuildinfo.cmake")
        self.run("cm-build -s " + self.name + " -p " + platform + " -i -j" + args)


    def package(self):
        platform = os.environ.get('CONAN_CMAKE_PLATFORM', 'x86')

        # self.copy("*.h", dst="include", src="out/" + platform + "/include")
        # self.copy("*hello.lib", dst="lib", keep_path=False)
        # self.copy("*.dll", dst="bin", src="out/" + platform + "/lib", keep_path=False)
        # self.copy("*.dylib", dst="lib", src="out/" + platform + "/lib", keep_path=False)
        # self.copy("*.so", dst="lib", src="out/" + platform + "/lib", keep_path=False)
        # self.copy("*.a", dst="lib", src="out/" + platform + "/lib", keep_path=False)
        self.copy("nmproxy", dst="bin", src="out/" + platform + "/bin", keep_path=False)

    def package_info(self):
        self.cpp_info.libs = [""]

