#define LOG_TAG "emud"
#include "util/JsonUtil.h"

#include <cstdlib>
#include <memory>

namespace emu {
namespace util {

std::optional<Json::Value> ParseJson(const std::string& text) {
    Json::CharReaderBuilder builder;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    Json::Value root;
    std::string errs;
    if (!reader->parse(text.data(), text.data() + text.size(), &root, &errs)) {
        return std::nullopt;
    }
    return root;
}

std::string DumpJson(const Json::Value& v) {
    Json::StreamWriterBuilder builder;
    builder["indentation"] = "";
    return Json::writeString(builder, v);
}

std::string GetString(const Json::Value& v, const std::string& key, const std::string& def) {
    const Json::Value& x = v[key];
    return x.isString() ? x.asString() : def;
}

int GetInt(const Json::Value& v, const std::string& key, int def) {
    const Json::Value& x = v[key];
    if (x.isNumeric()) return x.asInt();
    // 服务端可能以字符串下发数值（如 "mqttPort":"1883"），宽松解析
    if (x.isString()) return std::atoi(x.asString().c_str());
    return def;
}

bool GetBool(const Json::Value& v, const std::string& key, bool def) {
    const Json::Value& x = v[key];
    if (x.isBool()) return x.asBool();
    return def;
}

}  // namespace util
}  // namespace emu
