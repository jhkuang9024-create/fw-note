// emud 公共工具层：随机串（cnonce / nonce）。
#ifndef EMU_UTIL_RAND_UTIL_H
#define EMU_UTIL_RAND_UTIL_H

#include <cstddef>
#include <string>

namespace emu {
namespace util {

// 生成 len 位十六进制随机串。
// （合并 Auth::MakeCnonce / MakeNonce32；改用 bionic arc4random，加密安全，
//   替代原 std::srand/std::rand）
std::string MakeRandomHex(std::size_t len);

}  // namespace util
}  // namespace emu

#endif  // EMU_UTIL_RAND_UTIL_H
