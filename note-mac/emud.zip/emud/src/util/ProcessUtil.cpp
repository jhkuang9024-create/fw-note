#define LOG_TAG "emud"
#include "util/ProcessUtil.h"

#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstring>

#include <log/log.h>

namespace emu {
namespace util {

void ExecArgv(const std::vector<std::string>& args, int execFailFd) {
    std::vector<char*> argv;
    argv.reserve(args.size() + 1);
    for (const auto& a : args) argv.push_back(const_cast<char*>(a.c_str()));
    argv.push_back(nullptr);
    ::execve(argv[0], argv.data(), environ);
    ALOGE("[emud] execve failed: %s", ::strerror(errno));
    if (execFailFd >= 0) {
        const char failed = 1;
        ::write(execFailFd, &failed, 1);
    }
    _exit(127);
}

pid_t SpawnProbe(const std::vector<std::string>& args, const char* tag) {
    if (!tag) tag = "proc";
    // 管道探测 exec 结果：成功 → CLOEXEC 关闭写端（父进程读到 EOF）；
    // 失败 → 子进程写入 1 字节（父进程 n>0，回收后返回 -1）。
    int errPipe[2];
    if (::pipe(errPipe) != 0) {
        ALOGE("[%s] pipe failed: %s", tag, ::strerror(errno));
        return -1;
    }
    ::fcntl(errPipe[1], F_SETFD, FD_CLOEXEC);

    pid_t p = ::fork();
    if (p < 0) {
        ::close(errPipe[0]);
        ::close(errPipe[1]);
        ALOGE("[%s] fork failed: %s", tag, ::strerror(errno));
        return -1;
    }
    if (p == 0) {
        // child：exec 失败时 ExecArgv 已写管道并 _exit(127)，正常到不了这里
        ::close(errPipe[0]);
        ExecArgv(args, errPipe[1]);
        _exit(127);
    }

    // parent
    ::close(errPipe[1]);
    char failed = 0;
    const ssize_t n = ::read(errPipe[0], &failed, 1);
    ::close(errPipe[0]);

    if (n > 0) {
        // 子进程 exec 失败（管道收到字节）：回收后返回 -1
        ALOGE("[%s] exec FAILED pid=%d", tag, p);
        int status = 0;
        ::waitpid(p, &status, 0);
        return -1;
    }
    return p;
}

void TerminateProcess(pid_t& pid, const char* tag) {
    if (pid <= 0) return;
    if (::kill(pid, 0) != 0) {
        ALOGI("[%s] already exited pid=%d", tag, pid);
        pid = -1;
        return;
    }

    ::kill(pid, SIGTERM);
    for (int i = 0; i < 10 && ::kill(pid, 0) == 0; ++i) {
        ::usleep(100 * 1000);
    }
    if (::kill(pid, 0) == 0) {
        ::kill(pid, SIGKILL);
    }
    int status = 0;
    ::waitpid(pid, &status, 0);
    ALOGI("[%s] stopped pid=%d", tag, pid);
    pid = -1;
}

int ExecShellTimeout(const std::string& cmd, int timeoutSec,
                     const std::atomic<bool>* cancel) {
    pid_t pid = ::fork();
    if (pid < 0) {
        ALOGE("[emud] fork shell failed: %s", ::strerror(errno));
        return -1;
    }
    if (pid == 0) {
        // 子进程独立进程组：超时/取消时按组 SIGKILL，避免遗留孙进程继续跑。
        ::setpgid(0, 0);
        ::execl("/system/bin/sh", "sh", "-c", cmd.c_str(), static_cast<char*>(nullptr));
        ALOGE("[emud] exec sh failed: %s", ::strerror(errno));
        _exit(127);
    }

    const auto begin = std::chrono::steady_clock::now();
    int status = 0;
    for (;;) {
        const pid_t r = ::waitpid(pid, &status, WNOHANG);
        if (r == pid) {
            if (WIFEXITED(status)) return WEXITSTATUS(status);
            if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
            return -1;
        }
        if (r < 0) {
            ALOGE("[emud] waitpid shell failed: %s", ::strerror(errno));
            return -1;
        }
        const bool timedOut =
                timeoutSec > 0 &&
                std::chrono::duration_cast<std::chrono::seconds>(
                        std::chrono::steady_clock::now() - begin).count() >= timeoutSec;
        if (timedOut || (cancel && cancel->load())) {
            ALOGW("[emud] shell timeout/cancel, kill group pid=%d", pid);
            ::kill(-pid, SIGKILL);
            ::waitpid(pid, &status, 0);
            return -2;
        }
        ::usleep(100 * 1000);
    }
}

}  // namespace util
}  // namespace emu
