#define LOG_TAG "emud"
#include "util/StringUtil.h"

#include <cctype>
#include <utility>

#include <android-base/strings.h>

namespace emu {
namespace util {

// 按行拆分，丢弃空行，规整 CRLF/CR 行尾。
// 复用 libbase Tokenize（合并连续分隔符、忽略首尾空行 = 丢弃空行），
// 仅补 CR 行尾规整（payload_properties 等行尾兼容 CRLF/CR）。
std::vector<std::string> SplitHeaderLines(const std::string& headers) {
    std::vector<std::string> out;
    for (std::string& line : android::base::Tokenize(headers, "\n")) {
        if (line.back() == '\r') line.pop_back();
        out.push_back(std::move(line));
    }
    return out;
}

bool TaskIdSafe(const std::string& id, std::size_t maxLen) {
    if (id.empty() || id.size() > maxLen) return false;
    for (unsigned char c : id) {
        if (!(std::isalnum(c) || c == '_' || c == '-' || c == '.')) return false;
    }
    return true;
}

}  // namespace util
}  // namespace emu
