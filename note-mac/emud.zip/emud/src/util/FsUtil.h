// emud 公共工具层：文件系统（空闲空间 / mkdir -p）。
#ifndef EMU_UTIL_FS_UTIL_H
#define EMU_UTIL_FS_UTIL_H

#include <sys/types.h>

#include <string>
#include <vector>

namespace emu {
namespace util {

// 查询 path_hint 所在文件系统的可用空间（字节）；失败返回 -1。
// （合并 PkgCleanup::freeBytes 与 CaptureLogFeature::fsFreeBytes）
long long FreeBytes(const std::string& pathHint);

// mkdir -p 语义（多层递归创建，已存在不报错）；成功返回 0。
// （从 CaptureLogFeature 提取）
int MkdirP(const char* path, mode_t mode);

// 枚举目录项名称（不含 "." / ".."）。成功返回 0；失败返回 -1（errno 保留有效）。
// 后缀 / 隐藏文件过滤由调用方完成，保持各调用点既有语义不变。
// （合并 FileStore / TaskStore / PkgCleanup / CaptureLogFeature / DiagnosticsFeature
//   共 9+ 处手写 opendir/readdir/closedir 循环）
int ListDir(const std::string& dir, std::vector<std::string>* names);

// 原子写文件：内容先写同目录 <path>.tmp → fsync → rename 覆盖 → fsync 父目录。
// 断电 / 崩溃时目标文件要么是旧内容要么是新内容，不会留下截断半写（状态/任务等
// JSON 持久化用）。失败返回 -1（errno 保留有效），并清理临时文件。
int WriteFileAtomic(const std::string& path, const std::string& content,
                    mode_t mode = 0644);

}  // namespace util
}  // namespace emu

#endif  // EMU_UTIL_FS_UTIL_H
