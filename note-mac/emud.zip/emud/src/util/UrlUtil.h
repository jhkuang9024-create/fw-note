// emud 公共工具层：URL 校验 / 上传 URL 拼接。
#ifndef EMU_UTIL_URL_UTIL_H
#define EMU_UTIL_URL_UTIL_H

#include <string>

namespace emu {
namespace util {

// URL 基础合法性：仅 http/https，无控制字符。
// （OtaDownloader / UpgradeFeature / CaptureLogFeature 的公共校验部分）
bool IsHttpUrl(const std::string& url);

// 上传 URL 追加 EOF 标志：{eof} 占位符替换，否则路径追加 /true|/false。
// （合并 DiagnosticsFeature::buildUploadUrl 与 CaptureLogFeature::BuildUploadUrl）
std::string BuildUploadUrl(const std::string& base, bool eof);

// 轻量 percent 解码：%XX → 原始字节；非法 / 不完整 % 序列按原样保留。
// 两个语义入口（内部实现相同，仅 '+' 处理不同，避免合并时改错任一调用方）：
//  - PercentDecodeQuery：'+' → 空格（application/x-www-form-urlencoded 语义）。
//  - PercentDecodeRFC5987：'+' 保留为字面量（RFC5987 filename* 语义）。
// （合并 FileStore 与 HttpFileFetcher 两份逐字重复实现）
std::string PercentDecodeQuery(const std::string& in);
std::string PercentDecodeRFC5987(const std::string& in);

// URL host 提取：小写；去掉 scheme、userinfo、端口、路径、query 等；失败返回空。
// 例：https://u@10.0.0.1:8080/a?b → 10.0.0.1；http://[::1]:80/x → [::1]
std::string UrlHost(const std::string& url);

// host 是否回环 / 链路本地：localhost、127.*、::1、[::1]、0.0.0.0、169.254.*，
// 空串视为本地。入参约定小写（通常来自 UrlHost）。
// （合并 CaptureLogFeature::HostBlocked）
bool IsLocalHost(const std::string& host);

// 上传目标 URL 完整校验：IsHttpUrl + 禁引号/反引号/反斜杠 + host 非本地（SSRF 防护）；
// 空、超长（>= maxLen）拒绝。
// （合并 CaptureLogFeature::UrlAllowed，供 GET_LOG_FILE / 诊断抓包上传等共用）
bool UrlSafe(const std::string& url, std::size_t maxLen = 2048);

// URL 日志脱敏：去掉 query/fragment（常含签名/token），并净化控制字符防日志注入。
// （统一 OtaDownloader / NioFeature / FileUpload / CaptureLogFeature 各处不一致实现）
std::string RedactUrl(const std::string& url);

}  // namespace util
}  // namespace emu

#endif  // EMU_UTIL_URL_UTIL_H
