#define LOG_TAG "emud"
#include "util/UrlUtil.h"

#include <cctype>

namespace emu {
namespace util {

bool IsHttpUrl(const std::string& url) {
    if (url.compare(0, 8, "https://") != 0 && url.compare(0, 7, "http://") != 0) {
        return false;
    }
    for (char c : url) {
        if (c == '\r' || c == '\n' || static_cast<unsigned char>(c) < 0x20) {
            return false;
        }
    }
    return true;
}

std::string UrlHost(const std::string& url) {
    const size_t scheme = url.find("://");
    if (scheme == std::string::npos) return {};
    std::string h = url.substr(scheme + 3);
    // 去掉 userinfo（https://user@host/ 形式，防御性处理）。
    const size_t at = h.find('@');
    if (at != std::string::npos) h.erase(0, at + 1);
    if (!h.empty() && h[0] == '[') {
        // IPv6 字面量：[::1] 或 [::1]:port → 取括号内整体。
        const size_t rb = h.find(']');
        if (rb == std::string::npos) return {};
        h = h.substr(0, rb + 1);
    } else {
        for (size_t i = 0; i < h.size(); ++i) {
            const char c = h[i];
            if (c == '/' || c == ':' || c == '?' || c == '#' || c == '\\') {
                h.resize(i);
                break;
            }
        }
    }
    for (char& c : h) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return h;
}

bool IsLocalHost(const std::string& host) {
    if (host.empty()) return true;
    if (host == "localhost" || host == "127.0.0.1" || host == "::1" || host == "[::1]" ||
        host == "0.0.0.0")
        return true;
    if (host.compare(0, 4, "127.") == 0) return true;
    if (host.compare(0, 8, "169.254.") == 0) return true;
    return false;
}

bool UrlSafe(const std::string& url, std::size_t maxLen) {
    if (url.empty() || url.size() >= maxLen) return false;
    if (!IsHttpUrl(url)) return false;
    for (unsigned char c : url) {
        if (c == '\'' || c == '"' || c == '\\' || c == '`') return false;
    }
    if (IsLocalHost(UrlHost(url))) return false;
    return true;
}

std::string BuildUploadUrl(const std::string& base, bool eof) {
    std::string url = base;
    const std::string token = "{eof}";
    const size_t pos = url.find(token);
    if (pos != std::string::npos) {
        url.replace(pos, token.size(), eof ? "true" : "false");
        return url;
    }
    // 规范 §4.3.7.1：/api/ems/web/media/device/upload/{sn}/{taskId}/{fileType}/{eof}
    if (!url.empty() && url.back() == '/') url.pop_back();
    url += eof ? "/true" : "/false";
    return url;
}

namespace {

int HexVal(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

std::string PercentDecodeImpl(const std::string& in, bool plusAsSpace) {
    std::string out;
    out.reserve(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
        if (in[i] == '%' && i + 2 < in.size()) {
            int hi = HexVal(in[i + 1]);
            int lo = HexVal(in[i + 2]);
            if (hi >= 0 && lo >= 0) {
                out.push_back(static_cast<char>((hi << 4) | lo));
                i += 2;
                continue;
            }
        }
        if (plusAsSpace && in[i] == '+')
            out.push_back(' ');
        else
            out.push_back(in[i]);
    }
    return out;
}

}  // namespace

std::string PercentDecodeQuery(const std::string& in) {
    return PercentDecodeImpl(in, true);
}

std::string PercentDecodeRFC5987(const std::string& in) {
    return PercentDecodeImpl(in, false);
}

std::string RedactUrl(const std::string& url) {
    std::string out = url;
    const size_t q = out.find_first_of("?#");
    if (q != std::string::npos) out.resize(q);
    for (char& c : out) {
        if (c == '\r' || c == '\n' || static_cast<unsigned char>(c) < 0x20) c = '_';
    }
    return out;
}

}  // namespace util
}  // namespace emu
