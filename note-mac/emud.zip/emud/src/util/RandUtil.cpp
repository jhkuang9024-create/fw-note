#define LOG_TAG "emud"
#include "util/RandUtil.h"

#include <stdlib.h>

namespace emu {
namespace util {

std::string MakeRandomHex(std::size_t len) {
    const char* hex = "0123456789abcdef";
    std::string out(len, '0');
    for (auto& c : out) c = hex[arc4random_uniform(16)];
    return out;
}

}  // namespace util
}  // namespace emu
