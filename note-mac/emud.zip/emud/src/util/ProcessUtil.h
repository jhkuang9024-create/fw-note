// emud 公共工具层：子进程管理（exec / 终止）。
#ifndef EMU_UTIL_PROCESS_UTIL_H
#define EMU_UTIL_PROCESS_UTIL_H

#include <sys/types.h>

#include <atomic>
#include <string>
#include <vector>

namespace emu {
namespace util {

// 从 vector<string> 构建 argv（含结尾 nullptr）并 execve。
// execFailFd >= 0 时：exec 失败向该 fd 写入 1 字节通知父进程
// （fd 已设 FD_CLOEXEC：exec 成功会自动关闭写端 → 父进程读到 EOF）。
// 仅子进程调用；exec 失败写管道并 _exit(127)。
void ExecArgv(const std::vector<std::string>& args, int execFailFd = -1);

// fork + exec + 管道探测（合并 SshTunnel 两处同构实现）：
//  exec 成功 → 返回子进程 pid（写端随 exec 关闭，父进程读到 EOF）；
//  pipe/fork/exec 失败 → 自动 waitpid 回收并返回 -1。
// tag 仅用于日志前缀（如 "nmproxy" / "dropbear"）。
pid_t SpawnProbe(const std::vector<std::string>& args, const char* tag);

// 终止子进程：SIGTERM → 轮询（最多 1s）→ SIGKILL → waitpid 回收。
// 退出后 pid 置 -1；tag 仅用于日志前缀。
// （合并 SshTunnel / Capture 两处同模式实现，以 SshTunnel 版为基准）
void TerminateProcess(pid_t& pid, const char* tag);

// 执行 sh -c 命令并等待退出（非交互脚本场景）：
//  - 超过 timeoutSec（>0）或 cancel 置位时 SIGKILL 整个进程组并返回 -2（不留孙进程）；
//  - fork 失败返回 -1；正常退出返回退出码（shell 返回 127 表示命令不存在/exec 失败）。
// cancel：退出/停止信号，置位即中断等待（用于进程收尾路径）。
int ExecShellTimeout(const std::string& cmd, int timeoutSec,
                     const std::atomic<bool>* cancel = nullptr);

}  // namespace util
}  // namespace emu

#endif  // EMU_UTIL_PROCESS_UTIL_H
