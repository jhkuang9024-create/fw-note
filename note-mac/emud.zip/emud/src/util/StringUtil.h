// emud 公共工具层：字符串工具（行拆分 / taskId 校验）。
#ifndef EMU_UTIL_STRING_UTIL_H
#define EMU_UTIL_STRING_UTIL_H

#include <cstddef>
#include <string>
#include <vector>

namespace emu {
namespace util {

// 按行拆分，丢弃空行，规整 CRLF/CR 行尾。
// 复用 libbase Tokenize（合并连续分隔符、忽略首尾空行 = 丢弃空行），仅补 CR 行尾规整。
// （合并 OtaPackage / OtaPlatform 两处同逻辑实现）
std::vector<std::string> SplitHeaderLines(const std::string& headers);

// task_id 合法性：非空、长度 ≤ max_len、仅字母数字与 _-. 。
// （UpgradeFeature 用 64、CaptureLogFeature 用 80，统一实现按需传参）
bool TaskIdSafe(const std::string& id, std::size_t maxLen);

}  // namespace util
}  // namespace emu

#endif  // EMU_UTIL_STRING_UTIL_H
