#define LOG_TAG "emud"
#include "util/FsUtil.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace emu {
namespace util {

long long FreeBytes(const std::string& pathHint) {
    struct statvfs vfs;
    std::string dir = pathHint;
    size_t slash = dir.find_last_of('/');
    if (slash != std::string::npos) {
        dir.resize(slash);
    }
    if (dir.empty()) dir = "/";
    if (::statvfs(dir.c_str(), &vfs) != 0) return -1;
    return static_cast<long long>(vfs.f_bavail) * static_cast<long long>(vfs.f_frsize);
}

int MkdirP(const char* path, mode_t mode) {
    if (!path || !path[0]) return -1;
    char tmp[512];
    std::snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = std::strlen(tmp);
    if (len == 0) return -1;
    if (tmp[len - 1] == '/') tmp[len - 1] = '\0';
    for (char* p = tmp + 1; *p; ++p) {
        if (*p == '/') {
            *p = '\0';
            if (::mkdir(tmp, mode) != 0 && errno != EEXIST) return -1;
            *p = '/';
        }
    }
    if (::mkdir(tmp, mode) != 0 && errno != EEXIST) return -1;
    return 0;
}

int ListDir(const std::string& dir, std::vector<std::string>* names) {
    if (!names) return -1;
    names->clear();
    DIR* d = ::opendir(dir.c_str());
    if (!d) return -1;  // errno 由 opendir 设置，调用方可按需区分 ENOENT
    struct dirent* ent;
    while ((ent = ::readdir(d)) != nullptr) {
        const char* name = ent->d_name;
        if (!name || ::strcmp(name, ".") == 0 || ::strcmp(name, "..") == 0) continue;
        names->push_back(name);
    }
    ::closedir(d);
    return 0;
}

int WriteFileAtomic(const std::string& path, const std::string& content, mode_t mode) {
    if (path.empty()) return -1;
    const std::string tmp = path + ".tmp";
    const int fd = ::open(tmp.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, mode);
    if (fd < 0) return -1;
    size_t off = 0;
    while (off < content.size()) {
        const ssize_t w = ::write(fd, content.data() + off, content.size() - off);
        if (w < 0) {
            if (errno == EINTR) continue;
            ::close(fd);
            ::unlink(tmp.c_str());
            return -1;
        }
        off += static_cast<size_t>(w);
    }
    if (::fsync(fd) != 0 || ::close(fd) != 0) {
        ::unlink(tmp.c_str());
        return -1;
    }
    if (::rename(tmp.c_str(), path.c_str()) != 0) {
        ::unlink(tmp.c_str());
        return -1;
    }
    // fsync 父目录使 rename 落盘（断电安全）。
    const size_t slash = path.rfind('/');
    if (slash != std::string::npos) {
        const std::string dir = path.substr(0, slash);
        const int dfd = ::open(dir.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
        if (dfd >= 0) {
            ::fsync(dfd);
            ::close(dfd);
        }
    }
    return 0;
}

}  // namespace util
}  // namespace emu
