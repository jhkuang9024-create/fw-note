// emud 公共工具层：JSON 解析 / 序列化。
#ifndef EMU_UTIL_JSON_UTIL_H
#define EMU_UTIL_JSON_UTIL_H

#include <json/json.h>

#include <optional>
#include <string>

namespace emu {
namespace util {

// 解析 JSON 文本；失败返回 nullopt。
std::optional<Json::Value> ParseJson(const std::string& text);

// 序列化为紧凑单行文本（无缩进）。
std::string DumpJson(const Json::Value& v);

// 只读取值 helper（合并 Auth/Config 两套逐字重复的匿名实现）：
//  - GetString：仅字符串字段取值，缺失 / 类型不符回退 def（默认空串）。
//  - GetInt：优先数值；服务端可能以字符串下发数值（如 "mqttPort":"1883"），
//    字符串按 atoi 宽松解析；失败回退 def。
//  - GetBool：仅布尔字段取值，其余回退 def。
std::string GetString(const Json::Value& v, const std::string& key, const std::string& def = {});
int GetInt(const Json::Value& v, const std::string& key, int def);
bool GetBool(const Json::Value& v, const std::string& key, bool def);

}  // namespace util
}  // namespace emu

#endif  // EMU_UTIL_JSON_UTIL_H
