// 命令注册表：统一 Handler 模型。优先级：核心内置 → 业务域 → 配置 routes。
#ifndef EMU_COMMAND_REGISTRY_H
#define EMU_COMMAND_REGISTRY_H

#include <map>
#include <optional>
#include <string>

#include "Command.h"
#include "Config.h"

namespace emu {

class CommandRegistry {
  public:
    // 业务域注册（程序化）
    void registerHandler(const std::string& cmdType, CommandHandler h);

    // 核心内置 handler（terminal/local/get_handlers）在 Application 组装时注册
    void registerBuiltin(const std::string& cmdType, CommandHandler h);

    // 配置 routes（声明式）作为兜底
    void loadRoutes(const Config& cfg);

    // 分发：内置 → 域 → 配置路由
    std::optional<Response> dispatch(const InboundCommand& cmd) const;

  private:
    std::map<std::string, CommandHandler> mBuiltin;
    std::map<std::string, CommandHandler> mHandlers;
    std::vector<RouteConfig> mRoutes;
};

}  // namespace emu

#endif  // EMU_COMMAND_REGISTRY_H
