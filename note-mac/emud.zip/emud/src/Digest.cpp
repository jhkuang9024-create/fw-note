#include "Digest.h"

#include <openssl/sha.h>

#include <cstdio>

namespace emu {

namespace {

std::string Sha256Hex(const std::string& data) {
    unsigned char md[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(data.data()), data.size(), md);

    std::string out;
    out.reserve(SHA256_DIGEST_LENGTH * 2);
    char hex[3];
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        std::snprintf(hex, sizeof(hex), "%02x", md[i]);
        out += hex;
    }
    return out;
}

}  // namespace

std::string DigestResponse(const std::string& username, const std::string& realm,
                           const std::string& sn, const std::string& password,
                           const std::string& method, const std::string& uri,
                           const std::string& nonce, const std::string& nc,
                           const std::string& cnonce, const std::string& qop) {
    // HA1 = sha256(username:realm:sn:password)，仅此一处使用，直接内联。
    std::string h1 = Sha256Hex(username + ":" + realm + ":" + sn + ":" + password);
    std::string h2 = Sha256Hex(method + ":" + uri);
    return Sha256Hex(h1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + h2);
}

std::string ParseWwwAuthParam(const std::string& header, const std::string& key) {
    std::string k = key + "=";
    size_t pos = header.find(k);
    if (pos == std::string::npos) return {};
    pos += k.size();
    if (pos < header.size() && header[pos] == '"') {
        ++pos;
        size_t end = header.find('"', pos);
        if (end == std::string::npos) return {};
        return header.substr(pos, end - pos);
    }
    size_t end = header.find(',', pos);
    if (end == std::string::npos) end = header.size();
    std::string v = header.substr(pos, end - pos);
    while (!v.empty() && (v.front() == ' ' || v.front() == '\t')) v.erase(v.begin());
    while (!v.empty() && (v.back() == ' ' || v.back() == '\t')) v.pop_back();
    return v;
}

}  // namespace emu
