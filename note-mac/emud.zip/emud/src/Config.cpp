#define LOG_TAG "emud"
#include <log/log.h>

#include "Config.h"

#include <android-base/file.h>
#include <android-base/properties.h>
#include <cstdio>
#include <cstring>
#include <memory>
#include <sys/stat.h>

#include <json/json.h>

#include "util/JsonUtil.h"

namespace emu {

namespace {

// 读文件（失败返回空串；复用 libbase ReadFileToString）。
std::string ReadFile(const std::string& path) {
    std::string content;
    if (!android::base::ReadFileToString(path, &content)) return {};
    return content;
}

// 运行时数据首启 seed：/data/system/emud/data.json 不存在时，从
// /system/etc/emud/data.json 拷贝初始值；之后（含 OTA 后）绝不覆盖，
// 保证运行时数据跨重启保留。返回是否执行了 seed。
bool SeedDataIfMissing() {
    struct stat st;
    if (stat(kDataPath, &st) == 0) return false;  // 已存在，不覆盖
    std::string seed = ReadFile(kSystemDataSeedPath);
    if (seed.empty()) return false;
    if (!android::base::WriteStringToFile(seed, kDataPath)) {
        ALOGE("seed %s failed", kDataPath);
        return false;
    }
    ALOGI("seeded %s from %s", kDataPath, kSystemDataSeedPath);
    return true;
}

// 读系统属性（封装 android::base::GetProperty，libbase 已链接）。
std::string GetProperty(const char* key, const char* def = "") {
    return android::base::GetProperty(key, def);
}

// MAC 地址：ro.mac → /sys/class/net/eth0/address（兜底），并去掉所有冒号。
std::string ReadMacAddress() {
    std::string mac = GetProperty("ro.mac");
    if (mac.empty()) {
        FILE* fp = fopen("/sys/class/net/eth0/address", "r");
        if (fp) {
            char buf[128] = {0};
            if (fgets(buf, sizeof(buf), fp)) buf[strcspn(buf, "\r\n")] = '\0';
            mac = buf;
            fclose(fp);
        }
    }
    std::string out;
    for (char c : mac)
        if (c != ':') out += c;
    return out;
}

}  // namespace

std::optional<EventRoute> Config::findEventRoute(const std::string& eventClass) const {
    for (const auto& r : event_routes)
        if (r.event_class == eventClass) return r;
    return std::nullopt;
}

std::optional<ActionConfig> Config::findAction(const std::string& action) const {
    for (const auto& a : action_handlers)
        if (a.action == action) return a;
    return std::nullopt;
}

// 设备 ID：MAC 优先，SN 兜底
std::string DeviceId(const DeviceConfig& d) {
    return DeviceIdFrom(d.mac, d.sn);
}

std::string DeviceIdFrom(const std::string& mac, const std::string& sn) {
    return mac.empty() ? sn : mac;
}

std::optional<Config> ConfigLoad() {
    // 配置固定从 system 分区只读加载：config.json 优先，emud.json 兜底。
    std::string jsonText = ReadFile(kSystemConfigPath);
    if (jsonText.empty()) {
        jsonText = ReadFile(kSystemConfigFallbackPath);
        if (jsonText.empty()) {
            ALOGE("config.json not found (%s or %s)", kSystemConfigPath, kSystemConfigFallbackPath);
            return std::nullopt;
        }
    }
    auto root = util::ParseJson(jsonText);
    if (!root || !root->isObject()) {
        ALOGE("failed to parse config.json");
        return std::nullopt;
    }

    Config cfg;

    // 设备信息：直接读系统属性，不读取 config.json 的 device 段。
    DeviceConfig& d = cfg.device;

    d.sn = GetProperty("ro.serialno", "0123456789");
    d.mac = ReadMacAddress();
    d.model = GetProperty("ro.product.model", "TB712");
    d.vendor = GetProperty("ro.product.manufacturer");

    // firmwareVer：ro.build.display.id → 兜底 release.incremental
    d.firmware_ver = GetProperty("ro.build.version.incremental");
    if (d.firmware_ver.empty()) {
        const std::string rel = GetProperty("ro.build.version.release");
        const std::string inc = GetProperty("ro.build.version.incremental");
        if (!rel.empty() && !inc.empty())
            d.firmware_ver = rel + "." + inc;
        else if (!rel.empty())
            d.firmware_ver = rel;
        else
            d.firmware_ver = inc;
    }

    // firmwareInnerVer：incremental → fingerprint
    d.firmware_ver_inner = GetProperty("ro.build.display.id");
    if (d.firmware_ver_inner.empty()) d.firmware_ver_inner = GetProperty("ro.build.fingerprint");

    // hardwareVer
    d.hardware_ver = GetProperty("ro.boot.hardware");

    // hardwareInnerVer：revision → board.revision → hardware.version
    d.hardware_ver_inner = GetProperty("ro.boot.hardware.revision");
    if (d.hardware_ver_inner.empty()) d.hardware_ver_inner = GetProperty("ro.boot.board.revision");
    if (d.hardware_ver_inner.empty()) d.hardware_ver_inner = GetProperty("ro.soc.model");

    // carrier：ro.product.carrier → persist.sys.operator
    d.carrier = GetProperty("ro.product.carrier");
    if (d.carrier.empty()) d.carrier = GetProperty("persist.sys.operator", "CMCC");

    // province：persist.sys.province → ro.product.province
    d.province = GetProperty("persist.sys.province");
    if (d.province.empty()) d.province = GetProperty("ro.product.province");

    // netMethod：persist.sys.netmethod → ro.boot.netmode
    d.net_method = GetProperty("persist.sys.netmethod");
    if (d.net_method.empty()) d.net_method = GetProperty("ro.boot.netmode");

    // deviceType / trigger：无对应属性，固定取值。
    d.device_type = "mtv";
    d.trigger = "BOOT";

    // STB extendAttr（来源：emu_0827 同事方案；chipModel / androidVersion / stbId）
    d.chip_model = GetProperty("ro.product.cpu.info");
    d.android_version = GetProperty("ro.product.build.version.release");
    d.stb_id = GetProperty("ro.product.stb.stbid");

    ALOGI("[device] sn=%s mac=%s model=%s vendor=%s fw=%s hw=%s type=%s", d.sn.c_str(),
          d.mac.c_str(), d.model.c_str(), d.vendor.c_str(), d.firmware_ver.c_str(),
          d.hardware_ver.c_str(), d.device_type.c_str());
    ALOGI("[device] extend chipModel=%s androidVersion=%s stbId=%s", d.chip_model.c_str(),
          d.android_version.c_str(), d.stb_id.c_str());

    const Json::Value& auth = (*root)["auth"];
    cfg.auth.enable = util::GetBool(auth, "enable", true);
    cfg.auth.auth_server = util::GetString(auth, "auth_server");
    cfg.auth.digest_password = util::GetString(auth, "digest_password");
    cfg.auth.ca_cert_path = util::GetString(auth, "ca_cert_path");

    const Json::Value& subs = (*root)["subscribe_topics"];
    if (subs.isArray()) {
        for (const auto& t : subs) {
            SubscribeTopic st;
            st.topic = util::GetString(t, "topic");
            st.qos = util::GetInt(t, "qos", 1);
            cfg.subscribe_topics.push_back(st);
        }
    }

    const Json::Value& routes = (*root)["routes"];
    if (routes.isArray()) {
        for (const auto& r : routes) {
            RouteConfig rc;
            rc.cmd_type = util::GetString(r, "cmd_type");
            rc.ack_status = util::GetString(r, "ack_status");
            rc.ack_msg = util::GetString(r, "ack_msg");
            cfg.routes.push_back(rc);
        }
    }

    const Json::Value& evts = (*root)["event_routes"];
    if (evts.isArray()) {
        for (const auto& e : evts) {
            EventRoute er;
            er.event_class = util::GetString(e, "event_class");
            er.mqtt_event = util::GetString(e, "mqtt_event");
            cfg.event_routes.push_back(er);
        }
    }

    const Json::Value& actions = (*root)["action_handlers"];
    if (actions.isArray()) {
        for (const auto& a : actions) {
            ActionConfig ac;
            ac.action = util::GetString(a, "action");
            ac.handler = util::GetString(a, "handler");
            ac.command = util::GetString(a, "command");
            cfg.action_handlers.push_back(ac);
        }
    }

    cfg.get_handlers = (*root)["get_handlers"];

    // 运行时数据：独立 data.json（config.json 只读、永不写回）。
    SeedDataIfMissing();
    auto data = util::ParseJson(ReadFile(kDataPath));
    if (data && data->isObject()) cfg.data = std::move(*data);

    // 注册扩展运行时字段：data.json 优先，系统属性兜底（来源：emu_0827 同事方案）。
    // net_ip / work_mode / pppoe_acc / parent_sn 为运行时值，不读 config.json。
    if (d.net_ip.empty()) d.net_ip = util::GetString(cfg.data, "net_ip");
    if (d.work_mode.empty()) d.work_mode = util::GetString(cfg.data, "work_mode");
    if (d.pppoe_acc.empty()) d.pppoe_acc = util::GetString(cfg.data, "pppoe_acc");
    if (d.parent_sn.empty()) d.parent_sn = util::GetString(cfg.data, "parent_sn");

    return cfg;
}

}  // namespace emu
