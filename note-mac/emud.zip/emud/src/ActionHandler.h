// 内置 ActionHandler：terminal（system 命令）与 local（本地 data 读写），
// 以及 get_handlers（GET_ROBOT_* 读本地 data 字段）。
#ifndef EMU_ACTION_HANDLER_H
#define EMU_ACTION_HANDLER_H

#include <string>

#include "Command.h"
#include "CommandRegistry.h"
#include "Config.h"

namespace emu {

class ActionHandler {
  public:
    explicit ActionHandler(const Config& cfg) : mCfg(cfg) {}

    // 处理 action（terminal / local）
    std::optional<Response> handleAction(const InboundCommand& cmd);

    // 处理 GET_*（读 config.json 的 data 对象字段）
    std::optional<Response> handleGet(const InboundCommand& cmd);

    // 把内置 handler 注册进 CommandRegistry（terminal/local/get_handlers）
    void registerBuiltins(CommandRegistry& registry);

  private:
    Config mCfg;
};

}  // namespace emu

#endif  // EMU_ACTION_HANDLER_H
