// emud 入口：内嵌单进程模式（无 IPC）。
// 配置固定从 /system/etc/emud/ 只读加载，数据固定 /data/system/emud/（完全硬编码，无运行参数）。
#define LOG_TAG "emud"
#include <log/log.h>

#include <chrono>
#include <csignal>
#include <cstring>
#include <memory>
#include <string>
#include <thread>

#include "CurlHttpClient.h"
#include "trace/DiagnosticsFeature.h"
#include "nio/NioFeature.h"
#include "Framework.h"
#include "SshTunnel.h"
#include "UciMqttClient.h"
#include "upgrade/UpgradeFeature.h"
#include "trace/CaptureLogFeature.h"

namespace {

volatile std::sig_atomic_t g_stop = 0;
void OnSignal(int) {
    g_stop = 1;
}

}  // namespace

int main() {
    // 信号尽早注册：启动退避等待期间也响应 SIGTERM/SIGINT，保证可被看护/脚本正常停服。
    std::signal(SIGINT, OnSignal);
    std::signal(SIGTERM, OnSignal);

    // 真实网络链路：UciMqttClient → libmosquitto（MQTT v5）/ CurlHttpClient → libcurl。
    auto fw = emu::Framework::create(std::make_shared<emu::UciMqttClient>(),
                                     std::make_shared<emu::CurlHttpClient>());
    if (!fw) {
        ALOGE("config load failed");
        return 1;
    }

    // Feature 实例由 main 显式持有（create 返回 unique_ptr）：全部声明在 fw 之后，
    // main 返回时按逆序析构，Feature（worker 线程/回调引用 mFw）先于 Framework 销毁，
    // 消除原 registerSelf 全局自持在退出期析构顺序不确定的竞态（UAF）。
    auto upgrade = emu::upgrade::UpgradeFeature::create(*fw);
    auto sshTunnel = emu::ssh_tunnel::SshTunnelFeature::create(*fw);
    auto diagnostics = emu::diagnostics::DiagnosticsFeature::create(*fw);
    auto nio = emu::nio::NioFeature::create(*fw);
    // 抓日志域（GET_LOG_FILE）：dumpstate stream 方案，独立于 DiagnosticsFeature。
    // （来源：emu_0827 同事方案）
    auto captureLog = emu::diagnostics::CaptureLogFeature::create(*fw);

    // 启动（认证 → MQTT 连接 → 订阅/注册/心跳）：失败按斐波那契退避无限重试
    // （1,1,2,3,5,… 封顶 2h），进程保持存活——认证/MQTT 服务瞬时不可用时自动恢复，
    // 不再因冷启动抖动直接退出被看护反复拉起。信号可在任意等待段中断。
    long long delaySec = 1;
    long long prevDelaySec = 0;
    constexpr long long kMaxRetryDelaySec = 2LL * 3600;  // 退避上限 2h
    while (!g_stop) {
        if (fw->start() == 0) break;
        ALOGE("framework start failed; retry in %llds", delaySec);
        for (long long i = 0; i < delaySec && !g_stop; ++i) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        const long long next = prevDelaySec + delaySec;
        prevDelaySec = delaySec;
        delaySec = next > kMaxRetryDelaySec ? kMaxRetryDelaySec : next;
    }
    if (g_stop) {
        ALOGW("emud exit (stopped during startup retry)");
        return 0;  // 局部对象逆序析构：Feature → fw（stop() 幂等，MQTT 未连则无操作）
    }

    // 主循环：仅响应信号退出；MQTT 掉线/重连由框架断线回调编排，无需在此处理。
    while (!g_stop) {
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }

    // 先断开 MQTT（停消息回调线程）再 return：局部对象逆序析构（Feature → fw）时，
    // 不再有新入站命令触达已析构的 Feature handler（~Framework 再 stop() 为幂等空操作）。
    fw->stop();
    ALOGI("emud exit");
    return 0;
}
