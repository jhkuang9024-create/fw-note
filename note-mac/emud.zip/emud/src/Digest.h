// HTTP Digest (EMU 规范) 计算工具。
#ifndef EMU_DIGEST_H
#define EMU_DIGEST_H

#include <string>

namespace emu {

// EMU 规范 Digest:
//   HA1 = sha256(username:realm:sn:password)
//   HA2 = sha256(method:uri)
//   response = sha256(HA1:nonce:nc:cnonce:qop:HA2)
std::string DigestResponse(const std::string& username, const std::string& realm,
                           const std::string& sn, const std::string& password,
                           const std::string& method, const std::string& uri,
                           const std::string& nonce, const std::string& nc,
                           const std::string& cnonce, const std::string& qop);

// 从 WWW-Authenticate header 解析参数（realm/nonce/qop/opaque/algorithm）
std::string ParseWwwAuthParam(const std::string& header, const std::string& key);

}  // namespace emu

#endif  // EMU_DIGEST_H
