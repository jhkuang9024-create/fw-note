// 文件上传：抓包 / 抓日志 / 告警文件共用（HTTP multipart form-data）。
#ifndef EMU_FILE_UPLOAD_H
#define EMU_FILE_UPLOAD_H

#include <atomic>
#include <memory>
#include <string>

#include "HttpClient.h"

namespace emu {

// 以 multipart/form-data 上传本地文件（form 字段名 file，规范 §4.3.7.1）。
// cancel 非空时支持中途中止（置位即中断，进程收尾路径用）。
bool UploadFile(const std::shared_ptr<IHttpClient>& http, const std::string& path,
                const std::string& url, const std::atomic<bool>* cancel = nullptr);

}  // namespace emu

#endif  // EMU_FILE_UPLOAD_H
