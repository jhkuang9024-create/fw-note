// 诊断域 Feature：按 EMU管控技术规范V1 注册诊断命令。
//   GET_CAPTURE_PACKET_INTERFACE     查询支持抓包的接口列表
//   GET_CAPTURE_PACKET_FILE          下发抓包（后台抓取 → 打包 → 上传 uploadUrl）
//   GET_CAPTURE_PACKET_FILE_CANCEL   取消当前抓包
//   SET_CAPTURE_LOG                  主从设备抓日志（实时抓取 duration 秒 → 上传）
//   GET_LOG_FILE                     已移交 CaptureLogFeature（dumpstate stream 方案）
#ifndef EMU_DIAG_FEATURE_H
#define EMU_DIAG_FEATURE_H

#include <atomic>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <vector>

#include "Command.h"
#include "Framework.h"
#include "trace/Capture.h"

namespace emu {
namespace diagnostics {

class DiagnosticsFeature {
  public:
    explicit DiagnosticsFeature(Framework& fw);
    ~DiagnosticsFeature();

    // 构造 + 注册 handler；实例由调用方（main）持有，保证析构先于 Framework。
    static std::unique_ptr<DiagnosticsFeature> create(Framework& fw);

    std::optional<Response> onGetCapturePacketInterface(const InboundCommand& cmd);
    std::optional<Response> onGetCapturePacketFile(const InboundCommand& cmd);
    std::optional<Response> onGetCapturePacketFileCancel(const InboundCommand& cmd);
    std::optional<Response> onSetCaptureLog(const InboundCommand& cmd);

  private:
    // 后台任务：抓包 → 压缩打包 → 上传（规范 §4.3.2.18；CANCEL 停后仍上传已抓 pcap）
    void runCaptureTask(const std::string& taskId, const std::vector<std::string>& ifaces,
                        int packetSizeMb, int durationS, const std::string& filter,
                        const std::string& uploadUrl);
    // 后台任务：抓日志 duration 秒 → 压缩打包 → 上传（规范 §4.3.3.6）
    void runCaptureLogTask(const std::string& taskId, int durationS, const std::string& shell,
                           const std::string& uploadUrl);

    // 尝试占用后台任务槽位（同一时刻只允许一个诊断任务）。
    bool tryAcquireTask();
    void releaseTask();

    // 进程收尾：尽快结束后台任务（取消抓包 / 中断 shell / 置停止标志）并 join。
    void stop();

    // tar -czf 打包（文件可为任意绝对路径）。
    static bool buildTarGz(const std::vector<std::string>& files, const std::string& out);

    Framework& mFw;
    CaptureService mCapture;
    std::mutex mTaskMu;
    std::atomic<bool> mTaskBusy{false};
    // 当前后台槽位是否为抓包任务：GET_CAPTURE_PACKET_FILE_CANCEL 仅对抓包生效，
    // 不再误打断抓日志任务（原共享 mCancel 会串扰）。
    std::atomic<bool> mActiveCapture{false};
    // 抓包取消请求（仅 runCaptureTask 消费，任务启动时复位）。
    std::atomic<bool> mCancelCapture{false};
    // 进程收尾标志（仅 stop() 置位，不复位）：任务循环/打包/上传中断依据。
    std::atomic<bool> mStopping{false};
    std::thread mWorker;
};

}  // namespace diagnostics
}  // namespace emu

#endif  // EMU_DIAG_FEATURE_H
