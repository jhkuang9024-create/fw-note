#define LOG_TAG "emud"
#include <log/log.h>

#include "trace/FileUpload.h"

#include <fstream>

#include "util/UrlUtil.h"

namespace emu {

bool UploadFile(const std::shared_ptr<IHttpClient>& http, const std::string& path,
                const std::string& url, const std::atomic<bool>* cancel) {
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        ALOGE("[file_upload] cannot open %s", path.c_str());
        return false;
    }
    in.close();

    // multipart/form-data 上传（规范 §4.3.7.1：form 字段 file）。
    const std::string redacted = util::RedactUrl(url);
    HttpResponse resp = http->postFile(url, path, "file", {}, cancel);
    if (cancel && cancel->load()) {
        ALOGI("[file_upload] %s upload cancelled (%s)", path.c_str(), redacted.c_str());
        return false;
    }
    if (!resp.ok()) {
        // 上传 URL 常带预签名 query（签名/token），日志只留 scheme://host。
        ALOGE("[file_upload] upload %s → %s failed (http %d)", path.c_str(), redacted.c_str(),
              resp.status);
        return false;
    }
    ALOGI("[file_upload] %s → %s ok", path.c_str(), redacted.c_str());
    return true;
}

}  // namespace emu
