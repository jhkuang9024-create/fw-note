// 抓包诊断：tcpdump 子进程托管（fork + execve），输出 pcap 到诊断目录。
#define LOG_TAG "emud"
#include <log/log.h>

#include "trace/Capture.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <vector>

#include "util/FsUtil.h"
#include "util/ProcessUtil.h"

namespace emu {
namespace diagnostics {

namespace {

constexpr const char* kCaptureDir = "/data/system/emud/log";
constexpr const char* kTcpdumpPath = "/system/bin/tcpdump";

// 单接口 tcpdump 子进程：tcpdump -i <iface> -w <pcap> [opts]
// 统一走 util::SpawnProbe：exec 失败（如 tcpdump 缺失）父进程能立即感知并回收子进程，
// 不再误报“已启动”后空等（原裸 fork 无探测）。
pid_t SpawnTcpdump(const std::string& iface, const std::string& pcap, const std::string& opts) {
    std::vector<std::string> args = {kTcpdumpPath, "-i", iface, "-w", pcap};
    if (!opts.empty()) args.push_back(opts);
    return util::SpawnProbe(args, "tcpdump");
}

}  // namespace

CaptureService::~CaptureService() {
    stop();
}

bool CaptureService::start(const std::vector<std::string>& ifaces, const std::string& opts) {
    std::lock_guard<std::mutex> lk(mMu);
    if (mRunning.load() && !mPids.empty()) {
        ALOGW("[capture] already running pids=%zu", mPids.size());
        return true;
    }
    if (ifaces.empty()) {
        ALOGE("[capture] empty iface list");
        return false;
    }

    // 确保诊断目录存在（mkdir -p 语义，统一走 util::MkdirP）。
    if (util::MkdirP(kCaptureDir, 0755) != 0) {
        ALOGE("[capture] mkdir %s failed: %s", kCaptureDir, ::strerror(errno));
        return false;
    }

    mPids.clear();
    mPcapPaths.clear();
    for (size_t i = 0; i < ifaces.size(); ++i) {
        // 多接口时按接口名区分 pcap，避免互相覆盖。
        const std::string pcap = std::string(kCaptureDir) + "/capture_" +
                                 (ifaces.size() == 1 ? "packet" : ifaces[i]) + ".pcap";
        pid_t p = SpawnTcpdump(ifaces[i], pcap, opts);
        if (p < 0) break;
        mPids.push_back(p);
        mPcapPaths.push_back(pcap);
        ALOGI("[capture] started pid=%d iface=%s pcap=%s opts=%s", p, ifaces[i].c_str(),
              pcap.c_str(), opts.c_str());
    }

    if (mPids.empty()) {
        ALOGE("[capture] no tcpdump started");
        return false;
    }
    mRunning.store(true);
    return true;
}

bool CaptureService::stop() {
    if (!mRunning.load()) return false;
    terminate();
    return true;
}

std::vector<std::string> CaptureService::capturePaths() const {
    std::lock_guard<std::mutex> lk(mMu);
    return mPcapPaths;
}

void CaptureService::terminate() {
    std::lock_guard<std::mutex> lk(mMu);
    for (size_t i = 0; i < mPids.size(); ++i) {
        // tcpdump 收到 SIGTERM 后会刷新并关闭 pcap 文件。
        pid_t pid = mPids[i];
        util::TerminateProcess(pid, "capture");
        ALOGI("[capture] stopped pcap=%s", mPcapPaths[i].c_str());
    }
    mPids.clear();
    mRunning.store(false);
}

}  // namespace diagnostics
}  // namespace emu
