// 诊断域：按 EMU管控技术规范V1 实现抓包 / 抓日志 / 批量日志。
// 所有耗时操作（抓取 → tar 打包 → HTTP 上传 uploadUrl）均在后台线程执行，
// 命令同步回执"默认操作响应"（附录 A）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "trace/DiagnosticsFeature.h"

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstring>

#include "GetCapturePacketParam.pb.h"
#include "SetCaptureLog.pb.h"
#include "BusyGuard.h"
#include "trace/FileUpload.h"
#include "util/FsUtil.h"
#include "util/ProcessUtil.h"
#include "util/UrlUtil.h"

namespace emu {
namespace diagnostics {

namespace {

constexpr const char* kDiagDir = "/data/system/emud/log";
constexpr const char* kTarPath = "/system/bin/tar";
constexpr int kMaxCaptureLogSeconds = 300;  // 抓日志最大 5 分钟（规范 §4.3.3.6）
// SET_CAPTURE_LOG shell 加固（平台下发的自定义采集脚本原样执行）：
//  长度上限 + 超时强杀（不改变内容语义，防止平台误下发/异常脚本拖死诊断任务）。
constexpr size_t kMaxShellBytes = 2048;
constexpr int kShellTimeoutSec = 60;

// 删除诊断域历史产物（capture_*.pcap / capture_*.tar.gz / capturelog_*.tar.gz）。
// 任务串行（单槽位），任务开始时不存在“本任务正在写”的产物，可安全清理；
// 上次上传失败保留的现场也在此清理（现场有界保留到下一次诊断任务）。
void CleanupDiagOld() {
    std::vector<std::string> names;
    if (util::ListDir(kDiagDir, &names) != 0) return;
    for (const std::string& name : names) {
        const bool isTarGz =
                name.size() > 7 && name.compare(name.size() - 7, 7, ".tar.gz") == 0;
        const bool isPcap = name.size() > 5 && name.compare(name.size() - 5, 5, ".pcap") == 0;
        if (!isTarGz && !isPcap) continue;
        const bool isOurs = name.compare(0, 8, "capture_") == 0 ||
                            name.compare(0, 11, "capturelog_") == 0;
        if (!isOurs) continue;
        ::unlink((std::string(kDiagDir) + "/" + name).c_str());
    }
}

// 按分隔符切分（忽略空段）。
std::vector<std::string> Split(const std::string& s, char sep) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == sep) {
            if (!cur.empty()) out.push_back(cur);
            cur.clear();
        } else {
            cur.push_back(c);
        }
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

// 接口名 token 白名单：仅 alnum + _ - .（或 "any"），防 tcpdump -i 参数注入。
// （来源：emu_0827 同事方案 IfaceTokenOk）
bool IfaceTokenOk(const std::string& n) {
    if (n.empty() || n.size() >= 64) return false;
    if (n == "any") return true;
    for (unsigned char c : n) {
        if (!(std::isalnum(c) || c == '_' || c == '-' || c == '.')) return false;
    }
    return true;
}

// 接口列表：, ; | 分隔 + trim，非法 token 丢弃；空则 "any"。
// （来源：emu_0827 同事方案 splitIfaces）
std::vector<std::string> SplitIfaces(const std::string& raw) {
    std::vector<std::string> out;
    if (raw.empty()) {
        out.push_back("any");
        return out;
    }
    std::string cur;
    auto flush = [&]() {
        while (!cur.empty() && (cur.front() == ' ' || cur.front() == '\t')) cur.erase(cur.begin());
        while (!cur.empty() && (cur.back() == ' ' || cur.back() == '\t')) cur.pop_back();
        if (IfaceTokenOk(cur)) out.push_back(cur);
        cur.clear();
    };
    for (char c : raw) {
        if (c == ',' || c == ';' || c == '|') {
            flush();
        } else {
            cur.push_back(c);
        }
    }
    flush();
    if (out.empty()) out.push_back("any");
    return out;
}

// 枚举 /sys/class/net，过滤回环口。
std::vector<std::string> ListNetInterfaces() {
    std::vector<std::string> out;
    std::vector<std::string> names;
    if (util::ListDir("/sys/class/net", &names) != 0) return out;
    for (const std::string& name : names) {
        if (name == "lo") continue;
        out.push_back(name);
    }
    std::sort(out.begin(), out.end());
    return out;
}

// 目录下常规文件的绝对路径列表。
std::vector<std::string> CollectFilesInDir(const std::string& dir) {
    std::vector<std::string> out;
    std::vector<std::string> names;
    if (util::ListDir(dir, &names) != 0) return out;
    for (const std::string& name : names) {
        const std::string path = dir + "/" + name;
        struct stat st;
        if (::stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode)) out.push_back(path);
    }
    std::sort(out.begin(), out.end());
    return out;
}

// 尽力删除文件。
void RemoveFiles(const std::vector<std::string>& files) {
    for (const auto& f : files) ::unlink(f.c_str());
}

// 追加路径到去重列表。
void AppendUnique(std::vector<std::string>& dst, const std::vector<std::string>& src) {
    for (const auto& f : src) {
        if (std::find(dst.begin(), dst.end(), f) == dst.end()) dst.push_back(f);
    }
}

}  // namespace

DiagnosticsFeature::DiagnosticsFeature(Framework& fw) : mFw(fw) {}

DiagnosticsFeature::~DiagnosticsFeature() {
    stop();
}

void DiagnosticsFeature::stop() {
    mStopping.store(true);
    mCancelCapture.store(true);
    mCapture.stop();  // 终止运行中的 tcpdump，令 runCaptureTask 尽快退出
    if (mWorker.joinable()) mWorker.join();
}

std::unique_ptr<DiagnosticsFeature> DiagnosticsFeature::create(Framework& fw) {
    auto self = std::make_unique<DiagnosticsFeature>(fw);
    auto* raw = self.get();

    fw.registerCmdHandler("GET_CAPTURE_PACKET_INTERFACE", [raw](const InboundCommand& c) {
        return raw->onGetCapturePacketInterface(c);
    });
    fw.registerCmdHandler("GET_CAPTURE_PACKET_FILE", [raw](const InboundCommand& c) {
        return raw->onGetCapturePacketFile(c);
    });
    fw.registerCmdHandler("GET_CAPTURE_PACKET_FILE_CANCEL", [raw](const InboundCommand& c) {
        return raw->onGetCapturePacketFileCancel(c);
    });
    fw.registerCmdHandler("SET_CAPTURE_LOG",
                          [raw](const InboundCommand& c) { return raw->onSetCaptureLog(c); });
    // GET_LOG_FILE 已移交 CaptureLogFeature（dumpstate stream 方案），此处不再注册。
    return self;
}

bool DiagnosticsFeature::tryAcquireTask() {
    std::lock_guard<std::mutex> lk(mTaskMu);
    if (mTaskBusy.load()) return false;
    mTaskBusy.store(true);
    return true;
}

void DiagnosticsFeature::releaseTask() {
    mTaskBusy.store(false);
}

std::optional<Response> DiagnosticsFeature::onGetCapturePacketInterface(const InboundCommand& cmd) {
    (void)cmd;
    Response resp;
    resp.code = "0";
    resp.msg = "ok";
    resp.interface_list = ListNetInterfaces();
    ALOGI("[diag] GET_CAPTURE_PACKET_INTERFACE → %zu ifaces", resp.interface_list.size());
    return resp;
}

std::optional<Response> DiagnosticsFeature::onGetCapturePacketFile(const InboundCommand& cmd) {
    if (!tryAcquireTask()) {
        ALOGW("[diag] task busy, reject GET_CAPTURE_PACKET_FILE");
        return Response{"-1", "another diag task in progress"};
    }

    proto::GetCapturePacketParam req;
    if (!req.ParseFromString(cmd.payload)) {
        releaseTask();
        return Response{"-1", "invalid GetCapturePacketParam"};
    }

    const std::string taskId = req.taskid();
    // 接口名白名单净化（来源：emu_0827 同事方案 IfaceTokenOk/splitIfaces）
    const std::vector<std::string> ifaces = SplitIfaces(req.interface());
    const int packetSizeMb = req.has_packetsize() ? req.packetsize() : 0;
    int durationS = req.has_duration() ? req.duration() : 0;
    const std::string uploadUrl = req.uploadurl();

    // 包大小和时间必填一个（规范 §4.3.2.18）；都未填则默认 30 秒。
    if (packetSizeMb <= 0 && durationS <= 0) durationS = 30;

    // 上传 URL 安全校验（补丁：原实现直接 UploadFile 无校验）：
    // 仅 http/https、禁引号/反引号/反斜杠、host 非本地回环（防 SSRF）。
    if (!uploadUrl.empty() && !util::UrlSafe(uploadUrl, 2048)) {
        releaseTask();
        ALOGW("[diag] GET_CAPTURE_PACKET_FILE rejected uploadUrl");
        return Response{"-1", "illegal uploadUrl"};
    }

    // tcpdump 过滤表达式净化：protocol / port / ipProtocol 白名单化，
    // 防 tcpdump 表达式注入（来源：emu_0827 同事方案 buildTcpdumpOpts）。
    std::string filter;
    if (req.has_protocol() && !req.protocol().empty()) {
        std::vector<std::string> protos = Split(req.protocol(), ',');
        std::string expr;
        size_t used = 0;
        for (size_t i = 0; i < protos.size(); ++i) {
            std::string p = protos[i];
            for (char& c : p) {
                c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
                if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_')) c = '_';
            }
            if (p.empty() || p == "_") continue;
            if (used++) expr += " or ";
            expr += p;
        }
        if (used > 1) expr = "(" + expr + ")";
        filter = expr;
    }
    if (req.has_port() && !req.port().empty()) {
        std::string port = req.port();
        for (char& c : port) {
            if (!std::isalnum(static_cast<unsigned char>(c)) && c != ',' && c != '-' && c != '_')
                c = '_';
        }
        std::vector<std::string> ports = Split(port, ',');
        std::string expr;
        size_t used = 0;
        for (size_t i = 0; i < ports.size(); ++i) {
            if (ports[i].empty() || ports[i] == "_") continue;
            if (used++) expr += " or ";
            expr += "port " + ports[i];
        }
        if (used > 1) expr = "(" + expr + ")";
        if (!expr.empty()) {
            if (!filter.empty()) filter += " and ";
            filter += expr;
        }
    }
    if (req.has_ipprotocol() && !req.ipprotocol().empty()) {
        std::string ip = req.ipprotocol();
        std::string lower = ip;
        std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
        if (lower == "ipv4")
            ip = "ip";
        else if (lower == "ipv6")
            ip = "ip6";
        else {
            std::string cleaned;
            for (char c : lower) {
                if (std::isalnum(static_cast<unsigned char>(c)) || c == '_') cleaned += c;
            }
            ip = cleaned;
        }
        if (!ip.empty()) {
            if (!filter.empty()) filter += " and ";
            filter += ip;
        }
    }

    if (mWorker.joinable()) mWorker.join();
    mWorker = std::thread(&DiagnosticsFeature::runCaptureTask, this, taskId, ifaces, packetSizeMb,
                          durationS, filter, uploadUrl);
    return Response{"0", "ok"};
}

std::optional<Response> DiagnosticsFeature::onGetCapturePacketFileCancel(
        const InboundCommand& cmd) {
    (void)cmd;
    // 取消仅对抓包任务生效：无抓包在跑时忽略（抓日志任务不受 GET_CAPTURE_PACKET_FILE_CANCEL
    // 影响，原共享取消标志会误打断日志采集）。
    if (!mActiveCapture.load()) {
        ALOGW("[diag] cancel ignored: no active capture task");
        return Response{"0", "ok"};
    }
    mCancelCapture.store(true);
    mCapture.stop();
    return Response{"0", "ok"};
}

std::optional<Response> DiagnosticsFeature::onSetCaptureLog(const InboundCommand& cmd) {
    if (!tryAcquireTask()) {
        ALOGW("[diag] task busy, reject SET_CAPTURE_LOG");
        return Response{"-1", "another diag task in progress"};
    }

    proto::SetCaptureLog req;
    if (!req.ParseFromString(cmd.payload)) {
        releaseTask();
        return Response{"-1", "invalid SetCaptureLog"};
    }

    int durationS = req.has_duration() ? req.duration() : 30;
    if (durationS <= 0) durationS = 30;
    if (durationS > kMaxCaptureLogSeconds) durationS = kMaxCaptureLogSeconds;
    const std::string shell = req.has_shell() ? req.shell() : "";
    const std::string uploadUrl = req.has_uploadurl() ? req.uploadurl() : "";

    // 上传 URL 安全校验（补丁：原实现直接 UploadFile 无校验），空串 = 不上传，放行。
    if (!uploadUrl.empty() && !util::UrlSafe(uploadUrl, 2048)) {
        releaseTask();
        ALOGW("[diag] SET_CAPTURE_LOG rejected uploadUrl");
        return Response{"-1", "illegal uploadUrl"};
    }

    if (mWorker.joinable()) mWorker.join();
    mWorker = std::thread(&DiagnosticsFeature::runCaptureLogTask, this, req.taskid(), durationS,
                          shell, uploadUrl);
    return Response{"0", "ok"};
}

void DiagnosticsFeature::runCaptureTask(const std::string& taskId,
                                        const std::vector<std::string>& ifaces, int packetSizeMb,
                                        int durationS, const std::string& filter,
                                        const std::string& uploadUrl) {
    // 任务期声明业务占用，短连空闲租约不计时（来源：emu_0907 同事方案）
    BusyGuard busy(mFw, "capture_packet");
    // 复位取消标记：若上次 CANCEL 无任务在跑，标记会残留并污染本次抓包。
    mCancelCapture.store(false);
    mActiveCapture.store(true);

    // 清理历史诊断产物（上次任务残留 pcap/tar.gz），避免目录无限累积。
    CleanupDiagOld();

    if (ifaces.empty()) {
        ALOGE("[diag] capture no interface");
        mActiveCapture.store(false);
        releaseTask();
        return;
    }
    if (!mCapture.start(ifaces, filter)) {
        ALOGE("[diag] capture start failed");
        mActiveCapture.store(false);
        releaseTask();
        return;
    }

    // 等待：duration 秒 / pcap 总量达到 packetSize MB / 取消 / 进程停止。
    const int effectiveDuration = durationS > 0 ? durationS : 30;
    const auto begin = std::chrono::steady_clock::now();
    while (mCapture.isRunning() && !mCancelCapture.load() && !mStopping.load()) {
        const auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::seconds>(now - begin).count() >=
            effectiveDuration) {
            break;
        }
        if (packetSizeMb > 0) {
            off_t total = 0;
            for (const auto& p : mCapture.capturePaths()) {
                struct stat st;
                if (::stat(p.c_str(), &st) == 0) total += st.st_size;
            }
            if (total >= static_cast<off_t>(packetSizeMb) * 1024 * 1024) break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }

    mCapture.stop();
    mCancelCapture.store(false);
    std::vector<std::string> pcaps = mCapture.capturePaths();
    if (mStopping.load()) {
        // 进程收尾：不上传不保留，直接清理现场。
        ALOGI("[diag] capture task aborted by stop taskId=%s", taskId.c_str());
        RemoveFiles(pcaps);
        mActiveCapture.store(false);
        releaseTask();
        return;
    }

    const std::string tar = std::string(kDiagDir) + "/capture_" + taskId + ".tar.gz";
    if (!buildTarGz(pcaps, tar)) {
        ALOGE("[diag] pack pcap failed");
        RemoveFiles(pcaps);
        mActiveCapture.store(false);
        releaseTask();
        return;
    }
    RemoveFiles(pcaps);
    if (uploadUrl.empty() ||
        UploadFile(mFw.http(), tar, util::BuildUploadUrl(uploadUrl, true), &mStopping)) {
        ::unlink(tar.c_str());  // 上传成功（或无上传目标）即清理
    } else if (mStopping.load()) {
        ::unlink(tar.c_str());  // 进程收尾中断上传：现场直接清理
    } else {
        // 上传失败保留现场（下次任务 CleanupDiagOld 清理），供人工取回排查。
        ALOGE("[diag] capture upload failed, keep tar for manual fetch: %s", tar.c_str());
    }
    mActiveCapture.store(false);
    releaseTask();
    ALOGI("[diag] capture task done taskId=%s", taskId.c_str());
}

void DiagnosticsFeature::runCaptureLogTask(const std::string& taskId, int durationS,
                                           const std::string& shell, const std::string& uploadUrl) {
    // 任务期声明业务占用，短连空闲租约不计时（来源：emu_0907 同事方案）
    BusyGuard busy(mFw, "capture_log");
    // 清理历史诊断产物（含上次抓包/抓日志残留），避免目录累积。
    CleanupDiagOld();

    // 自定义日志捕获脚本：输出约定到 /data/system/emud/log（规范 §4.3.3.6 shell）。
    // 加固：长度上限（超长忽略）+ 超时强杀 + 失败告警；不改变平台下发内容语义。
    if (!shell.empty()) {
        if (shell.size() > kMaxShellBytes) {
            ALOGW("[diag] capture log shell too long (%zu bytes), ignored", shell.size());
        } else {
            ALOGI("[diag] run capture log shell: %.200s%s", shell.c_str(),
                  shell.size() > 200 ? "..." : "");
            const int rc = util::ExecShellTimeout(shell, kShellTimeoutSec, &mStopping);
            if (rc == -2)
                ALOGW("[diag] capture log shell cancelled or timed out (>%ds), killed",
                      kShellTimeoutSec);
            else if (rc != 0)
                ALOGW("[diag] capture log shell exited rc=%d", rc);
        }
    }

    // 实时抓取 duration 秒：周期收集日志文件（新增文件去重追加）。
    std::vector<std::string> collected;
    const auto begin = std::chrono::steady_clock::now();
    while (!mStopping.load()) {
        const auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::seconds>(now - begin).count() >= durationS) {
            break;
        }
        AppendUnique(collected, CollectFilesInDir(kDiagDir));
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (mStopping.load()) {
        ALOGI("[diag] capture log task aborted by stop taskId=%s", taskId.c_str());
        releaseTask();
        return;
    }

    if (collected.empty()) {
        ALOGW("[diag] capture log no files under %s", kDiagDir);
        releaseTask();
        return;
    }

    const std::string tar = std::string(kDiagDir) + "/capturelog_" + taskId + ".tar.gz";
    if (!buildTarGz(collected, tar)) {
        ALOGE("[diag] pack log failed");
        releaseTask();
        return;
    }
    // 内容已打进 tar：原始日志删除，避免跨任务重复收集与目录无限累积。
    RemoveFiles(collected);
    if (uploadUrl.empty() ||
        UploadFile(mFw.http(), tar, util::BuildUploadUrl(uploadUrl, true), &mStopping)) {
        ::unlink(tar.c_str());
    } else if (mStopping.load()) {
        ::unlink(tar.c_str());  // 进程收尾中断上传：现场直接清理
    } else {
        // 上传失败保留现场（下次任务 CleanupDiagOld 清理），供人工取回排查。
        ALOGE("[diag] capture log upload failed, keep tar for manual fetch: %s", tar.c_str());
    }
    releaseTask();
    ALOGI("[diag] capture log task done taskId=%s files=%zu", taskId.c_str(), collected.size());
}

bool DiagnosticsFeature::buildTarGz(const std::vector<std::string>& files, const std::string& out) {
    // tar -czf <out> -C / <相对路径...>（文件可为任意绝对路径）。
    std::vector<std::string> args = {kTarPath, "-czf", out, "-C", "/"};
    for (const auto& f : files) {
        std::string rel = f;
        if (!rel.empty() && rel[0] == '/') rel.erase(0, 1);
        args.push_back(rel);
    }

    pid_t p = ::fork();
    if (p < 0) {
        ALOGE("[diag] fork tar failed: %s", ::strerror(errno));
        return false;
    }
    if (p == 0) {
        // exec 失败时 util::ExecArgv 记日志并 _exit(127)；成功则进程被替换。
        // 注意 args[0] 用完整路径 kTarPath（ExecArgv 以 argv[0] 作 execve 路径，不做 PATH 搜索）。
        util::ExecArgv(args);
        _exit(127);  // 不可达，防御保留
    }
    int status = 0;
    ::waitpid(p, &status, 0);
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        ALOGE("[diag] tar %s failed status=%d", out.c_str(), status);
        return false;
    }
    ALOGI("[diag] packed %zu files → %s", files.size(), out.c_str());
    return true;
}

}  // namespace diagnostics
}  // namespace emu
