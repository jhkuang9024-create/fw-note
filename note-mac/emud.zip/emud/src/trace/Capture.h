// 抓包诊断（tcpdump 封装，子进程托管）。
#ifndef EMU_DIAG_CAPTURE_H
#define EMU_DIAG_CAPTURE_H

#include <sys/types.h>

#include <atomic>
#include <mutex>
#include <string>
#include <vector>

namespace emu {
namespace diagnostics {

// 对应管控规范 §4.3.2.18：tcpdump 为独立工具，CaptureService 以 fork + execve
// 子进程调用（RAII 生命周期，stop 时 SIGTERM → 超时 SIGKILL → waitpid 回收）。
// 支持一次抓多个接口：每个接口对应一个 tcpdump 子进程和一个 pcap 文件。
class CaptureService {
  public:
    CaptureService() = default;
    ~CaptureService();

    CaptureService(const CaptureService&) = delete;
    CaptureService& operator=(const CaptureService&) = delete;

    // ifaces 网卡名列表（如 {"eth0","wlan0"}）；opts 为附加 tcpdump 参数（可空）。
    bool start(const std::vector<std::string>& ifaces, const std::string& opts);
    bool stop();
    bool isRunning() const { return mRunning.load(); }

    // 当前抓包输出文件列表（最近一次 start 的目标 pcap，按接口顺序）。
    std::vector<std::string> capturePaths() const;

  private:
    void terminate();

    std::atomic<bool> mRunning{false};
    // pids_ / pcap_paths_ 由 start（回调线程）、terminate（回调线程）与
    // capturePaths（抓包工作线程）并发访问，需互斥保护。
    mutable std::mutex mMu;
    std::vector<std::string> mPcapPaths;
    std::vector<pid_t> mPids;
};

}  // namespace diagnostics
}  // namespace emu

#endif  // EMU_DIAG_CAPTURE_H
