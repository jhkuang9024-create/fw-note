// 抓日志域：GET_LOG_FILE（dumpstate stream + 上传）。位于 src/trace/。
// 采集：ctl.start dumpstate（-s stream）→ /dev/socket/dumpstate 直连，zip 数据流
// 在本进程内直接落盘到 /data/system/emud/bugreport（不再 fork emud_br_copy）。
// 来源：emu_0827 同事方案；解析改用本项目 protobuf-lite（GetLogFile.pb.h），
// 保留裸 wire fallback 兼容旧载荷。
#define LOG_TAG "emud"
#include <log/log.h>

#include "trace/CaptureLogFeature.h"

#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cctype>
#include <cerrno>
#include <chrono>
#include <cstring>
#include <ctime>
#include <fstream>
#include <memory>

#include <android-base/strings.h>

#include "GetLogFile.pb.h"
#include "BusyGuard.h"
#include "trace/FileUpload.h"
#include "util/FsUtil.h"
#include "util/StringUtil.h"
#include "util/UrlUtil.h"

namespace emu {
namespace diagnostics {

namespace {

constexpr const char* kLogCmd = "GET_LOG_FILE";
constexpr const char* kLogRootFixed = "/data/system/emud/bugreport";
constexpr off_t kMinZipBytes = 1024;

long long PathSize(const std::string& path) {
    struct stat st;
    if (::stat(path.c_str(), &st) != 0 || !S_ISREG(st.st_mode)) return -1;
    return static_cast<long long>(st.st_size);
}

bool ZipLooksValid(const std::string& path, std::string* err) {
    struct stat st;
    if (::stat(path.c_str(), &st) != 0) {
        if (err) *err = "stat_fail";
        return false;
    }
    if (st.st_size < kMinZipBytes) {
        if (err) *err = "empty_or_tiny";
        return false;
    }
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        if (err) *err = "open_fail";
        return false;
    }
    char mag[2] = {0, 0};
    in.read(mag, 2);
    if (in.gcount() != 2 || mag[0] != 'P' || mag[1] != 'K') {
        if (err) *err = "not_zip_magic";
        return false;
    }
    return true;
}

void DumpstateStop() {
    if (__system_property_set("ctl.stop", "dumpstate") != 0)
        ALOGD("[capturelog] result=CAPTURE ctl.stop dumpstate errno=%d", errno);
    else
        ALOGD("[capturelog] result=CAPTURE ctl.stop dumpstate");
}

int ConnectDumpstateSocket() {
    int fd = ::socket(AF_LOCAL, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_un addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_LOCAL;
    std::strncpy(addr.sun_path, "/dev/socket/dumpstate", sizeof(addr.sun_path) - 1);
    if (::connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
        ::close(fd);
        return -1;
    }
    return fd;
}

// protobuf wire helpers（裸 wire fallback，兼容旧载荷）
bool ReadVarint(const uint8_t* data, size_t len, size_t* offset, uint64_t* value) {
    *value = 0;
    int shift = 0;
    while (*offset < len) {
        uint8_t byte = data[(*offset)++];
        *value |= static_cast<uint64_t>(byte & 0x7f) << shift;
        if (!(byte & 0x80)) return true;
        shift += 7;
        if (shift > 63) return false;
    }
    return false;
}

void CopyStr(std::string* dest, const uint8_t* src, size_t n) {
    dest->assign(reinterpret_cast<const char*>(src), n);
}

// 上传 URL 追加 EOF 标志（规范 §4.3.7.1）：公共实现见 util::BuildUploadUrl。

}  // namespace

CaptureLogFeature::CaptureLogFeature(Framework& fw) : mFw(fw) {}

CaptureLogFeature::~CaptureLogFeature() {
    stop();
}

int CaptureLogFeature::init() {
    // 当前项目 config.json 无 capture_log 段：用内置默认值。
    // （来源：emu_0827 同事方案 log_min_free_mb/def/max_duration 语义）
    mLogEnable = true;
    mLogRoot = kLogRootFixed;
    if (mLogEnable) {
        (void)storeMkdir();
        mLogStop.store(false);
        mLogWorker = std::thread(&CaptureLogFeature::logWorkerLoop, this);
        ALOGD("[capturelog] result=INIT OK root=%s def_duration=%d max_duration=%d",
              mLogRoot.c_str(), mLogDefDuration, mLogMaxDuration);
    } else {
        ALOGD("[capturelog] result=INIT disabled=1");
    }
    ALOGI("[capturelog] initialized enable=%d", mLogEnable ? 1 : 0);
    return 0;
}

void CaptureLogFeature::stop() {
    mLogStop.store(true);
    mLogCv.notify_all();
    if (mLogWorker.joinable()) mLogWorker.join();
}

std::unique_ptr<CaptureLogFeature> CaptureLogFeature::create(Framework& fw) {
    auto self = std::make_unique<CaptureLogFeature>(fw);
    if (self->init() != 0) ALOGE("[capturelog] init failed");
    auto* raw = self.get();
    fw.registerCmdHandler("GET_LOG_FILE",
                          [raw](const InboundCommand& c) { return raw->onGetLogFile(c); });
    ALOGI("[capturelog] handlers registered");
    return self;
}

void CaptureLogFeature::pubCmd(const char* cmdType, const std::string& taskId, const char* status,
                               const char* msg, const std::string& corr) {
    mFw.publishCmdRespRaw(cmdType, taskId.c_str(), status, msg,
                          corr.empty() ? nullptr : corr.c_str());
}

bool CaptureLogFeature::logBusy() const {
    std::lock_guard<std::mutex> lk(mLogMu);
    return mLogBusy || mLogHasJob;
}

bool CaptureLogFeature::enqueueLog(const LogCmd& cmd) {
    std::lock_guard<std::mutex> lk(mLogMu);
    if (mLogBusy || mLogHasJob) return false;
    mLogJob = cmd;
    mLogHasJob = true;
    mLogCv.notify_one();
    return true;
}

void CaptureLogFeature::logWorkerLoop() {
    ALOGD("[capturelog] result=WORKER start");
    while (true) {
        LogCmd job;
        {
            std::unique_lock<std::mutex> lk(mLogMu);
            mLogCv.wait(lk, [this] { return mLogHasJob || mLogStop.load(); });
            if (mLogStop.load() && !mLogHasJob) break;
            job = mLogJob;
            mLogHasJob = false;
            mLogBusy = true;
        }
        // 任务期声明业务占用，短连空闲租约不计时（来源：emu_0907 同事方案）
        mFw.businessStart("get_log_file");
        ALOGD("[capturelog] result=WORKER pickup taskId=%s", job.task_id.c_str());
        runLogJob(job);
        mFw.businessEnd("get_log_file");
        {
            std::lock_guard<std::mutex> lk(mLogMu);
            mLogBusy = false;
        }
        ALOGD("[capturelog] result=WORKER idle");
    }
    ALOGD("[capturelog] result=WORKER exit");
}

bool CaptureLogFeature::storeMkdir() {
    if (util::MkdirP("/data/system/emud", 0755) != 0) {
        ALOGE("[capturelog] mkdir /data/system/emud errno=%d", errno);
        return false;
    }
    if (util::MkdirP(mLogRoot.c_str(), 0755) != 0) {
        ALOGE("[capturelog] mkdir %s errno=%d", mLogRoot.c_str(), errno);
        return false;
    }
    return true;
}

std::string CaptureLogFeature::makeStampName() {
    time_t now = ::time(nullptr);
    struct tm tm;
    ::localtime_r(&now, &tm);
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%04d%02d%02d_%02d%02d%02d.zip", tm.tm_year + 1900,
                  tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
    return buf;
}

int CaptureLogFeature::cleanupOld() {
    std::vector<std::string> names;
    if (util::ListDir(mLogRoot, &names) != 0) return 0;
    int removed = 0;
    for (const std::string& name : names) {
        if (name.empty() || name[0] == '.') continue;
        if (!android::base::EndsWith(name, ".zip") && !android::base::EndsWith(name, ".log") &&
            !android::base::EndsWith(name, ".tmp"))
            continue;
        std::string path = mLogRoot + "/" + name;
        if (::unlink(path.c_str()) == 0) ++removed;
    }
    ALOGD("[capturelog] result=CLEAN removed=%d", removed);
    return removed;
}

bool CaptureLogFeature::runBugreportz(int durationSec, const std::string& destZip,
                                      std::string* err) {
    if (err) err->clear();
    if (destZip.empty()) {
        if (err) *err = "no_dest";
        return false;
    }

    const int budget = durationSec > 0 ? durationSec : 180;
    // stream 模式：dumpstate -s 直接把 zip 数据流经 socket 推送给客户端，
    // emud 在本进程内落盘，不访问官方 bugreports 目录（无需 fork emud_br_copy）。
    if (__system_property_set("ctl.start", "dumpstate") != 0) {
        if (err) *err = "ctl_start_fail";
        return false;
    }
    ALOGD("[capturelog] result=CAPTURE start dumpstate stream budget=%ds", budget);

    int s = -1;
    for (int i = 0; i < 20; ++i) {
        s = ConnectDumpstateSocket();
        if (s >= 0) break;
        ::sleep(1);
    }
    if (s < 0) {
        DumpstateStop();
        if (err) *err = "dumpstate_socket";
        return false;
    }

    struct timeval tv;
    tv.tv_sec = budget;
    tv.tv_usec = 0;
    (void)::setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    const std::string part = destZip + ".part";
    ::unlink(part.c_str());
    FILE* out = ::fopen(part.c_str(), "wb");
    if (!out) {
        ::close(s);
        DumpstateStop();
        if (err) *err = "open_part";
        return false;
    }

    char buf[65536];
    bool bad = false;
    // 用 poll 分片等待（1s 粒度），读取期间响应停止标志，避免退出时 join 卡满 budget。
    struct pollfd pfd;
    pfd.fd = s;
    pfd.events = POLLIN;
    while (true) {
        if (mLogStop.load()) {
            if (err) *err = "stopped";
            bad = true;
            break;
        }
        const int pr = ::poll(&pfd, 1, 1000);
        if (pr < 0) {
            if (errno == EINTR) continue;
            if (err) *err = "sock_poll";
            bad = true;
            break;
        }
        if (pr == 0) continue;  // 1s 内无数据：回到循环顶部复查停止标志
        ssize_t r = ::read(s, buf, sizeof(buf));
        if (r == 0) break;  // dumpstate 传输完毕并关闭连接
        if (r < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == ETIMEDOUT) {
                if (err) *err = "timeout";
                bad = true;
                break;
            }
            if (err) *err = "sock_read";
            bad = true;
            break;
        }
        if (::fwrite(buf, 1, static_cast<size_t>(r), out) != static_cast<size_t>(r)) {
            if (err) *err = "write_part";
            bad = true;
            break;
        }
    }
    ::close(s);
    if (::fclose(out) != 0 && !bad) {
        if (err) *err = "close_part";
        bad = true;
    }
    if (bad) {
        DumpstateStop();
        ::unlink(part.c_str());
        return false;
    }

    // 校验后 rename 到最终文件（语义与原 emud_br_copy 一致）
    struct stat st;
    if (::stat(part.c_str(), &st) != 0 || st.st_size < kMinZipBytes || !ZipLooksValid(part, err)) {
        if (err && err->empty()) *err = "invalid_zip";
        DumpstateStop();
        ::unlink(part.c_str());
        return false;
    }
    ::unlink(destZip.c_str());
    if (::rename(part.c_str(), destZip.c_str()) != 0) {
        if (err) *err = "rename";
        DumpstateStop();
        ::unlink(part.c_str());
        return false;
    }

    DumpstateStop();
    ALOGD("[capturelog] result=CAPTURE path=%s bytes=%lld via=dumpstate_stream", destZip.c_str(),
          PathSize(destZip));
    return true;
}

void CaptureLogFeature::runLogJob(const LogCmd& cmd) {
    const time_t t0 = ::time(nullptr);
    const int budget = cmd.duration_sec > 0 ? cmd.duration_sec : mLogDefDuration;

    ALOGD("[capturelog] result=JOB_START taskId=%s logType=%s budget=%ds", cmd.task_id.c_str(),
          cmd.log_type.empty() ? "-" : cmd.log_type.c_str(), budget);

    if (!storeMkdir()) {
        pubCmd(kLogCmd, cmd.task_id, "-1", "mkdir_fail", cmd.corr);
        return;
    }
    cleanupOld();

    const long long freeB = util::FreeBytes(mLogRoot);
    const long long need = static_cast<long long>(mLogMinFreeMb) * 1024LL * 1024LL;
    ALOGD("[capturelog] result=SPACE free_bytes=%lld need=%lld", freeB, need);
    if (freeB >= 0 && freeB < need) {
        pubCmd(kLogCmd, cmd.task_id, "-1", "no_space", cmd.corr);
        return;
    }

    const std::string zipName = makeStampName();
    const std::string zipPath = mLogRoot + "/" + zipName;
    std::string err;
    if (!runBugreportz(budget, zipPath, &err)) {
        std::string msg = "capture:" + (err.empty() ? "fail" : err);
        pubCmd(kLogCmd, cmd.task_id, "-1", msg.c_str(), cmd.corr);
        return;
    }

    const std::string red = util::BuildUploadUrl(cmd.upload_url, true);
    ALOGD("[capturelog] result=UPLOAD start eof=1 url=%s", util::RedactUrl(red).c_str());
    if (!UploadFile(mFw.http(), zipPath, red, &mLogStop)) {
        if (mLogStop.load()) {
            // 进程收尾中断上传：不补回执，现场直接清理。
            ::unlink(zipPath.c_str());
            return;
        }
        // 上传失败保留本地 zip 现场（下次任务 cleanupOld 时清理），供人工取回排查。
        ALOGE("[capturelog] result=UPLOAD_FAIL keep=%s", zipPath.c_str());
        pubCmd(kLogCmd, cmd.task_id, "-1", "upload:fail", cmd.corr);
        return;
    }
    ::unlink(zipPath.c_str());  // 上传成功即清理本地大文件，避免在 /data 累积
    pubCmd(kLogCmd, cmd.task_id, "0", "ok", cmd.corr);
    ALOGD("[capturelog] result=DONE status=0 msg=ok zip=%s elapsed=%lds", zipName.c_str(),
          static_cast<long>(::time(nullptr) - t0));
}

bool CaptureLogFeature::parseLogCmd(const std::string& payload, const std::string& mqttCorr,
                                    LogCmd* out) {
    if (!out) return false;
    *out = LogCmd{};
    out->corr = mqttCorr;

    if (payload.size() > 8192) return false;

    if (!payload.empty()) {
        // protobuf-lite 解析优先；失败回退裸 wire（兼容旧载荷）。
        proto::GetLogFile msg;
        bool pbOk = msg.ParseFromString(payload);
        if (pbOk) {
            if (msg.has_taskid()) out->task_id = msg.taskid();
            if (msg.has_logtype()) out->log_type = msg.logtype();
            if (msg.has_uploadurl()) out->upload_url = msg.uploadurl();
        } else {
            const auto* data = reinterpret_cast<const uint8_t*>(payload.data());
            size_t pos = 0;
            const size_t len = payload.size();
            while (pos < len) {
                uint64_t tagVal = 0;
                if (!ReadVarint(data, len, &pos, &tagVal)) break;
                unsigned field = static_cast<unsigned>(tagVal >> 3);
                unsigned wt = static_cast<unsigned>(tagVal & 0x07);
                if (wt == 0) {
                    uint64_t v = 0;
                    if (!ReadVarint(data, len, &pos, &v)) return false;
                } else if (wt == 2) {
                    uint64_t slen = 0;
                    if (!ReadVarint(data, len, &pos, &slen) || pos + slen > len) return false;
                    if (field == 1)
                        CopyStr(&out->task_id, data + pos, static_cast<size_t>(slen));
                    else if (field == 2)
                        CopyStr(&out->log_type, data + pos, static_cast<size_t>(slen));
                    else if (field == 4)
                        CopyStr(&out->upload_url, data + pos, static_cast<size_t>(slen));
                    pos += static_cast<size_t>(slen);
                } else if (wt == 5) {
                    if (pos + 4 > len) return false;
                    pos += 4;
                } else if (wt == 1) {
                    if (pos + 8 > len) return false;
                    pos += 8;
                } else {
                    return false;
                }
            }
        }
    }

    for (char& c : out->log_type)
        if (static_cast<unsigned char>(c) < 0x20) c = '_';

    if (out->task_id.empty() && !out->corr.empty()) out->task_id = out->corr;
    // uploadUrl 校验收敛到 util::UrlSafe（IsHttpUrl + 禁引号/反引号/反斜杠 + 非本地 host）
    if (!util::TaskIdSafe(out->task_id, 80) || !util::UrlSafe(out->upload_url, 1000)) return false;

    out->duration_sec = mLogDefDuration;
    if (out->duration_sec > mLogMaxDuration) out->duration_sec = mLogMaxDuration;
    if (out->duration_sec < 1) out->duration_sec = 1;
    return true;
}

std::optional<Response> CaptureLogFeature::onGetLogFile(const InboundCommand& cmd) {
    Response r;
    r.msg = "__async_ack__";
    const std::string& corr = cmd.task_id;

    if (!mLogEnable) {
        pubCmd(kLogCmd, "", "-1", "capture_not_ready", corr);
        return r;
    }
    if (logBusy()) {
        pubCmd(kLogCmd, corr, "-1", "busy", corr);
        return r;
    }

    LogCmd lc;
    if (!parseLogCmd(cmd.payload, corr, &lc)) {
        pubCmd(kLogCmd, corr, "-1", "parse error", corr);
        return r;
    }

    pubCmd(kLogCmd, lc.task_id, "1", "received", lc.corr);
    if (!enqueueLog(lc)) {
        pubCmd(kLogCmd, lc.task_id, "-1", "busy", lc.corr);
        return r;
    }
    return r;
}

}  // namespace diagnostics
}  // namespace emu
