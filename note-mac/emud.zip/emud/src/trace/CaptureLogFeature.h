// 抓日志域（src/trace/）：GET_LOG_FILE = dumpstate stream（socket 直连）+ 上传。
// 来源：emu_0827 同事方案；解析改用本项目 protobuf-lite（GetLogFile.pb.h）。
#ifndef EMU_CAPTURE_LOG_FEATURE_H
#define EMU_CAPTURE_LOG_FEATURE_H

#include <atomic>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>

#include "Command.h"
#include "Framework.h"

namespace emu {
namespace diagnostics {

struct LogCmd {
    std::string task_id;
    std::string corr;
    std::string upload_url;
    std::string log_type;
    int duration_sec = 180;
};

class CaptureLogFeature {
  public:
    explicit CaptureLogFeature(Framework& fw);
    ~CaptureLogFeature();

    // 构造 + 注册 handler；实例由调用方（main）持有，保证析构先于 Framework。
    static std::unique_ptr<CaptureLogFeature> create(Framework& fw);

    std::optional<Response> onGetLogFile(const InboundCommand& cmd);

  private:
    int init();
    void stop();

    void pubCmd(const char* cmdType, const std::string& taskId, const char* status, const char* msg,
                const std::string& corr);

    void logWorkerLoop();
    void runLogJob(const LogCmd& cmd);
    bool enqueueLog(const LogCmd& cmd);
    bool logBusy() const;

    bool runBugreportz(int durationSec, const std::string& destZip, std::string* err);
    bool storeMkdir();
    int cleanupOld();
    static std::string makeStampName();
    bool parseLogCmd(const std::string& payload, const std::string& mqttCorr, LogCmd* out);

    Framework& mFw;

    bool mLogEnable = true;
    std::string mLogRoot = "/data/system/emud/bugreport";
    int mLogMinFreeMb = 64;
    int mLogDefDuration = 180;
    int mLogMaxDuration = 300;

    mutable std::mutex mLogMu;
    std::condition_variable mLogCv;
    bool mLogHasJob = false;
    bool mLogBusy = false;
    // 停止标志：logWorkerLoop 的退出条件；runBugreportz 读循环 / 上传中断也检查它。
    std::atomic<bool> mLogStop{false};
    LogCmd mLogJob;
    std::thread mLogWorker;
};

}  // namespace diagnostics
}  // namespace emu

#endif  // EMU_CAPTURE_LOG_FEATURE_H
