#define LOG_TAG "emud"
#include <log/log.h>

#include "Envelope.h"

namespace emu {

std::optional<InboundCommand> Envelope::parse(const MqttMessage& msg) {
    InboundCommand cmd;
    cmd.header = msg.header;
    cmd.cmd_type = msg.header.cmd_type;
    cmd.task_id = msg.header.correlation_data;
    cmd.payload = msg.payload;  // protobuf 二进制载荷

    if (cmd.cmd_type.empty()) {
        ALOGW("[envelope] missing cmdType in MQTT v5 header");
        return std::nullopt;
    }
    return cmd;
}

std::string Envelope::extractTaskId(const std::string& payload) {
    // JSON 载荷无统一 taskId 约定，不做解析。
    if (payload.empty() || payload[0] == '{') return {};

    // field 1 = taskId，wire type 2（string）：tag = (1 << 3) | 2 = 0x0A。
    if (static_cast<uint8_t>(payload[0]) != 0x0A) return {};

    // 读 length varint。
    size_t pos = 1;
    uint64_t len = 0;
    int shift = 0;
    while (pos < payload.size() && shift <= 63) {
        const uint8_t b = static_cast<uint8_t>(payload[pos++]);
        len |= static_cast<uint64_t>(b & 0x7f) << shift;
        if ((b & 0x80) == 0) break;
        shift += 7;
    }
    if (shift > 63 || pos + len > payload.size()) return {};
    return payload.substr(pos, static_cast<size_t>(len));
}

}  // namespace emu
