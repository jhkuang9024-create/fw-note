// nio：FileStore 实现（meta 用 jsoncpp 读写，解析/序列化统一走 util::JsonUtil）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "nio/FileStore.h"

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

#include <json/json.h>

#include "util/FsUtil.h"
#include "util/JsonUtil.h"
#include "util/UrlUtil.h"

namespace emu {
namespace nio {

namespace {

bool IsKnownType(const std::string& t) {
    return t == "QOS" || t == "VOICE_GRAMMAR" || t == "CUSTOM_TIMBRE" || t == "OTHER";
}

}  // namespace

FileStore::FileStore(NioConfig cfg) : cfg_(std::move(cfg)) {
    if (!DataRootSafe(cfg_.data_root)) cfg_.data_root = kDefaultDataRoot;
    if (cfg_.expire_days <= 0) cfg_.expire_days = kDefaultExpireDays;
    if (cfg_.min_free_mb <= 0) cfg_.min_free_mb = kDefaultMinFreeMb;
    if (cfg_.max_file_mb <= 0) cfg_.max_file_mb = kDefaultMaxFileMb;
    // 单文件上限硬顶，防止配置误设过大
    if (cfg_.max_file_mb > 512) cfg_.max_file_mb = 512;
}

int FileStore::init() {
    // mkdir -p 语义统一走 util::MkdirP（原私有 MkdirP 已收敛至 util/FsUtil）
    auto mk = [](const std::string& dir) {
        if (util::MkdirP(dir.c_str(), 0755) != 0) {
            ALOGE("[NIO] result=FAIL reason=mkdir dir=%s errno=%d", dir.c_str(), errno);
            return -1;
        }
        return 0;
    };
    if (mk(cfg_.data_root) != 0) return -1;
    if (mk(cfg_.data_root + "/QOS") != 0) return -1;
    if (mk(cfg_.data_root + "/VOICE_GRAMMAR") != 0) return -1;
    if (mk(cfg_.data_root + "/CUSTOM_TIMBRE") != 0) return -1;
    if (mk(cfg_.data_root + "/OTHER") != 0) return -1;
    if (mk(cfg_.data_root + "/.meta") != 0) return -1;
    PurgeExpired();
    ALOGI("[NIO] store ready root=%s expire_days=%d min_free_mb=%d max_file_mb=%d",
          cfg_.data_root.c_str(), cfg_.expire_days, cfg_.min_free_mb, cfg_.max_file_mb);
    return 0;
}

std::string FileStore::NormalizeType(const std::string& file_type) {
    if (IsKnownType(file_type)) return file_type;
    return "OTHER";
}

bool FileStore::TaskIdSafe(const std::string& s) {
    if (s.empty() || s.size() > 128) return false;
    for (char c : s) {
        if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '-' || c == '.'))
            return false;
    }
    if (s.find("..") != std::string::npos) return false;
    return true;
}

bool FileStore::Md5Safe(const std::string& s) {
    if (s.size() < 32 || s.size() > 64) return false;
    for (unsigned char c : s) {
        if (!std::isxdigit(c)) return false;
    }
    return true;
}

bool FileStore::DataRootSafe(const std::string& root) {
    if (root.empty() || root[0] != '/') return false;
    if (root.find("..") != std::string::npos) return false;
    // 强制落在 /data/system/emud/ 下（与 bugreport 同级的数据目录现状）
    static const char kPrefix[] = "/data/system/emud/";
    if (root.compare(0, sizeof(kPrefix) - 1, kPrefix) != 0) return false;
    if (root.size() > 256) return false;
    for (unsigned char c : root) {
        if (c < 0x20 || c == ' ' || c == '\'' || c == '"') return false;
    }
    return true;
}

namespace {

bool PathUnderDataRoot(const std::string& path, const std::string& root) {
    if (path.empty() || path[0] != '/' || root.empty()) return false;
    if (path.find("..") != std::string::npos) return false;
    if (path.compare(0, root.size(), root) != 0) return false;
    if (path.size() == root.size()) return true;
    return path[root.size()] == '/';
}

}  // namespace

bool FileStore::UrlAllowed(const std::string& url) {
    // 手写 scheme / 控制字符检查收敛到 util::IsHttpUrl（语义等价：仅 http/https 且无控制字符）。
    if (url.empty() || url.size() > 2048) return false;
    if (!util::IsHttpUrl(url)) return false;
    if (url.find("..") != std::string::npos) return false;
    return true;
}

namespace {

bool IsDangerousNameChar(unsigned char c) {
    if (c < 0x20) return true;
    switch (c) {
        case '/':
        case '\\':
        case ':':
        case '*':
        case '?':
        case '"':
        case '<':
        case '>':
        case '|':
        case '\'':
            return true;
        default:
            return false;
    }
}

std::string QueryParam(const std::string& url, const char* key) {
    auto q = url.find('?');
    if (q == std::string::npos) return {};
    const std::string query = url.substr(q + 1);
    const std::string needle = std::string(key) + "=";
    size_t p = 0;
    while (p < query.size()) {
        auto amp = query.find('&', p);
        const std::string part =
                query.substr(p, amp == std::string::npos ? std::string::npos : amp - p);
        if (part.compare(0, needle.size(), needle) == 0) {
            // query 语义：'+' 表示空格（util::PercentDecodeQuery）
            return util::PercentDecodeQuery(part.substr(needle.size()));
        }
        if (amp == std::string::npos) break;
        p = amp + 1;
    }
    return {};
}

}  // namespace

std::string FileStore::SanitizeFileName(const std::string& raw) {
    std::string s = raw;
    // basename only
    auto slash = s.find_last_of("/\\");
    if (slash != std::string::npos) s = s.substr(slash + 1);
    // strip quotes often seen in CD
    while (!s.empty() && (s.front() == '"' || s.front() == '\'')) s.erase(s.begin());
    while (!s.empty() && (s.back() == '"' || s.back() == '\'')) s.pop_back();

    std::string out;
    out.reserve(s.size());
    for (unsigned char c : s) {
        if (IsDangerousNameChar(c)) continue;
        if (c == ' ') {
            out.push_back('_');
            continue;
        }
        // 允许 ASCII 可打印与 UTF-8 高位，以保留中文原名+后缀
        out.push_back(static_cast<char>(c));
    }
    while (!out.empty() && (out.back() == '.' || out.back() == ' ' || out.back() == '_'))
        out.pop_back();
    while (!out.empty() && out.front() == '.') out.erase(out.begin());
    if (out.empty() || out == "." || out == "..") return "payload.bin";
    // 避免与临时/旁路后缀冲突（ListCompleted 会跳过 *.part / *.otherinfo）
    auto ends_with_ci = [](const std::string& s, const char* suf) {
        const size_t n = std::strlen(suf);
        if (s.size() < n) return false;
        for (size_t i = 0; i < n; ++i) {
            char a = s[s.size() - n + i];
            char b = suf[i];
            if (a >= 'A' && a <= 'Z') a = static_cast<char>(a - 'A' + 'a');
            if (b >= 'A' && b <= 'Z') b = static_cast<char>(b - 'A' + 'a');
            if (a != b) return false;
        }
        return true;
    };
    if (ends_with_ci(out, ".part") || ends_with_ci(out, ".otherinfo")) out += ".bin";
    if (out.size() > 128) {
        // 尽量保留后缀：截断 stem
        auto dot = out.find_last_of('.');
        if (dot != std::string::npos && dot > 0 && out.size() - dot <= 16) {
            const std::string ext = out.substr(dot);
            std::string stem = out.substr(0, dot);
            if (stem.size() + ext.size() > 128) {
                if (128 > ext.size())
                    stem.resize(128 - ext.size());
                else
                    stem.clear();
            }
            out = stem + ext;
        } else {
            out.resize(128);
        }
    }
    if (out.empty()) return "payload.bin";
    return out;
}

std::string FileStore::NameHintFromUrl(const std::string& url) {
    // 仅认明确的文件名参数；避免 ?name=xxx / ?file=id 误当作原名
    const char* keys[] = {"filename", "fileName", "file_name"};
    for (const char* k : keys) {
        std::string v = QueryParam(url, k);
        if (!v.empty()) return v;
    }
    std::string path = url;
    auto q = path.find('?');
    if (q != std::string::npos) path = path.substr(0, q);
    auto slash = path.find_last_of('/');
    std::string base = (slash == std::string::npos) ? path : path.substr(slash + 1);
    return base;
}

std::string FileStore::ResolveBaseName(const std::string& preferred, const std::string& http_name,
                                      const std::string& url) {
    if (!preferred.empty()) return SanitizeFileName(preferred);
    if (!http_name.empty()) return SanitizeFileName(http_name);
    return SanitizeFileName(NameHintFromUrl(url));
}

std::string FileStore::FinalPath(const NioCmd& cmd, const std::string& base_name) const {
    const std::string type = NormalizeType(cmd.file_type);
    const std::string base = SanitizeFileName(base_name);
    // 仅用原名（含后缀）；taskId 记在 .meta，不进文件名
    return cfg_.data_root + "/" + type + "/" + base;
}

std::string FileStore::FinalPath(const NioCmd& cmd) const {
    return FinalPath(cmd, ResolveBaseName(cmd.preferred_name, {}, cmd.download_url));
}

std::string FileStore::TypeDir(const NioCmd& cmd) const {
    return cfg_.data_root + "/" + NormalizeType(cmd.file_type);
}

std::string FileStore::PartPathForTask(const NioCmd& cmd) const {
    return TypeDir(cmd) + "/" + cmd.task_id + ".part";
}

std::string FileStore::MetaPath(const std::string& task_id) const {
    return cfg_.data_root + "/.meta/" + task_id + ".json";
}

// 读 meta JSON（jsoncpp）→ MetaRecord。
// 旧版（emu_0901 fprintf 手拼）meta 同为合法 JSON 且字段名一致，读取向前兼容。
bool FileStore::ReadMeta(const std::string& meta_path, MetaRecord* out) {
    if (!out) return false;
    FILE* fp = ::fopen(meta_path.c_str(), "rb");
    if (!fp) return false;
    std::string text;
    char buf[1024];
    size_t n = 0;
    while ((n = ::fread(buf, 1, sizeof(buf), fp)) > 0) text.append(buf, n);
    ::fclose(fp);
    if (text.empty()) return false;

    auto j = util::ParseJson(text);
    if (!j || !j->isObject()) return false;

    MetaRecord m;
    const Json::Value& r = *j;
    if (r["taskId"].isString()) m.task_id = r["taskId"].asString();
    if (r["fileType"].isString()) m.file_type = r["fileType"].asString();
    if (r["path"].isString()) m.path = r["path"].asString();
    if (r["md5"].isString()) m.md5 = r["md5"].asString();
    if (r["otherInfo"].isString()) m.other_info = r["otherInfo"].asString();
    if (r["mtime"].isInt64()) m.mtime = r["mtime"].asInt64();
    if (r["expireAt"].isInt64()) m.expire_at = r["expireAt"].asInt64();
    *out = std::move(m);
    return true;
}

int FileStore::RemoveByTaskId(const std::string& task_id) const {
    if (!TaskIdSafe(task_id)) return -1;
    const std::string prefix = task_id + "__";
    const std::string part_name = task_id + ".part";

    // 优先按 meta 记录的精确 path 删除（避免误删）
    MetaRecord m;
    if (ReadMeta(MetaPath(task_id), &m) && PathUnderDataRoot(m.path, cfg_.data_root)) {
        ::unlink(m.path.c_str());
        ::unlink((m.path + ".otherinfo").c_str());
        ::unlink((m.path + ".part").c_str());
    }

    const char* types[] = {"QOS", "VOICE_GRAMMAR", "CUSTOM_TIMBRE", "OTHER"};
    for (const char* type : types) {
        const std::string dir = cfg_.data_root + "/" + type;
        std::vector<std::string> names;
        if (util::ListDir(dir, &names) != 0) continue;
        for (const std::string& n : names) {
            if (n.empty() || n[0] == '.') continue;
            if (n == part_name ||
                (n.size() > prefix.size() && n.compare(0, prefix.size(), prefix) == 0)) {
                ::unlink((dir + "/" + n).c_str());
            }
        }
    }
    ::unlink(MetaPath(task_id).c_str());
    return 0;
}

int FileStore::EnsureDirs(const std::string& final_path) const {
    auto slash = final_path.find_last_of('/');
    if (slash == std::string::npos) return -1;
    const std::string dir = final_path.substr(0, slash);
    if (util::MkdirP(dir.c_str(), 0755) != 0) {
        ALOGE("[NIO] result=FAIL reason=mkdir dir=%s errno=%d", dir.c_str(), errno);
        return -1;
    }
    return 0;
}

int FileStore::WriteMeta(const NioCmd& cmd, const std::string& final_path) const {
    // 同名覆盖时清理其它 task 指向该 path 的陈旧 meta
    {
        const std::string meta_dir = cfg_.data_root + "/.meta";
        std::vector<std::string> names;
        if (util::ListDir(meta_dir, &names) == 0) {
            for (const std::string& n : names) {
                if (n.empty() || n[0] == '.') continue;
                if (n.size() < 6 || n.compare(n.size() - 5, 5, ".json") != 0) continue;
                const std::string tid = n.substr(0, n.size() - 5);
                if (tid == cmd.task_id) continue;
                MetaRecord m;
                if (ReadMeta(meta_dir + "/" + n, &m) && m.path == final_path)
                    ::unlink((meta_dir + "/" + n).c_str());
            }
        }
    }

    const time_t now = ::time(nullptr);
    const time_t expire = now + static_cast<time_t>(cfg_.expire_days) * 86400;

    // 序列化走 jsoncpp（字符串自动转义），不再手拼 JSON / 手写转义。
    Json::Value j(Json::objectValue);
    j["taskId"] = cmd.task_id;
    j["fileType"] = NormalizeType(cmd.file_type);
    j["path"] = final_path;
    // md5 仅作 meta 记录；正常已由 Md5Safe 约束为 hex，再兜底清洗非 hex 字符
    std::string md5_esc = cmd.md5;
    for (char& c : md5_esc) {
        if (!std::isxdigit(static_cast<unsigned char>(c))) c = '0';
    }
    if (md5_esc.size() > 64) md5_esc.resize(64);
    j["md5"] = md5_esc;
    j["mtime"] = static_cast<Json::Int64>(now);
    j["expireAt"] = static_cast<Json::Int64>(expire);
    // otherInfo 仅记录 ≤512（jsoncpp 自动转义，不再替换控制字符/引号/反斜杠）
    std::string oi = cmd.other_info;
    if (oi.size() > 512) oi.resize(512);
    j["otherInfo"] = oi;
    const std::string text = util::DumpJson(j);

    const std::string meta = MetaPath(cmd.task_id);
    FILE* fp = ::fopen(meta.c_str(), "wb");
    if (!fp) {
        ALOGE("[NIO] result=FAIL reason=write_meta path=%s errno=%d", meta.c_str(), errno);
        return -1;
    }
    const bool ok = ::fwrite(text.data(), 1, text.size(), fp) == text.size();
    ::fclose(fp);
    if (!ok) {
        ALOGE("[NIO] result=FAIL reason=write_meta path=%s", meta.c_str());
        ::unlink(meta.c_str());
        return -1;
    }
    return 0;
}

int FileStore::WriteOtherInfoSidecar(const std::string& final_path,
                                     const std::string& other_info) const {
    if (other_info.empty()) return 0;
    const std::string side = final_path + ".otherinfo";
    FILE* fp = ::fopen(side.c_str(), "wb");
    if (!fp) return -1;
    const size_t n = other_info.size() > 4096 ? 4096 : other_info.size();
    ::fwrite(other_info.data(), 1, n, fp);
    ::fclose(fp);
    return 0;
}

long long FileStore::MinFreeBytes() const {
    return static_cast<long long>(cfg_.min_free_mb) * 1024LL * 1024LL;
}

long long FileStore::MaxFileBytes() const {
    return static_cast<long long>(cfg_.max_file_mb) * 1024LL * 1024LL;
}

int FileStore::RemoveEntry(const Entry& e) const {
    if (!e.path.empty()) {
        if (::unlink(e.path.c_str()) == 0)
            ALOGI("[NIO] removed path=%s", e.path.c_str());
        ::unlink((e.path + ".otherinfo").c_str());
        ::unlink((e.path + ".part").c_str());
    }
    if (!e.task_id.empty()) ::unlink(MetaPath(e.task_id).c_str());
    return 0;
}

int FileStore::ListCompleted(std::vector<Entry>* out) const {
    if (!out) return -1;
    out->clear();

    // path → (taskId, expireAt)，文件名不再带 taskId（读取统一走 jsoncpp ReadMeta）
    std::vector<MetaRecord> metas;
    {
        const std::string meta_dir = cfg_.data_root + "/.meta";
        std::vector<std::string> names;
        if (util::ListDir(meta_dir, &names) == 0) {
            for (const std::string& n : names) {
                if (n.empty() || n[0] == '.') continue;
                if (n.size() < 6 || n.compare(n.size() - 5, 5, ".json") != 0) continue;
                MetaRecord m;
                if (!ReadMeta(meta_dir + "/" + n, &m) || m.path.empty()) continue;
                m.task_id = n.substr(0, n.size() - 5);  // taskId 以 meta 文件名（归属）为准
                metas.push_back(std::move(m));
            }
        }
    }

    const char* types[] = {"QOS", "VOICE_GRAMMAR", "CUSTOM_TIMBRE", "OTHER"};
    for (const char* type : types) {
        const std::string dir = cfg_.data_root + "/" + type;
        std::vector<std::string> names;
        if (util::ListDir(dir, &names) != 0) continue;
        for (const std::string& n : names) {
            if (n.empty() || n[0] == '.') continue;
            if (n.size() > 5 && n.compare(n.size() - 5, 5, ".part") == 0) continue;
            if (n.size() > 10 && n.compare(n.size() - 10, 10, ".otherinfo") == 0) continue;
            Entry e;
            e.path = dir + "/" + n;
            struct stat st;
            if (::stat(e.path.c_str(), &st) != 0 || !S_ISREG(st.st_mode)) continue;
            e.mtime = st.st_mtime;
            e.size = static_cast<long long>(st.st_size);
            e.expire_at = e.mtime + static_cast<time_t>(cfg_.expire_days) * 86400;
            // 优先 meta；兼容旧版 {taskId}__{name}
            for (const MetaRecord& h : metas) {
                if (h.path == e.path) {
                    e.task_id = h.task_id;
                    if (h.expire_at > 0) e.expire_at = static_cast<time_t>(h.expire_at);
                    break;
                }
            }
            if (e.task_id.empty()) {
                auto us = n.find("__");
                if (us != std::string::npos) e.task_id = n.substr(0, us);
            }
            out->push_back(e);
        }
    }
    return 0;
}

int FileStore::PurgeExpired() {
    std::vector<Entry> list;
    ListCompleted(&list);
    const time_t now = ::time(nullptr);
    int n = 0;
    for (const Entry& e : list) {
        if (e.expire_at > 0 && now >= e.expire_at) {
            RemoveEntry(e);
            ++n;
        }
    }
    if (n > 0) ALOGI("[NIO] purgeExpired removed=%d", n);
    return n;
}

int FileStore::EnsureSpace(const std::string& protect_task_id) {
    const long long need = MinFreeBytes();
    long long freeb = util::FreeBytes(cfg_.data_root);
    // 无法探测剩余空间时 fail-closed，避免打满磁盘
    if (freeb < 0) {
        ALOGE("[NIO] result=FAIL reason=statvfs root=%s", cfg_.data_root.c_str());
        return -1;
    }
    if (freeb >= need) return 0;

    std::vector<Entry> list;
    ListCompleted(&list);
    std::sort(list.begin(), list.end(),
              [](const Entry& a, const Entry& b) { return a.mtime < b.mtime; });

    for (const Entry& e : list) {
        if (!protect_task_id.empty() && e.task_id == protect_task_id) continue;
        RemoveEntry(e);
        freeb = util::FreeBytes(cfg_.data_root);
        if (freeb >= 0 && freeb >= need) {
            ALOGI("[NIO] ensureSpace ok free=%lld", freeb);
            return 0;
        }
    }
    freeb = util::FreeBytes(cfg_.data_root);
    if (freeb < 0 || freeb < need) {
        ALOGE("[NIO] result=FAIL reason=space_short free=%lld need=%lld", freeb, need);
        return -1;
    }
    return 0;
}

}  // namespace nio
}  // namespace emu
