// nio：SET_FILE_DOWNLOAD（平台资源文件下发：下载落盘 + 结果事件上报）。
// 来源：emu_0901 同事 file_download 域（现并入 nio）；回执/事件风格对齐本仓库升级域。
#ifndef EMU_NIO_FEATURE_H
#define EMU_NIO_FEATURE_H

#include <memory>
#include <optional>
#include <string>

#include "Command.h"
#include "NioTypes.h"
#include "NioWorker.h"
#include "Framework.h"

namespace emu {
namespace nio {

// 解析 SET_FILE_DOWNLOAD 载荷（JSON 或 protobuf，按首字节判定），做合法性归一。
// mqtt_corr：MQTT v5 correlation_data，taskId 缺失时兜底。
bool ParseSetFileDownload(const std::string& payload, const std::string& mqtt_corr,
                          NioCmd* out);

class NioFeature {
  public:
    explicit NioFeature(Framework& fw);
    ~NioFeature();

    // 构造 + 启动 worker + 注册 handler；实例由调用方（main）持有，保证析构先于 Framework。
    static std::unique_ptr<NioFeature> create(Framework& fw);

    std::optional<Response> onSetFileDownload(const InboundCommand& cmd);

  private:
    void onFileResult(const NioCmd& cmd, const std::string& status,
                      const std::string& msg);

    Framework& mFw;
    std::unique_ptr<NioWorker> mWorker;
    bool mReady = false;  // worker/store init 成功
};

}  // namespace nio
}  // namespace emu

#endif  // EMU_NIO_FEATURE_H
