// nio：SET_FILE_DOWNLOAD（平台资源文件下发：下载落盘 + 过期清理 + 磁盘保护）。
// 来源：emu_0901 同事 file_download 域（现并入 nio），移植并本地化（数据目录对齐 /data/system/emud 现状）。
#ifndef EMU_NIO_TYPES_H
#define EMU_NIO_TYPES_H

#include <string>

#ifndef EMU_NIO_EXPIRE_DAYS
#define EMU_NIO_EXPIRE_DAYS 7
#endif

namespace emu {
namespace nio {

inline constexpr const char* kCmdType = "SET_FILE_DOWNLOAD";
// 落盘根目录（沿用本仓库数据目录现状 /data/system/emud，与 bugreport 同级）。
inline constexpr const char* kDefaultDataRoot = "/data/system/emud/files";
inline constexpr int kDefaultExpireDays = EMU_NIO_EXPIRE_DAYS;
inline constexpr int kDefaultMinFreeMb = 64;
inline constexpr int kDefaultMaxFileMb = 100;
inline constexpr int kQueueSize = 4;

struct NioConfig {
    bool enable = true;
    std::string data_root = kDefaultDataRoot;
    int expire_days = kDefaultExpireDays;
    int min_free_mb = kDefaultMinFreeMb;
    int max_file_mb = kDefaultMaxFileMb;
};

struct NioCmd {
    std::string task_id;
    std::string corr;  // MQTT v5 correlation_data 回显值（可为空，用 task_id 兜底）
    std::string download_url;
    std::string md5;  // 仅作 meta 记录，本域不做内容校验（可能分片/续传场景）
    std::string file_type;   // normalized: QOS / VOICE_GRAMMAR / CUSTOM_TIMBRE / OTHER
    std::string other_info;  // 平台附带信息（≤4096），落盘为 <file>.otherinfo 旁路文件
    std::string preferred_name;  // 可选：协议/otherInfo 给出的原始文件名
    bool has_next = false;
};

}  // namespace nio
}  // namespace emu

#endif  // EMU_NIO_TYPES_H
