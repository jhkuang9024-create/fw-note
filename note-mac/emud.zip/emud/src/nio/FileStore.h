// nio：文件存储（目录布局 / 落盘 / 过期清理 / 磁盘保护 / meta 记录）。
// 来源：emu_0901 同事 file_download 域（现并入 nio） FileStore，移植并本地化日志与数据目录。
#ifndef EMU_FILE_STORE_H
#define EMU_FILE_STORE_H

#include <ctime>
#include <string>
#include <vector>

#include "nio/NioTypes.h"

namespace emu {
namespace nio {

class FileStore {
  public:
    explicit FileStore(NioConfig cfg);

    int init();
    const NioConfig& config() const { return cfg_; }

    // Normalize fileType; unknown/empty → OTHER.
    static std::string NormalizeType(const std::string& file_type);
    static bool TaskIdSafe(const std::string& s);
    static bool Md5Safe(const std::string& s);
    static bool DataRootSafe(const std::string& root);
    static bool UrlAllowed(const std::string& url);
    // 消毒 basename，保留后缀；空/非法 → payload.bin
    static std::string SanitizeFileName(const std::string& raw);
    // 从 URL path / 常见 query 取候选名（未消毒）
    static std::string NameHintFromUrl(const std::string& url);
    // 优先级：preferred → http Content-Disposition → URL → payload.bin
    static std::string ResolveBaseName(const std::string& preferred, const std::string& http_name,
                                      const std::string& url);

    // Final path under data_root/{type}/{原名}
    std::string FinalPath(const NioCmd& cmd, const std::string& base_name) const;
    // 兼容旧调用：仅用 URL 推名
    std::string FinalPath(const NioCmd& cmd) const;
    // 下载临时文件：{root}/{type}/{taskId}.part（与最终名解耦，下载中不污染正式文件）
    std::string PartPathForTask(const NioCmd& cmd) const;
    std::string TypeDir(const NioCmd& cmd) const;

    // 清理同 taskId 旧文件（换名重下时避免残留）
    int RemoveByTaskId(const std::string& task_id) const;

    int EnsureDirs(const std::string& final_path) const;
    int WriteMeta(const NioCmd& cmd, const std::string& final_path) const;
    int WriteOtherInfoSidecar(const std::string& final_path, const std::string& other_info) const;

    // Delete expired (by meta expireAt / mtime+days). Returns files removed.
    int PurgeExpired();
    // Free space until min_free; skip protect_task_id and its .part. Returns 0 if ok.
    int EnsureSpace(const std::string& protect_task_id);

    long long MinFreeBytes() const;
    long long MaxFileBytes() const;

  private:
    struct Entry {
        std::string path;
        std::string task_id;
        time_t mtime = 0;
        time_t expire_at = 0;
        long long size = 0;
    };

    // .meta/{taskId}.json 记录（jsoncpp 序列化）。
    // 字段名沿用旧 fprintf 手拼版（taskId/fileType/path/md5/mtime/expireAt/otherInfo），
    // 旧格式同为合法 JSON，读取向前兼容。
    struct MetaRecord {
        std::string task_id;
        std::string file_type;
        std::string path;
        std::string md5;
        std::string other_info;
        long long mtime = 0;
        long long expire_at = 0;
    };

    // 读 meta JSON → MetaRecord；文件缺失 / 非法返回 false。
    static bool ReadMeta(const std::string& meta_path, MetaRecord* out);

    std::string MetaPath(const std::string& task_id) const;
    int ListCompleted(std::vector<Entry>* out) const;
    int RemoveEntry(const Entry& e) const;

    NioConfig cfg_;
};

}  // namespace nio
}  // namespace emu

#endif  // EMU_FILE_STORE_H
