// nio：NioFeature 实现。
// 说明：
//   - 载荷兼容 JSON 与 protobuf（同事域实践经验：平台可能以 JSON 下发）；
//   - 回执采用本仓库同步风格：enqueue 后返回 {"1","received"}，由框架自动补发
//     SetCommonRsp（等价同事的即时 ack）；失败返回 {"-1", reason}；
//   - 下载终态经 fileDownload 事件（E_FILE_DOWNLOAD）上报，payload 复用
//     EventUpgradeRet 消息形状（sn/mac/params{taskId,status,msg}），correlation_data
//     回显下行关联 ID（与升级域 upgradeReport 同构）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "nio/NioFeature.h"

#include <string>

#include "SetFileDownload.pb.h"
#include "util/JsonUtil.h"
#include "util/UrlUtil.h"

namespace emu {
namespace nio {

namespace {

// JSON 分支（平台可能以 JSON 下发）：统一走 util::JsonUtil（jsoncpp），替换原手写字符串
// 扫描 JsonGetStr（对空白/转义/类型脆弱，且嵌套同名字段可能取错）。字段缺失保持默认。
bool ParseJsonPayload(const std::string& json, NioCmd* out) {
    auto parsed = util::ParseJson(json);
    if (!parsed || !parsed->isObject()) return false;
    const Json::Value& v = *parsed;
    const std::string url =
            util::GetString(v, "downLoadUrl", util::GetString(v, "downloadUrl"));
    if (!url.empty()) out->download_url = url;
    const std::string tid = util::GetString(v, "taskId");
    if (!tid.empty()) out->task_id = tid;
    const std::string md5 = util::GetString(v, "md5");
    if (!md5.empty()) out->md5 = md5;
    const std::string ft = util::GetString(v, "fileType");
    if (!ft.empty()) out->file_type = ft;
    const std::string oi = util::GetString(v, "otherInfo");
    if (!oi.empty()) out->other_info = oi;
    out->has_next = util::GetBool(v, "hasNext", false);
    return !out->download_url.empty();
}

bool ParsePb(const std::string& payload, NioCmd* out) {
    proto::SetFileDownload msg;
    if (!msg.ParseFromString(payload)) return false;
    out->task_id = msg.taskid();
    out->download_url = msg.downloadurl();
    out->md5 = msg.md5();
    out->file_type = msg.filetype();
    out->other_info = msg.otherinfo();
    out->has_next = msg.hasnext();
    return !out->download_url.empty();
}

}  // namespace

bool ParseSetFileDownload(const std::string& payload, const std::string& mqtt_corr,
                          NioCmd* out) {
    if (payload.empty() || !out) return false;
    *out = NioCmd{};

    bool ok = false;
    if (payload[0] == '{') {
        ok = ParseJsonPayload(payload, out);
    } else {
        ok = ParsePb(payload, out);
    }
    if (!ok) return false;

    if (out->task_id.empty() && !mqtt_corr.empty()) out->task_id = mqtt_corr;
    out->corr = !mqtt_corr.empty() ? mqtt_corr : out->task_id;
    out->file_type = FileStore::NormalizeType(out->file_type);

    if (!FileStore::TaskIdSafe(out->task_id)) {
        ALOGE("[NIO] result=FAIL step=parse reason=taskId");
        return false;
    }
    if (!FileStore::UrlAllowed(out->download_url)) {
        ALOGE("[NIO] result=FAIL step=parse reason=url url=%s",
              util::RedactUrl(out->download_url).c_str());
        return false;
    }
    // 平台可不下发 md5；格式非法时丢弃该字段不阻断下载（本域不做内容校验，仅记录）。
    if (!out->md5.empty() && !FileStore::Md5Safe(out->md5)) {
        ALOGI("[NIO] md5 ignored reason=format");
        out->md5.clear();
    }
    if (out->other_info.size() > 4096) out->other_info.resize(4096);

    // 可选原名：otherInfo JSON 或顶层 fileName（不改协议 proto）。
    if (!out->other_info.empty()) {
        auto oi = util::ParseJson(out->other_info);
        if (oi && oi->isObject()) {
            std::string fn = util::GetString(*oi, "fileName");
            if (fn.empty()) fn = util::GetString(*oi, "filename");
            if (fn.empty()) fn = util::GetString(*oi, "file_name");
            if (!fn.empty()) out->preferred_name = fn;
        }
    }
    if (out->preferred_name.empty() && payload[0] == '{') {
        auto top = util::ParseJson(payload);
        if (top && top->isObject()) {
            std::string fn = util::GetString(*top, "fileName");
            if (fn.empty()) fn = util::GetString(*top, "filename");
            if (!fn.empty()) out->preferred_name = fn;
        }
    }
    if (!out->preferred_name.empty()) {
        out->preferred_name = FileStore::SanitizeFileName(out->preferred_name);
        if (out->preferred_name == "payload.bin") out->preferred_name.clear();
    }

    ALOGI("[NIO] parsed taskId=%s type=%s url=%s hasNext=%d md5=%d name=%s",
          out->task_id.c_str(), out->file_type.c_str(),
          util::RedactUrl(out->download_url).c_str(), out->has_next ? 1 : 0,
          out->md5.empty() ? 0 : 1,
          out->preferred_name.empty() ? "-" : out->preferred_name.c_str());
    return true;
}

NioFeature::NioFeature(Framework& fw) : mFw(fw) {
    NioConfig cfg;  // 默认：enable=true / root=/data/system/emud/files（硬编码见 Types.h）
    mWorker = std::make_unique<NioWorker>(cfg);
    if (mWorker->start([this](const NioCmd& c, const std::string& s,
                              const std::string& m) { onFileResult(c, s, m); }) != 0) {
        ALOGE("[NIO] result=FAIL step=init");
        mWorker.reset();
        return;
    }
    // 文件下载执行期对连接工作模式声明占用（来源：emu_0907 同事方案）
    mWorker->setBusyCallback([this](bool busy) {
        if (busy)
            mFw.businessStart("file_download");
        else
            mFw.businessEnd("file_download");
    });
    mReady = true;
    ALOGI("[NIO] initialized root=%s", cfg.data_root.c_str());
}

NioFeature::~NioFeature() = default;

std::unique_ptr<NioFeature> NioFeature::create(Framework& fw) {
    auto self = std::make_unique<NioFeature>(fw);
    auto* raw = self.get();
    fw.registerCmdHandler(kCmdType,
                          [raw](const InboundCommand& c) { return raw->onSetFileDownload(c); });
    return self;
}

std::optional<Response> NioFeature::onSetFileDownload(const InboundCommand& cmd) {
    if (!mReady || !mWorker) {
        return Response{"-1", "file download disabled"};
    }

    NioCmd fcmd;
    if (!ParseSetFileDownload(cmd.payload, cmd.task_id, &fcmd)) {
        ALOGE("[NIO] result=FAIL step=parse corr=%s", cmd.task_id.c_str());
        return Response{"-1", "parse error"};
    }

    if (fcmd.has_next) {
        // 同 SET_UPGRADE：多包级联（hasNext=true）暂未实现，仅告警不阻断当前包。
        ALOGW("[NIO] task=%s hasNext=true: multi-package cascade not implemented, "
              "follow-up packages will be ignored",
              fcmd.task_id.c_str());
    }

    ALOGI("[NIO] result=RX taskId=%s type=%s", fcmd.task_id.c_str(),
          fcmd.file_type.c_str());

    const int enq = mWorker->enqueue(fcmd);
    if (enq < 0) {
        // 队列满 / 未运行：同步回执 -1/busy（事件通道异步可能迟到）。
        return Response{"-1", "busy"};
    }
    if (enq == 0) {
        // duplicate：不重复入队，但仍回 received（幂等 ack），终态事件以首次为准。
        ALOGI("[NIO] duplicate taskId=%s no_re-enqueue", fcmd.task_id.c_str());
    }

    // 记录下行 correlation_data，供 fileDownload 事件回显对账（与升级域同构）。
    mFw.correlation().put(fcmd.task_id, cmd.task_id);
    return Response{"1", "received"};
}

void NioFeature::onFileResult(const NioCmd& cmd, const std::string& status,
                                       const std::string& msg) {
    // 终态经 fileDownload 事件（E_FILE_DOWNLOAD）上报；路由判断与对账缓存清理
    // 统一走 Framework helper（构造 / 回显 / 清理语义与升级域同构）。
    mFw.publishTaskEvent("fileDownload", cmd.task_id, status, msg, true);
}

}  // namespace nio
}  // namespace emu
