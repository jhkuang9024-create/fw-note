// nio：HttpFileFetcher 实现（libcurl）。
// 来源：emu_0901 同事 file_download 域（现并入 nio）；含协议白名单（防 file:// 及重定向逃逸）、
// 单文件大小中止（写回调 + Content-Length 预检双保险）、Content-Disposition 文件名提取。
#define LOG_TAG "emud"
#include <log/log.h>

#include "nio/HttpFileFetcher.h"

#include <cctype>
#include <cstdio>
#include <cstring>
#include <string>
#include <unistd.h>

#include <curl/curl.h>

#include "util/UrlUtil.h"

namespace emu {
namespace nio {

namespace {

struct DlCtx {
    FILE* fp = nullptr;
    long long written = 0;
    long long max_bytes = 0;
    int too_large = 0;
    int aborted = 0;
    std::atomic<bool>* cancel = nullptr;
    std::string* out_filename = nullptr;
};

// 从 Content-Disposition 提取 filename / filename*
bool ParseContentDispositionFilename(const char* line, size_t len, std::string* out) {
    if (!line || !out || len < 20) return false;
    // Content-Disposition: ...
    static const char kPrefix[] = "content-disposition:";
    const size_t plen = sizeof(kPrefix) - 1;
    if (len < plen) return false;
    for (size_t i = 0; i < plen; ++i) {
        if (std::tolower(static_cast<unsigned char>(line[i])) != kPrefix[i]) return false;
    }
    std::string hdr(line + plen, line + len);
    while (!hdr.empty() && (hdr.back() == '\r' || hdr.back() == '\n')) hdr.pop_back();

    // Prefer RFC5987 filename*=
    auto star = hdr.find("filename*=");
    if (star == std::string::npos) star = hdr.find("FILENAME*=");
    if (star != std::string::npos) {
        std::string v = hdr.substr(star + 10);
        auto sc = v.find(';');
        if (sc != std::string::npos) v = v.substr(0, sc);
        while (!v.empty() && (v.front() == ' ' || v.front() == '\t' || v.front() == '"'))
            v.erase(v.begin());
        while (!v.empty() && (v.back() == ' ' || v.back() == '"' || v.back() == ';')) v.pop_back();
        // charset'lang'value
        auto q1 = v.find('\'');
        if (q1 != std::string::npos) {
            auto q2 = v.find('\'', q1 + 1);
            if (q2 != std::string::npos) v = v.substr(q2 + 1);
        }
        // RFC5987 filename*：'+' 是字面量，保留（util::PercentDecodeRFC5987）
        v = util::PercentDecodeRFC5987(v);
        if (!v.empty()) {
            *out = v;
            return true;
        }
    }

    auto pos = hdr.find("filename=");
    if (pos == std::string::npos) {
        // case-insensitive scan；跳过 filename*=
        for (size_t i = 0; i + 9 <= hdr.size(); ++i) {
            if (std::tolower(static_cast<unsigned char>(hdr[i])) != 'f' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 1])) != 'i' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 2])) != 'l' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 3])) != 'e' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 4])) != 'n' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 5])) != 'a' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 6])) != 'm' ||
                std::tolower(static_cast<unsigned char>(hdr[i + 7])) != 'e')
                continue;
            if (i + 8 < hdr.size() && hdr[i + 8] == '*') continue;  // filename*=
            if (i + 8 < hdr.size() && hdr[i + 8] == '=') {
                pos = i;
                break;
            }
        }
    }
    if (pos == std::string::npos) return false;
    std::string v = hdr.substr(pos + 9);
    auto sc = v.find(';');
    if (sc != std::string::npos) v = v.substr(0, sc);
    while (!v.empty() && (v.front() == ' ' || v.front() == '\t')) v.erase(v.begin());
    if (!v.empty() && v.front() == '"') {
        v.erase(v.begin());
        auto endq = v.find('"');
        if (endq != std::string::npos) v = v.substr(0, endq);
    } else {
        while (!v.empty() && (v.back() == ' ' || v.back() == '\r' || v.back() == '\n')) v.pop_back();
    }
    if (v.empty()) return false;
    *out = v;
    return true;
}

size_t WriteCb(void* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* ctx = static_cast<DlCtx*>(userdata);
    if (!ctx || !ctx->fp) return 0;
    const size_t nbytes = size * nmemb;
    if (ctx->max_bytes > 0 && ctx->written + static_cast<long long>(nbytes) > ctx->max_bytes) {
        ctx->too_large = 1;
        return 0;
    }
    size_t n = fwrite(ptr, size, nmemb, ctx->fp);
    if (n == nmemb) ctx->written += static_cast<long long>(nbytes);
    return n;
}

size_t HeaderCb(char* buffer, size_t size, size_t nitems, void* userdata) {
    auto* ctx = static_cast<DlCtx*>(userdata);
    const size_t total = size * nitems;
    if (!ctx || !buffer || total == 0) return total;
    if (ctx->out_filename) {
        std::string name;
        if (ParseContentDispositionFilename(buffer, total, &name) && !name.empty()) {
            if (name.size() > 256) name.resize(256);
            *ctx->out_filename = name;  // 重定向后以最后一次为准
        }
    }
    return total;
}

int XferInfoCb(void* p, curl_off_t, curl_off_t, curl_off_t, curl_off_t) {
    auto* ctx = static_cast<DlCtx*>(p);
    if (!ctx) return 1;
    if (ctx->cancel && ctx->cancel->load()) {
        ctx->aborted = 1;
        return 1;
    }
    return 0;
}

}  // namespace

int FetchHttpFile(const FetchReq& req) {
    if (req.url.empty() || req.dest_part.empty()) return -1;
    if (!util::IsHttpUrl(req.url)) return -1;  // 手写 scheme 检查收敛到 util（含控制字符拒绝）

    ::unlink(req.dest_part.c_str());
    FILE* fp = ::fopen(req.dest_part.c_str(), "wb");
    if (!fp) {
        ALOGE("[NIO] result=FAIL reason=open_part path=%s", req.dest_part.c_str());
        return -1;
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        ::fclose(fp);
        ::unlink(req.dest_part.c_str());
        ALOGE("[NIO] result=FAIL reason=curl_init");
        return -1;
    }

    DlCtx ctx;
    ctx.fp = fp;
    ctx.max_bytes = req.max_bytes;
    ctx.cancel = req.cancel;
    ctx.out_filename = req.out_filename;

    curl_easy_setopt(curl, CURLOPT_URL, req.url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 5L);
    // 禁止 file:// / dict:// 等协议及重定向逃逸
    curl_easy_setopt(curl, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, HeaderCb);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 30L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 600L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "emud-file-download/1.0");
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, XferInfoCb);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);

    CURLcode rc = curl_easy_perform(curl);
    long http = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http);
    double clen = -1;
    curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD, &clen);
    curl_easy_cleanup(curl);
    ::fclose(fp);

    if (ctx.aborted) {
        ::unlink(req.dest_part.c_str());
        return -2;
    }
    if (ctx.too_large) {
        ::unlink(req.dest_part.c_str());
        ALOGE("[NIO] result=FAIL reason=too_large written=%lld max=%lld", ctx.written,
              req.max_bytes);
        return -3;
    }
    if (req.max_bytes > 0 && clen > 0 && static_cast<long long>(clen) > req.max_bytes) {
        ::unlink(req.dest_part.c_str());
        return -3;
    }
    if (rc != CURLE_OK) {
        ALOGE("[NIO] result=FAIL reason=curl err=%s http=%ld", curl_easy_strerror(rc), http);
        ::unlink(req.dest_part.c_str());
        return -1;
    }
    if (http > 0 && http / 100 != 2) {
        ALOGE("[NIO] result=FAIL reason=http_status code=%ld", http);
        ::unlink(req.dest_part.c_str());
        return -1;
    }
    if (ctx.written <= 0) {
        ::unlink(req.dest_part.c_str());
        ALOGE("[NIO] result=FAIL reason=empty_body");
        return -1;
    }
    if (req.out_filename && !req.out_filename->empty()) {
        ALOGI("[NIO] download ok bytes=%lld cd_name=%s", ctx.written,
              req.out_filename->c_str());
    } else {
        ALOGI("[NIO] download ok bytes=%lld", ctx.written);
    }
    return 0;
}

}  // namespace nio
}  // namespace emu
