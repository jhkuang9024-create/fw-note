// nio：NioWorker（单线程消费 + 固定大小队列 + 重复任务去重）。
#ifndef EMU_NIO_WORKER_H
#define EMU_NIO_WORKER_H

#include <atomic>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <string>
#include <thread>

#include "nio/NioTypes.h"
#include "nio/FileStore.h"

namespace emu {
namespace nio {

// 结果回调：status "0"=成功 / "-1"=失败（msg 附原因）。
using NioListener =
        std::function<void(const NioCmd& cmd, const std::string& status,
                           const std::string& msg)>;

class NioWorker {
  public:
    explicit NioWorker(NioConfig cfg);
    ~NioWorker();

    NioWorker(const NioWorker&) = delete;
    NioWorker& operator=(const NioWorker&) = delete;

    // 启动 worker（内含 FileStore init：建目录 + purge 过期）；0=ok，-1=store init 失败。
    int start(NioListener listener);
    // 取消 in-flight 并停线程；幂等，可在析构中自动调用。
    void stop();

    // 1=new, 0=duplicate (in-flight or queued), -1=queue full
    int enqueue(const NioCmd& cmd);

    // 业务占用回调（来源：emu_0907 同事方案）：消费任务期间保持短连在线。
    using BusyFn = std::function<void(bool busy)>;
    void setBusyCallback(BusyFn fn) { busy_fn_ = std::move(fn); }

  private:
    void workerMain();
    void runOne(const NioCmd& cmd);
    void notifyResult(const NioCmd& cmd, const std::string& status,
                      const std::string& msg);

    FileStore store_;
    NioCmd queue_[kQueueSize];
    int head_ = 0;
    int tail_ = 0;
    int count_ = 0;
    std::mutex mu_;
    std::condition_variable cv_;
    bool running_ = false;
    std::atomic<bool> cancel_{false};
    std::thread worker_;

    // in-flight task_id（去重 + EnsureSpace 保护）
    std::string active_task_id_;

    NioListener listener_;
    BusyFn busy_fn_;
};

}  // namespace nio
}  // namespace emu

#endif  // EMU_NIO_WORKER_H
