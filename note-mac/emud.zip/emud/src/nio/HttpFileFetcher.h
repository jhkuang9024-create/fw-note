// nio：HTTP 文件下载器（libcurl，单次拉取）。
#ifndef EMU_HTTP_FILE_FETCHER_H
#define EMU_HTTP_FILE_FETCHER_H

#include <atomic>
#include <string>

namespace emu {
namespace nio {

struct FetchReq {
    std::string url;
    std::string dest_part;  // write to .part
    long long max_bytes = 0;
    std::atomic<bool>* cancel = nullptr;
    // 可选：填入响应 Content-Disposition 中的 filename（未消毒）
    std::string* out_filename = nullptr;
};

// 0=ok, -1=http/io, -2=cancel, -3=too_large
int FetchHttpFile(const FetchReq& req);

}  // namespace nio
}  // namespace emu

#endif  // EMU_HTTP_FILE_FETCHER_H
