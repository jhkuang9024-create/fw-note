// nio：NioWorker 实现（队列去重 + 单线程顺序消费）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "nio/NioWorker.h"

#include <cerrno>
#include <cstdio>
#include <cstring>
#include <unistd.h>

#include "nio/HttpFileFetcher.h"
#include "util/UrlUtil.h"

namespace emu {
namespace nio {

namespace {

const char* TypeOf(const NioCmd& cmd) {
    const std::string& t = cmd.file_type;
    if (t == "QOS") return "QOS";
    if (t == "VOICE_GRAMMAR") return "VOICE_GRAMMAR";
    if (t == "CUSTOM_TIMBRE") return "CUSTOM_TIMBRE";
    return "OTHER";
}

}  // namespace

NioWorker::NioWorker(NioConfig cfg) : store_(std::move(cfg)) {}

NioWorker::~NioWorker() { stop(); }

int NioWorker::start(NioListener listener) {
    std::lock_guard<std::mutex> lk(mu_);
    if (running_) return 0;
    if (store_.init() != 0) {
        ALOGE("[NIO] result=FAIL reason=store_init");
        return -1;
    }
    listener_ = std::move(listener);
    cancel_.store(false);
    running_ = true;
    worker_ = std::thread([this] { workerMain(); });
    ALOGI("[NIO] worker started");
    return 0;
}

void NioWorker::stop() {
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!running_) return;
        running_ = false;
    }
    cancel_.store(true);
    cv_.notify_all();
    if (worker_.joinable()) worker_.join();
    ALOGI("[NIO] worker stopped");
}

int NioWorker::enqueue(const NioCmd& cmd) {
    std::lock_guard<std::mutex> lk(mu_);
    if (!running_) {
        ALOGI("[NIO] result=SKIP reason=not_running task=%s", cmd.task_id.c_str());
        return -1;
    }
    if (!cmd.task_id.empty() && cmd.task_id == active_task_id_) {
        ALOGI("[NIO] result=SKIP reason=in_flight task=%s", cmd.task_id.c_str());
        return 0;
    }
    for (int i = 0; i < count_; ++i) {
        const int idx = (head_ + i) % kQueueSize;
        if (queue_[idx].task_id == cmd.task_id) {
            ALOGI("[NIO] result=SKIP reason=queued task=%s", cmd.task_id.c_str());
            return 0;
        }
    }
    if (count_ >= kQueueSize) {
        ALOGI("[NIO] result=FAIL reason=queue_full task=%s", cmd.task_id.c_str());
        return -1;
    }
    queue_[tail_] = cmd;
    tail_ = (tail_ + 1) % kQueueSize;
    ++count_;
    cv_.notify_all();
    // 下载 URL 可能带预签名 query，日志只留 scheme://host（与其它域一致）。
    ALOGI("[NIO] enqueue ok task=%s type=%s url=%s", cmd.task_id.c_str(),
          TypeOf(cmd), util::RedactUrl(cmd.download_url).c_str());
    return 1;
}

void NioWorker::workerMain() {
    for (;;) {
        NioCmd cmd;
        {
            std::unique_lock<std::mutex> lk(mu_);
            cv_.wait(lk, [this] { return !running_ || count_ > 0; });
            if (!running_ && count_ == 0) break;
            cmd = queue_[head_];
            head_ = (head_ + 1) % kQueueSize;
            --count_;
            active_task_id_ = cmd.task_id;
        }
        // 任务处理期间声明业务占用（来源：emu_0907 同事方案）
        if (busy_fn_) busy_fn_(true);
        runOne(cmd);
        if (busy_fn_) busy_fn_(false);
        {
            std::lock_guard<std::mutex> lk(mu_);
            active_task_id_.clear();
        }
        cancel_.store(false);
    }
}

void NioWorker::runOne(const NioCmd& cmd) {
    const std::string task = cmd.task_id;
    const std::string type = TypeOf(cmd);

    ALOGI("[NIO] begin task=%s type=%s", task.c_str(), type.c_str());
    if (store_.PurgeExpired() < 0) ALOGE("[NIO] purgeExpired warn");
    if (store_.EnsureSpace(task) != 0) {
        notifyResult(cmd, "-1", "no_space");
        return;
    }

    // 同 task 旧残留清理
    store_.RemoveByTaskId(task);

    const std::string base0 = FileStore::ResolveBaseName(cmd.preferred_name, "", cmd.download_url);
    const std::string final0 = store_.FinalPath(cmd, base0);
    if (store_.EnsureDirs(final0) != 0) {
        notifyResult(cmd, "-1", "mkdir_fail");
        return;
    }
    const std::string part = store_.PartPathForTask(cmd);

    std::string http_name;
    FetchReq req;
    req.url = cmd.download_url;
    req.dest_part = part;
    req.max_bytes = store_.MaxFileBytes();
    req.cancel = &cancel_;
    req.out_filename = &http_name;
    const int rc = FetchHttpFile(req);

    if (rc == -3) {
        notifyResult(cmd, "-1", "file_too_large");
        return;
    }
    if (rc == -2) {
        ALOGI("[NIO] cancelled task=%s", task.c_str());
        notifyResult(cmd, "-1", "cancelled");
        return;
    }
    if (rc != 0) {
        notifyResult(cmd, "-1", "http_error");
        return;
    }

    // Content-Disposition 名优先级：preferred > CD > URL
    std::string base = base0;
    std::string final = final0;
    if (!http_name.empty()) {
        base = FileStore::ResolveBaseName(cmd.preferred_name, http_name, cmd.download_url);
        final = store_.FinalPath(cmd, base);
        if (final != final0 && store_.EnsureDirs(final) != 0) {
            notifyResult(cmd, "-1", "mkdir_fail");
            return;
        }
    }

    if (::rename(part.c_str(), final.c_str()) != 0) {
        ALOGE("[NIO] result=FAIL reason=rename task=%s errno=%d", task.c_str(), errno);
        ::unlink(part.c_str());
        notifyResult(cmd, "-1", "rename_fail");
        return;
    }

    if (store_.WriteMeta(cmd, final) != 0) {
        notifyResult(cmd, "-1", "meta_fail");
        return;
    }
    store_.WriteOtherInfoSidecar(final, cmd.other_info);

    ALOGI("[NIO] done task=%s path=%s", task.c_str(), final.c_str());
    notifyResult(cmd, "0", "ok");
}

void NioWorker::notifyResult(const NioCmd& cmd, const std::string& status,
                                      const std::string& msg) {
    ALOGI("[NIO] result task=%s status=%s msg=%s", cmd.task_id.c_str(), status.c_str(),
          msg.c_str());
    if (listener_) listener_(cmd, status, msg);
}

}  // namespace nio
}  // namespace emu
