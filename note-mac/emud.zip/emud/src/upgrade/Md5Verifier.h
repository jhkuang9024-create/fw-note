// 升级包 MD5 校验（OpenSSL libcrypto）。
#ifndef EMU_UPGRADE_MD5_VERIFIER_H
#define EMU_UPGRADE_MD5_VERIFIER_H

#include <string>

#include "upgrade/Pipeline.h"

namespace emu {
namespace upgrade {

class Md5Verifier : public IVerifier {
  public:
    bool verify(const std::string& localPath, const std::string& md5) override;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_MD5_VERIFIER_H
