// 升级包 MD5 校验实现（OpenSSL MD5）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/Md5Verifier.h"

#include <ctype.h>
#include <stdio.h>

#include <openssl/md5.h>

namespace emu {
namespace upgrade {

namespace {

int Md5File(const std::string& path, char* outHex, size_t outSz) {
    if (path.empty() || !outHex || outSz < 33) return -1;
    FILE* fp = fopen(path.c_str(), "rb");
    if (!fp) return -1;
    MD5_CTX ctx;
    MD5_Init(&ctx);
    unsigned char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) MD5_Update(&ctx, buf, n);
    fclose(fp);
    unsigned char dig[MD5_DIGEST_LENGTH];
    MD5_Final(dig, &ctx);
    for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
        snprintf(outHex + i * 2, outSz - static_cast<size_t>(i * 2), "%02x", dig[i]);
    }
    outHex[32] = '\0';
    return 0;
}

bool HexEqCi(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); i++) {
        if (tolower(static_cast<unsigned char>(a[i])) !=
            tolower(static_cast<unsigned char>(b[i]))) {
            return false;
        }
    }
    return true;
}

}  // namespace

bool Md5Verifier::verify(const std::string& localPath, const std::string& md5) {
    if (md5.empty()) {
        ALOGI("[verifier] empty md5, skip");
        return true;
    }
    char got[40];
    if (Md5File(localPath, got, sizeof(got)) != 0) return false;
    if (!HexEqCi(got, md5)) {
        ALOGE("[verifier] md5 mismatch got=%s expected=%s", got, md5.c_str());
        return false;
    }
    ALOGI("[verifier] md5 ok");
    return true;
}

}  // namespace upgrade
}  // namespace emu
