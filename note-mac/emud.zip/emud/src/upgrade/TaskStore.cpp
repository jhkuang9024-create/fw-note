#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/TaskStore.h"

#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <utility>

#include "util/FsUtil.h"
#include "util/JsonUtil.h"

namespace emu {
namespace upgrade {

const char* StateName(State s) {
    switch (s) {
        case State::Idle:
            return "IDLE";
        case State::Accepted:
            return "ACCEPTED";
        case State::Downloading:
            return "DOWNLOADING";
        case State::Downloaded:
            return "DOWNLOADED";
        case State::Verifying:
            return "VERIFYING";
        case State::Applying:
            return "APPLYING";
        case State::PendingReboot:
            return "PENDING_REBOOT";
        case State::Success:
            return "SUCCESS";
        case State::Failed:
            return "FAILED";
    }
    return "UNKNOWN";
}

TaskStore::TaskStore(const std::string& root) : mRoot(root) {
    std::string tasks = mRoot + "/tasks";
    std::string pkgs = mRoot + "/packages";
    ::mkdir(mRoot.c_str(), 0755);
    ::mkdir(tasks.c_str(), 0755);
    ::mkdir(pkgs.c_str(), 0755);
}

std::string TaskStore::taskPath(const std::string& taskId) const {
    return mRoot + "/tasks/" + taskId + ".json";
}

bool TaskStore::save(const Task& t) {
    Json::Value j(Json::objectValue);
    j["taskId"] = t.task_id;
    j["upgUrl"] = t.upg_url;
    j["md5"] = t.md5;
    j["hasNext"] = t.has_next;
    j["traffic"] = t.traffic;
    j["state"] = static_cast<int>(t.state);
    j["localPath"] = t.local_path;
    j["lastStatus"] = t.last_status;
    j["lastMsg"] = t.last_msg;
    j["failCode"] = t.fail_code;

    // 原子落盘（tmp + fsync + rename + 目录 fsync）：状态机每次迁移都写这里，
    // 直写覆盖遇断电会截断 JSON，重启后 load 失败恢复逻辑失灵。
    if (util::WriteFileAtomic(taskPath(t.task_id), util::DumpJson(j)) != 0) {
        ALOGE("[task_store] cannot write %s", taskPath(t.task_id).c_str());
        return false;
    }
    return true;
}

std::optional<Task> TaskStore::load(const std::string& taskId) const {
    std::ifstream in(taskPath(taskId));
    if (!in) return std::nullopt;
    std::ostringstream ss;
    ss << in.rdbuf();
    auto j = util::ParseJson(ss.str());
    if (!j) return std::nullopt;
    const Json::Value& v = *j;

    Task t;
    if (v["taskId"].isString()) t.task_id = v["taskId"].asString();
    if (v["upgUrl"].isString()) t.upg_url = v["upgUrl"].asString();
    if (v["md5"].isString()) t.md5 = v["md5"].asString();
    if (v["hasNext"].isBool()) t.has_next = v["hasNext"].asBool();
    if (v["traffic"].isString()) t.traffic = v["traffic"].asString();
    if (v["state"].isNumeric()) t.state = static_cast<State>(v["state"].asInt());
    if (v["localPath"].isString()) t.local_path = v["localPath"].asString();
    if (v["lastStatus"].isString()) t.last_status = v["lastStatus"].asString();
    if (v["lastMsg"].isString()) t.last_msg = v["lastMsg"].asString();
    if (v["failCode"].isNumeric()) t.fail_code = v["failCode"].asInt();
    return t;
}

std::vector<Task> TaskStore::listIncomplete() const {
    std::vector<Task> out;
    std::string tasksDir = mRoot + "/tasks";
    std::vector<std::string> names;
    if (util::ListDir(tasksDir, &names) != 0) return out;
    for (const std::string& name : names) {
        if (name.size() < 6 || name.compare(name.size() - 5, 5, ".json") != 0) continue;
        std::string id = name.substr(0, name.size() - 5);
        auto t = load(id);
        if (t && t->state != State::Success) out.push_back(std::move(*t));
    }
    return out;
}

}  // namespace upgrade
}  // namespace emu
