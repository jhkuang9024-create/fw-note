// OTA 升级包解析：A/B OTA zip（payload.bin + payload_properties.txt）或裸 payload。
#ifndef EMU_UPGRADE_OTA_PACKAGE_H
#define EMU_UPGRADE_OTA_PACKAGE_H

#include <cstdint>
#include <string>
#include <vector>

namespace emu {
namespace upgrade {

// 解析结果：A/B OTA zip 中 payload.bin 的字节偏移/大小 + payload_properties.txt 的
// "KEY=VALUE" 行（update_engine 校验 payload 需要 FILE_HASH / FILE_SIZE /
// METADATA_HASH / METADATA_SIZE）。裸 payload 文件时 offset=0、size=文件大小。
struct OtaPackageInfo {
    int64_t payload_offset = 0;
    int64_t payload_size = 0;
    std::vector<std::string> headers;  // 每个元素一条 "KEY=VALUE"
    bool is_zip = false;
};

class OtaPackage {
  public:
    // 解析 |packagePath| 并填充 |out|。返回 0 成功，负值失败。
    // 不提取（可能数 GB 的）payload，仅记录 zip 内偏移供 update_engine 就地读取。
    static int parse(const std::string& packagePath, OtaPackageInfo* out);

    // 把 headers 行重新拼成单行\n分隔的字符串（供 UpdateEngineClient 拆行）。
    static std::string joinHeaders(const std::vector<std::string>& headers);
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_OTA_PACKAGE_H
