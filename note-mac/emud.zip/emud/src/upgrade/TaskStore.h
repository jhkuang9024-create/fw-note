// 升级任务持久化（契约字段名 / state 枚举）。
#ifndef EMU_UPGRADE_TASK_STORE_H
#define EMU_UPGRADE_TASK_STORE_H

#include <optional>
#include <string>
#include <vector>

namespace emu {
namespace upgrade {

// 状态枚举顺序（持久化数值稳定，不得调整）
enum class State {
    Idle = 0,
    Accepted,
    Downloading,
    Downloaded,
    Verifying,
    Applying,
    PendingReboot,
    Success,
    Failed
};

const char* StateName(State s);

struct Task {
    std::string task_id;
    std::string upg_url;
    std::string md5;
    bool has_next = false;
    std::string traffic;
    State state = State::Idle;
    std::string local_path;
    std::string last_status;
    std::string last_msg;
    int fail_code = 0;
};

class TaskStore {
  public:
    explicit TaskStore(const std::string& root);  // root 如 /data/system/emud/upgrade

    bool save(const Task& t);
    std::optional<Task> load(const std::string& taskId) const;
    std::vector<Task> listIncomplete() const;

    std::string taskPath(const std::string& taskId) const;
    std::string root() const { return mRoot; }

  private:
    std::string mRoot;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_TASK_STORE_H
