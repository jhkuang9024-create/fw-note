// 真实升级执行器实现。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/UpdateEngineApplier.h"

#include "upgrade/OtaPackage.h"
#include "upgrade/OtaPlatform.h"

namespace emu {
namespace upgrade {

int UpdateEngineApplier::apply(const std::string& localPath, const std::string& taskId) {
    if (localPath.empty() || taskId.empty()) {
        ALOGE("[applier] empty path/task_id");
        return -1;
    }

    // 1. 解析升级包：A/B OTA zip（payload.bin + payload_properties.txt）或裸 payload。
    OtaPackageInfo info;
    if (OtaPackage::parse(localPath, &info) != 0) {
        ALOGE("[applier] failed to parse package %s", localPath.c_str());
        return -1;
    }

    // 2. headers 重新拼成 \n 分隔文本，交给平台侧再次拆行。
    std::string headers = OtaPackage::joinHeaders(info.headers);

    // 3. 平台 AB 应用：boot mask + pending + update_engine binder。
    //    返回 0 = stub 成功（无需重启）；1 = 应用成功，需重启；-1 = 失败。
    int rc = OtaPlatform::applyAbUpdate(taskId, localPath, info.payload_offset, info.payload_size,
                                        headers);
    ALOGI("[applier] apply result=%d (zip=%d offset=%lld size=%lld)", rc, info.is_zip ? 1 : 0,
          static_cast<long long>(info.payload_offset), static_cast<long long>(info.payload_size));
    return rc;
}

}  // namespace upgrade
}  // namespace emu
