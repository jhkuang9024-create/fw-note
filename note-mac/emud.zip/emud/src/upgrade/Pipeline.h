// 升级执行原语：Downloader / Verifier / Applier 抽象。
// 真实实现：CurlDownloader（libcurl 断点续传）/ Md5Verifier（OpenSSL MD5）/
// UpdateEngineApplier（libziparchive 解析 OTA 包 + update_engine stable binder 应用）。
#ifndef EMU_UPGRADE_PIPELINE_H
#define EMU_UPGRADE_PIPELINE_H

#include <memory>
#include <string>

namespace emu {
namespace upgrade {

// 下载：把 URL 下载到本地路径；traffic 为限速（如 "10M" 表示 10MB/min，0/空不限速）
class IDownloader {
  public:
    virtual ~IDownloader() = default;
    virtual bool download(const std::string& url, const std::string& localPath,
                          const std::string& traffic) = 0;
};

// 校验：校验本地包（md5 等）
class IVerifier {
  public:
    virtual ~IVerifier() = default;
    virtual bool verify(const std::string& localPath, const std::string& md5) = 0;
};

// 应用：执行 OTA（调用 update_engine / 本地刷写）。
// 返回值：<0 失败；0 成功（无需重启，如 stub 模式）；1 成功且需重启切换槽位。
class IApplier {
  public:
    virtual ~IApplier() = default;
    virtual int apply(const std::string& localPath, const std::string& taskId) = 0;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_PIPELINE_H
