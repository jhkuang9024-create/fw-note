// 升级包下载器（libcurl）：断点续传 / 重试 / 卡死检测 / 限速 / 磁盘空间检查。
#ifndef EMU_UPGRADE_OTA_DOWNLOADER_H
#define EMU_UPGRADE_OTA_DOWNLOADER_H

#include <string>

#include "upgrade/Pipeline.h"

namespace emu {
namespace upgrade {

class CurlDownloader : public IDownloader {
  public:
    // traffic 形如 "10M"（10MB/min），atoi 取整；0/空表示不限速。
    bool download(const std::string& url, const std::string& localPath,
                  const std::string& traffic) override;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_OTA_DOWNLOADER_H
