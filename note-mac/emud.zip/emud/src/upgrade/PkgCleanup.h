// 升级包目录空间管理：下载前清理、空间保证、任务包删除。
#ifndef EMU_UPGRADE_PKG_CLEANUP_H
#define EMU_UPGRADE_PKG_CLEANUP_H

#include <string>

namespace emu {
namespace upgrade {

// 包目录固定为 /data/system/emud/upgrade/packages（TaskStore::kPackageDir）。
class PkgCleanup {
  public:
    static constexpr const char* kPackageDir = "/data/system/emud/upgrade/packages";

    // 下载前清理：删除目录下所有 .bin / .tmp 文件，保留 |keep|（本次任务）与
    // |protect|（排他保护，多任务互不干扰；传 nullptr 表示无）。
    static int beforeDownload(const std::string* keep, const std::string* protect);

    // 保证目录至少有 |needBytes| 空闲；不足时先清理再复查。
    // |keep| / |protect| 同 beforeDownload。
    static int ensureSpace(const std::string& pathHint, long long needBytes,
                           const std::string* keep, const std::string* protect);

    // 删除某个任务的包文件（<taskId>.bin 及 .bin.tmp）。
    // taskId 必须合法（无 / \ ..），否则拒绝。
    static int removeTask(const std::string& taskId);
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_PKG_CLEANUP_H
