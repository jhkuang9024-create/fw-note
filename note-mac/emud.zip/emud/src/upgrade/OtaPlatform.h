// 平台 OTA 集成：boot mask / pending 落盘、TR069 忙检查、AB 升级应用、重启。
#ifndef EMU_UPGRADE_OTA_PLATFORM_H
#define EMU_UPGRADE_OTA_PLATFORM_H

#include <cstdint>
#include <string>

namespace emu {
namespace upgrade {

class OtaPlatform {
  public:
    static constexpr const char* kDataRoot = "/data/system/emud/upgrade";
    static constexpr const char* kBootMaskPath = "/data/system/emud/upgrade/boot_mask";
    static constexpr const char* kPendingPath = "/data/system/emud/upgrade/pending_task";

    static int setBootMask(int mask);
    static int getBootMask();
    static int clearBootMask();
    static int savePending(const std::string& taskId, const std::string& path);
    static int loadPending(std::string* taskId, std::string* path);
    static void clearPending();

    // TR069 / 系统升级占中时拒绝新任务。
    static bool tr069Busy();

    // 应用 AB 升级：
    //  返回 0  = stub 模式（EMU_OTA_MODE=stub，跳过真实安装）；
    //  返回 1  = 已应用到 inactive 槽位，需要重启切换；
    //  返回 -1 = 失败（并清理 boot mask / pending）。
    static int applyAbUpdate(const std::string& taskId, const std::string& packagePath,
                             int64_t payloadOffset, int64_t payloadSize,
                             const std::string& headers);

    // AB 升级成功后触发普通重启切换槽位。
    static int rebootNormal();

    // 读取上次 AB 安装结果（检查 update_engine 的 rollback-happened 标记）。
    // 0 = 成功或未尝试，负值 = 回滚（升级失败）。
    static int readLastInstallResult();
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_OTA_PLATFORM_H
