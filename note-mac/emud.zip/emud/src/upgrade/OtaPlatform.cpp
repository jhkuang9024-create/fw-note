// 平台 OTA 集成实现。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/OtaPlatform.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <android-base/properties.h>

#include <string>
#include <vector>

#include "upgrade/UpdateEngineClient.h"
#include "util/FsUtil.h"
#include "util/StringUtil.h"

namespace emu {
namespace upgrade {

namespace {

constexpr const char* kRollbackHappenedPref = "/data/misc/update_engine/prefs/rollback-happened";

void MkdirRoot() {
    ::mkdir(OtaPlatform::kDataRoot, 0755);
}

}  // namespace

int OtaPlatform::setBootMask(int mask) {
    MkdirRoot();
    // 原子写：boot mask 在 apply 前/后由 Recovery 读取，半写内容会被误判。
    if (util::WriteFileAtomic(kBootMaskPath, std::to_string(mask) + "\n") != 0) {
        ALOGE("[ota_platform] write boot_mask failed");
        return -1;
    }
    ALOGI("[ota_platform] boot_mask=%d", mask);
    return 0;
}

int OtaPlatform::getBootMask() {
    FILE* fp = fopen(kBootMaskPath, "r");
    if (!fp) return 0;
    int m = 0;
    if (fscanf(fp, "%d", &m) != 1) m = 0;
    fclose(fp);
    return m;
}

int OtaPlatform::clearBootMask() {
    unlink(kBootMaskPath);
    return 0;
}

int OtaPlatform::savePending(const std::string& taskId, const std::string& path) {
    MkdirRoot();
    // 原子写：pending 记录在 apply 前落盘、重启后据此继续/回滚，不能半写。
    if (util::WriteFileAtomic(kPendingPath, taskId + "\n" + path + "\n") != 0) {
        ALOGE("[ota_platform] save pending failed");
        return -1;
    }
    return 0;
}

int OtaPlatform::loadPending(std::string* taskId, std::string* path) {
    if (!taskId || !path) return -1;
    FILE* fp = fopen(kPendingPath, "r");
    if (!fp) return -1;
    char line1[128] = {0}, line2[512] = {0};
    if (!fgets(line1, sizeof(line1), fp)) {
        fclose(fp);
        return -1;
    }
    fgets(line2, sizeof(line2), fp);
    fclose(fp);
    size_t n1 = strlen(line1);
    if (n1 && line1[n1 - 1] == '\n') line1[n1 - 1] = '\0';
    size_t n2 = strlen(line2);
    if (n2 && line2[n2 - 1] == '\n') line2[n2 - 1] = '\0';
    *taskId = line1;
    *path = line2;
    return 0;
}

void OtaPlatform::clearPending() {
    unlink(kPendingPath);
}

bool OtaPlatform::tr069Busy() {
    // 系统侧升级占中标记。
    if (android::base::GetProperty("sys.upgrade.router.status", "") == "1") {
        ALOGW("[ota_platform] TR069/sys.upgrade busy (router)");
        return true;
    }
    if (android::base::GetProperty("sys.upgrade.stb.status", "") == "1") {
        ALOGW("[ota_platform] TR069/sys.upgrade busy (stb)");
        return true;
    }
    return false;
}

int OtaPlatform::applyAbUpdate(const std::string& taskId, const std::string& packagePath,
                               int64_t payloadOffset, int64_t payloadSize,
                               const std::string& headers) {
    if (packagePath.empty()) return -1;
    if (packagePath.find('\n') != std::string::npos ||
        packagePath.find('\r') != std::string::npos) {
        ALOGE("[ota_platform] illegal path characters");
        return -1;
    }
    if (access(packagePath.c_str(), R_OK) != 0) {
        ALOGE("[ota_platform] package not readable: %s", packagePath.c_str());
        return -1;
    }

    // stub 模式：跳过真实安装（开发/测试）。
    const char* mode = getenv("EMU_OTA_MODE");
    if (mode && strcmp(mode, "stub") == 0) {
        ALOGI("[ota_platform] EMU_OTA_MODE=stub — skip real install");
        return 0;
    }

    std::vector<std::string> headerList = util::SplitHeaderLines(headers);

    if (setBootMask(0x02) != 0) return -1;
    if (savePending(taskId, packagePath) != 0) {
        clearBootMask();
        return -1;
    }

    ALOGI("[ota_platform] applying AB update via update_engine binder "
          "(offset=%lld size=%lld headers=%zu)",
          static_cast<long long>(payloadOffset), static_cast<long long>(payloadSize),
          headerList.size());

    int rc = ApplyUpdateEngine(
            packagePath, payloadOffset, payloadSize, headerList, [](float progress) {
                ALOGI("[ota_platform] progress %.1f%%", static_cast<double>(progress) * 100.0);
            });
    if (rc != 0) {
        ALOGE("[ota_platform] update_engine apply failed (%d)", rc);
        clearBootMask();
        clearPending();
        return -1;
    }

    // AB 升级已应用到 inactive 槽位，调用方应重启切换槽位。
    ALOGI("[ota_platform] AB update complete, ready for reboot");
    return 1;
}

int OtaPlatform::rebootNormal() {
    ALOGI("[ota_platform] triggering normal reboot for AB slot switch");
    sync();
    if (!android::base::SetProperty("sys.powerctl", "reboot")) {
        ALOGE("[ota_platform] setprop sys.powerctl reboot failed");
        return -1;
    }
    return 1;
}

int OtaPlatform::readLastInstallResult() {
    // AB 升级：检查 update_engine 的 rollback-happened 标记。
    // 存在 → 上次 AB 升级失败并回滚；不存在 → 成功（或未尝试）。
    if (access(kRollbackHappenedPref, F_OK) == 0) {
        ALOGE("[ota_platform] last AB install failed (rollback detected)");
        return -1;
    }
    ALOGI("[ota_platform] last AB install appears successful (no rollback)");
    return 0;
}

}  // namespace upgrade
}  // namespace emu
