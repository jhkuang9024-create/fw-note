// 升级域 Feature：注册 SET_UPGRADE 命令处理，驱动 FSM 并上报结果。
#ifndef EMU_UPGRADE_FEATURE_H
#define EMU_UPGRADE_FEATURE_H

#include <memory>
#include <optional>

#include "Command.h"
#include "Framework.h"
#include "upgrade/TaskStore.h"
#include "upgrade/UpgradeFsm.h"

namespace emu {
namespace upgrade {

class UpgradeFeature {
  public:
    explicit UpgradeFeature(Framework& fw);
    ~UpgradeFeature();

    // 构造 + 注册 handler；实例由调用方（main）持有，保证析构先于 Framework。
    static std::unique_ptr<UpgradeFeature> create(Framework& fw);

    std::optional<Response> onSetUpgrade(const InboundCommand& cmd);

  private:
    void onReport(const Task& t);

    Framework& mFw;
    std::unique_ptr<TaskStore> mStore;
    std::unique_ptr<UpgradeFsm> mFsm;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_FEATURE_H
