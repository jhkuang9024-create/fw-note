// 升级状态机：单 worker 线程，按 State 枚举顺序驱动任务，并上报状态变更。
#ifndef EMU_UPGRADE_FSM_H
#define EMU_UPGRADE_FSM_H

#include <atomic>
#include <condition_variable>
#include <functional>
#include <memory>
#include <mutex>
#include <queue>
#include <thread>

#include "upgrade/Pipeline.h"
#include "upgrade/TaskStore.h"

namespace emu {
namespace upgrade {

class UpgradeFsm {
  public:
    UpgradeFsm(std::shared_ptr<IDownloader> dl, std::shared_ptr<IVerifier> vf,
               std::shared_ptr<IApplier> ap, TaskStore* store);
    ~UpgradeFsm();

    // 入队任务（异步处理）
    void enqueue(Task t);

    // 同步跑完一个任务（测试 / 简化场景）
    void runSync(Task t);

    // 启动恢复：上次 AB 升级成功后把 pending 任务标记 SUCCESS，并清理
    // boot mask / pending；把崩溃遗留的中间状态任务标记 FAILED。
    void recover();

    int pendingCount() const;
    void signalStop();

    using ReportFn = std::function<void(const Task&)>;
    void setReportCallback(ReportFn fn) { mReport = std::move(fn); }

    // 业务占用回调（来源：emu_0907 同事方案）：worker 处理任务期间保持短连在线，
    // 避免升级长任务中途被空闲租约下线。
    using BusyFn = std::function<void(bool busy)>;
    void setBusyCallback(BusyFn fn) { mBusy = std::move(fn); }

  private:
    // report=false 时只持久化状态不触发事件上报（下载开始时即如此：
    // 不回传状态 2，等下载完成后再由 DOWNLOADED 上报）。
    void setState(Task* t, State s, bool report = true);
    void workerLoop();

    std::shared_ptr<IDownloader> mDownloader;
    std::shared_ptr<IVerifier> mVerifier;
    std::shared_ptr<IApplier> mApplier;
    TaskStore* mStore;
    ReportFn mReport;
    BusyFn mBusy;

    mutable std::mutex mMu;
    std::condition_variable mCv;
    std::queue<Task> mQueue;
    std::atomic<bool> mRunning{false};
    std::thread mWorker;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_FSM_H
