// 升级包目录空间管理实现。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/PkgCleanup.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <string>

#include <android-base/strings.h>

#include "util/FsUtil.h"

namespace emu {
namespace upgrade {

namespace {

// 从包文件名（<task_id>.bin / <task_id>.bin.tmp / <task_id>.tmp）解析 task_id。
bool TaskIdFromPkgName(const std::string& name, std::string* tid) {
    size_t n = name.size();
    if (n > 8 && name.compare(n - 8, 8, ".bin.tmp") == 0) {
        *tid = name.substr(0, n - 8);
        return !tid->empty();
    }
    if (android::base::EndsWith(name, ".tmp")) {
        if (n <= 4) return false;
        *tid = name.substr(0, n - 4);
        return true;
    }
    if (android::base::EndsWith(name, ".bin")) {
        if (n <= 4) return false;
        *tid = name.substr(0, n - 4);
        return true;
    }
    return false;
}

// 文件名段安全校验（防路径穿越）：拒绝 / \ ..。
// 注意：与 util::TaskIdSafe（字母数字白名单）语义不同，此处是包文件名场景。
bool IsPathSafe(const std::string& taskId) {
    if (taskId.empty() || taskId.find('/') != std::string::npos ||
        taskId.find('\\') != std::string::npos || taskId.find("..") != std::string::npos) {
        return false;
    }
    return true;
}

// 文件大小（用于日志统计释放空间）。
long long st_size_or_zero(const std::string& path) {
    struct stat st;
    if (stat(path.c_str(), &st) == 0) {
        return static_cast<long long>(st.st_size);
    }
    return 0;
}

}  // namespace

int PkgCleanup::beforeDownload(const std::string* keep, const std::string* protect) {
    std::vector<std::string> entries;
    if (util::ListDir(kPackageDir, &entries) != 0) {
        if (errno == ENOENT) return 0;
        ALOGE("[pkg_cleanup] opendir(%s) failed: %s", kPackageDir, strerror(errno));
        return -1;
    }

    long long freed = 0;
    int removed = 0;
    for (const std::string& fname : entries) {
        if (fname.empty() || fname[0] == '.') continue;
        if (!android::base::EndsWith(fname, ".bin") && !android::base::EndsWith(fname, ".tmp")) continue;

        std::string tid;
        if (!TaskIdFromPkgName(fname, &tid)) continue;

        // protect：排他保护的任务包一律保留。
        if (protect && !protect->empty() && tid == *protect) continue;

        std::string path = std::string(kPackageDir) + "/" + fname;
        if (keep && !keep->empty() && tid == *keep) {
            if (android::base::EndsWith(fname, ".bin") && !android::base::EndsWith(fname, ".bin.tmp")) {
                // 同任务已有完成的 .bin 且无进行中的 .tmp：视为陈旧，删除；
                // 有 .tmp 时保留 .bin 供后续比对，仅当无 .tmp 时才删 .bin。
                std::string tmpchk = path + ".tmp";
                if (access(tmpchk.c_str(), F_OK) != 0) {
                    freed += st_size_or_zero(path);
                    if (unlink(path.c_str()) == 0) removed++;
                }
            }
            continue;  // keep 任务的其余文件保留
        }

        freed += st_size_or_zero(path);
        if (unlink(path.c_str()) == 0) removed++;
    }
    ALOGI("[pkg_cleanup] before_download keep=%s protect=%s removed=%d freed≈%lld",
          keep ? keep->c_str() : "-", protect ? protect->c_str() : "-", removed, freed);
    return 0;
}

int PkgCleanup::ensureSpace(const std::string& pathHint, long long needBytes,
                            const std::string* keep, const std::string* protect) {
    long long need = needBytes > 0 ? needBytes : (64LL * 1024 * 1024);
    long long freeb = util::FreeBytes(pathHint);
    if (freeb < 0) {
        ALOGE("[pkg_cleanup] free unknown, skip gate");
        return 0;
    }
    if (freeb >= need) return 0;

    ALOGW("[pkg_cleanup] short free=%lld need=%lld — cleanup", freeb, need);
    beforeDownload(keep, protect);

    freeb = util::FreeBytes(pathHint);
    if (freeb < 0) return 0;
    if (freeb < need) {
        ALOGE("[pkg_cleanup] still short free=%lld need=%lld", freeb, need);
        return -1;
    }
    return 0;
}

int PkgCleanup::removeTask(const std::string& taskId) {
    if (!IsPathSafe(taskId)) {
        ALOGE("[pkg_cleanup] illegal task_id '%s'", taskId.c_str());
        return -1;
    }
    std::string bin = std::string(kPackageDir) + "/" + taskId + ".bin";
    std::string tmp = bin + ".tmp";
    int rc = 0;
    if (unlink(bin.c_str()) != 0 && errno != ENOENT) {
        ALOGE("[pkg_cleanup] unlink(%s) failed: %s", bin.c_str(), strerror(errno));
        rc = -1;
    }
    if (unlink(tmp.c_str()) != 0 && errno != ENOENT) {
        ALOGE("[pkg_cleanup] unlink(%s) failed: %s", tmp.c_str(), strerror(errno));
        rc = -1;
    }
    return rc;
}

}  // namespace upgrade
}  // namespace emu
