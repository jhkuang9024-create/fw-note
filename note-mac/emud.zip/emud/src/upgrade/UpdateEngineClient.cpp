// update_engine 稳定 AIDL binder 客户端实现。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/UpdateEngineClient.h"

#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include <chrono>
#include <condition_variable>
#include <mutex>
#include <utility>

#include <android-base/unique_fd.h>
#include <android/os/BnUpdateEngineStableCallback.h>
#include <android/os/IUpdateEngineStable.h>
#include <binder/IServiceManager.h>
#include <binder/ParcelFileDescriptor.h>
#include <binder/ProcessState.h>
#include <binder/Status.h>
#include <utils/String16.h>
#include <utils/StrongPointer.h>

namespace emu {
namespace upgrade {

namespace {

// 与 system/update_engine/common/error_code.h 保持一致。
constexpr int kErrorCodeSuccess = 0;               // ErrorCode::kSuccess
constexpr int kErrorCodeUpdatedButNotActive = 52;  // ErrorCode::kUpdatedButNotActive

constexpr char kUpdateEngineServiceName[] = "android.os.UpdateEngineStableService";

// 大包应用耗时可能很长，用宽松超时避免 update_engine 崩溃时 worker 线程永久阻塞。
constexpr int kCompletionTimeoutSeconds = 7200;  // 2 小时

class UpdateEngineCallback final : public android::os::BnUpdateEngineStableCallback {
  public:
    explicit UpdateEngineCallback(std::function<void(float)> onProgress)
        : mOnProgress(std::move(onProgress)) {}

    android::binder::Status onStatusUpdate(int32_t statusCode, float progress) override {
        (void)statusCode;
        if (mOnProgress) {
            mOnProgress(progress);
        }
        return android::binder::Status::ok();
    }

    android::binder::Status onPayloadApplicationComplete(int32_t errorCode) override {
        ALOGI("[update_engine_client] onPayloadApplicationComplete(%d)", errorCode);
        std::lock_guard<std::mutex> lock(mMutex);
        mDone = true;
        mResult = (errorCode == kErrorCodeSuccess || errorCode == kErrorCodeUpdatedButNotActive)
                          ? 0
                          : -1;
        mCv.notify_all();
        return android::binder::Status::ok();
    }

    // 阻塞直到收到完成回调；超时返回负值。
    int wait() {
        std::unique_lock<std::mutex> lock(mMutex);
        if (!mCv.wait_for(lock, std::chrono::seconds(kCompletionTimeoutSeconds),
                          [this] { return mDone; })) {
            ALOGE("[update_engine_client] timed out waiting for payload application");
            return -1;
        }
        return mResult;
    }

  private:
    std::function<void(float)> mOnProgress;
    std::mutex mMutex;
    std::condition_variable mCv;
    bool mDone = false;
    int mResult = -1;
};

}  // namespace

int ApplyUpdateEngine(const std::string& packagePath, int64_t payloadOffset, int64_t payloadSize,
                      const std::vector<std::string>& headers,
                      std::function<void(float)> onProgress) {
    if (packagePath.empty()) {
        ALOGE("[update_engine_client] empty package path");
        return -1;
    }

    // 确保进程有 binder 线程池，这样 oneway 的状态/完成回调能在本线程阻塞期间送达。
    android::ProcessState::self()->startThreadPool();

    android::sp<android::os::IUpdateEngineStable> service;
    android::status_t status =
            android::getService(android::String16(kUpdateEngineServiceName), &service);
    if (status != android::OK || service == nullptr) {
        ALOGE("[update_engine_client] failed to get '%s' (status=%d)", kUpdateEngineServiceName,
              static_cast<int>(status));
        return -1;
    }

    // 先绑定回调再触发 payload，避免漏掉状态更新。
    android::sp<UpdateEngineCallback> callback = new UpdateEngineCallback(std::move(onProgress));
    bool bound = false;
    android::binder::Status bindStatus = service->bind(callback, &bound);
    if (!bindStatus.isOk() || !bound) {
        ALOGE("[update_engine_client] failed to bind callback (%s)",
              bindStatus.toString8().c_str());
        return -1;
    }

    // update_engine 从 |payloadOffset| 起就地读取 payload，无需先解压大包。
    android::base::unique_fd fd(
            TEMP_FAILURE_RETRY(open(packagePath.c_str(), O_RDONLY | O_CLOEXEC)));
    if (fd.get() < 0) {
        ALOGE("[update_engine_client] cannot open %s: %s", packagePath.c_str(), strerror(errno));
        service->unbind(callback, &bound);
        return -1;
    }

    std::vector<android::String16> headerKvs;
    headerKvs.reserve(headers.size());
    for (const std::string& header : headers) {
        headerKvs.emplace_back(android::String16(header.c_str()));
    }

    android::os::ParcelFileDescriptor pfd(std::move(fd));
    android::binder::Status applyStatus =
            service->applyPayloadFd(pfd, payloadOffset, payloadSize, headerKvs);
    if (!applyStatus.isOk()) {
        ALOGE("[update_engine_client] applyPayloadFd failed (%s)", applyStatus.toString8().c_str());
        service->unbind(callback, &bound);
        return -1;
    }

    ALOGI("[update_engine_client] payload request sent (offset=%lld size=%lld "
          "headers=%zu)",
          static_cast<long long>(payloadOffset), static_cast<long long>(payloadSize),
          headerKvs.size());

    int result = callback->wait();

    service->unbind(callback, &bound);
    return result;
}

}  // namespace upgrade
}  // namespace emu
