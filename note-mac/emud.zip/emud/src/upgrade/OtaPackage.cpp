// OTA 升级包解析实现（libziparchive）。
//
//  - 用 libziparchive 探测 zip；找到 payload.bin 记录偏移/大小；
//  - 提取 payload_properties.txt 拆成 KEY=VALUE 行（处理 CRLF/CR）；
//  - 非 zip 文件回退为裸 payload（offset=0, size=文件大小）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/OtaPackage.h"

#include <string.h>
#include <sys/stat.h>

#include <vector>

#include <ziparchive/zip_archive.h>

#include "util/StringUtil.h"

namespace emu {
namespace upgrade {

namespace {

// payload_properties.txt 很小（几百字节），限制解压大小避免畸形包放大内存。
constexpr uint64_t kMaxPropertiesSize = 1024 * 1024;

bool ExtractEntryToString(ZipArchiveHandle archive, const std::string& name, std::string* out) {
    ZipEntry64 entry;
    if (FindEntry(archive, name, &entry) != 0) {
        ALOGE("[ota_package] entry '%s' not found", name.c_str());
        return false;
    }

    if (entry.uncompressed_length > kMaxPropertiesSize) {
        ALOGE("[ota_package] entry '%s' too large (%llu bytes)", name.c_str(),
              static_cast<unsigned long long>(entry.uncompressed_length));
        return false;
    }

    std::vector<uint8_t> buffer(entry.uncompressed_length);
    if (!buffer.empty() && ExtractToMemory(archive, &entry, buffer.data(), buffer.size()) != 0) {
        ALOGE("[ota_package] failed to extract '%s'", name.c_str());
        return false;
    }

    out->assign(buffer.empty() ? "" : reinterpret_cast<const char*>(buffer.data()), buffer.size());
    return true;
}

}  // namespace

int OtaPackage::parse(const std::string& packagePath, OtaPackageInfo* out) {
    if (out == nullptr) {
        return -1;
    }
    *out = OtaPackageInfo{};

    struct stat st;
    if (stat(packagePath.c_str(), &st) != 0 || !S_ISREG(st.st_mode)) {
        ALOGE("[ota_package] cannot stat %s", packagePath.c_str());
        return -1;
    }

    ZipArchiveHandle archive = nullptr;
    if (OpenArchive(packagePath.c_str(), &archive) == 0) {
        ZipEntry64 payload;
        std::string properties;

        bool ok = (FindEntry(archive, "payload.bin", &payload) == 0);
        if (ok) {
            ok = ExtractEntryToString(archive, "payload_properties.txt", &properties);
        }

        if (ok) {
            out->is_zip = true;
            out->payload_offset = static_cast<int64_t>(payload.offset);
            out->payload_size = static_cast<int64_t>(payload.uncompressed_length);
            out->headers = util::SplitHeaderLines(properties);

            ALOGI("[ota_package] parsed OTA zip payload.bin offset=%lld size=%lld "
                  "headers=%zu",
                  static_cast<long long>(out->payload_offset),
                  static_cast<long long>(out->payload_size), out->headers.size());
        }

        CloseArchive(archive);

        if (ok) {
            return 0;
        }

        ALOGE("[ota_package] zip archive is not a valid A/B OTA package "
              "(missing payload.bin/payload_properties.txt)");
        return -1;
    }

    // 非 zip：当作裸 payload.bin。
    out->is_zip = false;
    out->payload_offset = 0;
    out->payload_size = static_cast<int64_t>(st.st_size);

    ALOGI("[ota_package] raw payload size=%lld", static_cast<long long>(out->payload_size));
    return 0;
}

std::string OtaPackage::joinHeaders(const std::vector<std::string>& headers) {
    std::string out;
    for (size_t i = 0; i < headers.size(); ++i) {
        if (i > 0) out += '\n';
        out += headers[i];
    }
    return out;
}

}  // namespace upgrade
}  // namespace emu
