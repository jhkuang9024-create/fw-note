// 升级包下载器实现（libcurl）。
#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/OtaDownloader.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include <curl/curl.h>

#include "util/FsUtil.h"
#include "util/UrlUtil.h"

namespace emu {
namespace upgrade {

namespace {

constexpr int kDefaultConnectTimeoutSec = 30;
constexpr int kDefaultMaxRetries = 10;
constexpr int kDefaultStallTimeoutSec = 180;
constexpr long long kDefaultMinFreeBytes = 64LL * 1024 * 1024;

struct DlCtx {
    FILE* fp = nullptr;
    curl_off_t last_dlnow = 0;
    time_t last_progress_ts = 0;
    int stall_timeout_sec = 0;
    int aborted = 0;
};

// 日志脱敏：只保留 scheme://host[:port]/path，去掉 query/fragment。
std::string RedactUrl(const std::string& url) {
    std::string out = url;
    size_t q = out.find_first_of("?#");
    if (q != std::string::npos) {
        out.resize(q);
    }
    return out;
}

size_t WriteCb(void* ptr, size_t size, size_t nmemb, void* userdata) {
    DlCtx* ctx = static_cast<DlCtx*>(userdata);
    if (!ctx || !ctx->fp) return 0;
    struct timeval tv = {.tv_sec = 0, .tv_usec = 1000};
    select(0, nullptr, nullptr, nullptr, &tv);  // 每块稍微让出，避免饿死其他线程
    return fwrite(ptr, size, nmemb, ctx->fp);
}

int XferinfoCb(void* p, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal,
               curl_off_t ulnow) {
    (void)dltotal;
    (void)ultotal;
    (void)ulnow;
    DlCtx* ctx = static_cast<DlCtx*>(p);
    if (!ctx) return 1;
    time_t now = time(nullptr);
    if (dlnow != ctx->last_dlnow) {
        ctx->last_dlnow = dlnow;
        ctx->last_progress_ts = now;
    } else if (ctx->stall_timeout_sec > 0 && ctx->last_progress_ts > 0 &&
               (now - ctx->last_progress_ts) >= ctx->stall_timeout_sec) {
        ALOGE("[downloader] stall timeout %ds (dlnow=%lld)", ctx->stall_timeout_sec,
              static_cast<long long>(dlnow));
        ctx->aborted = 1;
        return 1;
    }
    return 0;
}

bool IsRetryable(CURLcode rc) {
    switch (rc) {
        case CURLE_COULDNT_CONNECT:
        case CURLE_COULDNT_RESOLVE_HOST:
        case CURLE_OPERATION_TIMEDOUT:
        case CURLE_RECV_ERROR:
        case CURLE_SEND_ERROR:
        case CURLE_PARTIAL_FILE:
        case CURLE_GOT_NOTHING:
        case CURLE_HTTP_RETURNED_ERROR:
            return true;
        default:
            return false;
    }
}

// 单次尝试（带断点续传）。
int DoOne(const std::string& url, const std::string& tmpPath, curl_off_t trafficBps,
          int stallTimeout, curl_off_t resume) {
    CURL* curl = curl_easy_init();
    if (!curl) return -1;
    FILE* fp = fopen(tmpPath.c_str(), resume > 0 ? "ab" : "wb");
    if (!fp) {
        curl_easy_cleanup(curl);
        return -1;
    }

    DlCtx ctx;
    ctx.fp = fp;
    ctx.stall_timeout_sec = stallTimeout;
    ctx.last_progress_ts = time(nullptr);

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    // 仅 http/https + 重定向封顶（与 HttpFileFetcher / CurlHttpClient 一致，收敛 SSRF 面）。
    curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 5L);
    curl_easy_setopt(curl, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, kDefaultConnectTimeoutSec);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "sn_upgrade/1.0");
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, XferinfoCb);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    if (trafficBps > 0) {
        curl_easy_setopt(curl, CURLOPT_MAX_RECV_SPEED_LARGE, trafficBps);
    }
    if (resume > 0) {
        curl_easy_setopt(curl, CURLOPT_RESUME_FROM_LARGE, resume);
    }

    CURLcode rc = curl_easy_perform(curl);
    long http = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http);
    curl_easy_cleanup(curl);
    fclose(fp);

    if (ctx.aborted) return -2;
    if (rc != CURLE_OK) {
        ALOGE("[downloader] curl error: %s (http=%ld code=%d)", curl_easy_strerror(rc), http,
              static_cast<int>(rc));
        return IsRetryable(rc) ? -3 : -1;
    }
    if (http > 0 && http / 100 != 2) {
        ALOGE("[downloader] http status %ld", http);
        return -1;
    }
    return 0;
}

}  // namespace

bool CurlDownloader::download(const std::string& url, const std::string& localPath,
                              const std::string& traffic) {
    if (url.empty() || localPath.empty()) return false;
    ALOGI("[downloader] start url=%s dest=%s traffic=%s", RedactUrl(url).c_str(), localPath.c_str(),
          traffic.c_str());

    if (!util::IsHttpUrl(url)) {
        ALOGE("[downloader] illegal url scheme");
        return false;
    }

    long long need = kDefaultMinFreeBytes;
    long long freeb = util::FreeBytes(localPath);
    if (freeb >= 0 && freeb < need) {
        ALOGE("[downloader] insufficient space free=%lld need=%lld", freeb, need);
        return false;
    }

    std::string tmp = localPath + ".tmp";
    int retries = kDefaultMaxRetries;
    int stall = kDefaultStallTimeoutSec;
    curl_off_t speed = 0;
    int trafficMbMin = atoi(traffic.c_str());
    if (trafficMbMin > 0) {
        speed = static_cast<curl_off_t>(trafficMbMin) * 1024 * 1024 / 60;
    }

    for (int attempt = 0; attempt < retries; attempt++) {
        struct stat st;
        curl_off_t resume = 0;
        if (stat(tmp.c_str(), &st) == 0 && st.st_size > 0) {
            resume = static_cast<curl_off_t>(st.st_size);
        }

        int r = DoOne(url, tmp, speed, stall, resume);
        if (r == 0) {
            if (rename(tmp.c_str(), localPath.c_str()) != 0) {
                ALOGE("[downloader] rename failed errno=%d", errno);
                return false;
            }
            ALOGI("[downloader] download ok path=%s", localPath.c_str());
            return true;
        }
        ALOGE("[downloader] attempt %d/%d failed r=%d", attempt + 1, retries, r);
        if (r == -1) break;  // 不可重试错误
        sleep(1 + (attempt < 5 ? attempt : 5));
    }
    return false;
}

}  // namespace upgrade
}  // namespace emu
