#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/UpgradeFsm.h"

#include <unistd.h>

#include "upgrade/OtaPlatform.h"
#include "upgrade/PkgCleanup.h"

namespace emu {
namespace upgrade {

namespace {

// 升级状态契约（upgrade_status_contract）：
//  SUCCESS / PENDING_REBOOT → "0"
//  下载中 / 已下载 / 校验中 / 应用中 / 已接受 → "2"
//  下载失败 → "-2"
//  其余失败 → "-1"
std::string ContractStatus(const Task& t, State s) {
    switch (s) {
        case State::Success:
        case State::PendingReboot:
            return "0";
        case State::Accepted:
        case State::Downloading:
        case State::Downloaded:
        case State::Verifying:
        case State::Applying:
            return "2";
        case State::Failed:
            return t.fail_code == 1 ? "-2" : "-1";
        default:
            return "-1";
    }
}

}  // namespace

UpgradeFsm::UpgradeFsm(std::shared_ptr<IDownloader> dl, std::shared_ptr<IVerifier> vf,
                       std::shared_ptr<IApplier> ap, TaskStore* store)
    : mDownloader(std::move(dl)), mVerifier(std::move(vf)), mApplier(std::move(ap)), mStore(store) {
    mRunning = true;
    mWorker = std::thread([this] { workerLoop(); });
}

UpgradeFsm::~UpgradeFsm() {
    signalStop();
    if (mWorker.joinable()) mWorker.join();
}

int UpgradeFsm::pendingCount() const {
    std::lock_guard<std::mutex> lk(mMu);
    return static_cast<int>(mQueue.size());
}

void UpgradeFsm::signalStop() {
    mRunning = false;
    mCv.notify_all();
}

void UpgradeFsm::enqueue(Task t) {
    {
        std::lock_guard<std::mutex> lk(mMu);
        mQueue.push(t);
    }
    mCv.notify_one();
}

void UpgradeFsm::setState(Task* t, State s, bool report) {
    t->state = s;
    t->last_status = ContractStatus(*t, s);
    if (mStore) mStore->save(*t);
    if (report && mReport) mReport(*t);
    ALOGI("[upgrade] task=%s → %s (status=%s)", t->task_id.c_str(), StateName(s),
          t->last_status.c_str());
}

void UpgradeFsm::runSync(Task t) {
    const std::string pkg = (mStore ? mStore->root() : "/tmp") + "/packages/" + t.task_id + ".bin";

    // 1. 下载（先清理 + 保证空间）。
    //    下载开始不立即回传 status=2，等下载完成后再由 DOWNLOADED 上报，
    //    避免平台端过早收到“下载成功”。
    //    清理时保留当前任务的 .bin/.tmp：上次下载失败残留的 .tmp 用于断点续传。
    setState(&t, State::Downloading, false);
    PkgCleanup::beforeDownload(&t.task_id, nullptr);
    PkgCleanup::ensureSpace(PkgCleanup::kPackageDir, 200LL * 1024 * 1024, &t.task_id, nullptr);

    if (!mDownloader->download(t.upg_url, pkg, t.traffic)) {
        t.last_msg = "download failed";
        t.fail_code = 1;
        setState(&t, State::Failed);
        // 下载失败保留 .tmp 以便断点续传，不删除包文件。
        return;
    }
    t.local_path = pkg;
    setState(&t, State::Downloaded);

    // 2. 校验 MD5。
    setState(&t, State::Verifying);
    if (!mVerifier->verify(t.local_path, t.md5)) {
        t.last_msg = "verify failed";
        t.fail_code = 2;
        setState(&t, State::Failed);
        PkgCleanup::removeTask(t.task_id);
        return;
    }

    // 3. 应用（TR069 忙检查 + AB 应用）。
    setState(&t, State::Applying);
    if (OtaPlatform::tr069Busy()) {
        t.last_msg = "system upgrade busy";
        t.fail_code = 3;
        setState(&t, State::Failed);
        PkgCleanup::removeTask(t.task_id);
        return;
    }

    // 返回值：<0 失败；0 stub 成功（无需重启）；1 成功且需重启切换槽位。
    int arc = mApplier->apply(t.local_path, t.task_id);
    if (arc < 0) {
        t.last_msg = "apply failed";
        t.fail_code = 3;
        setState(&t, State::Failed);
        PkgCleanup::removeTask(t.task_id);
        return;
    }
    if (arc == 0) {
        // stub 模式：跳过真实安装，直接成功。
        t.last_msg = "success (stub)";
        setState(&t, State::Success);
        return;
    }

    // 4. AB 应用完成：等待重启切换槽位。
    //    重启前只上报一次 PENDING_REBOOT（status=0），不补发 SUCCESS；
    //    设备真正重启、新系统起来后由 recover() 检测 pending 并把任务标记为 SUCCESS 上报，
    //    避免平台端在设备尚未重启时就把升级判定为成功（“成功过快”）。
    t.last_msg = "success, pending reboot";
    setState(&t, State::PendingReboot);
    sleep(2);
    if (OtaPlatform::rebootNormal() != 1) {
        ALOGE("[upgrade] reboot trigger failed, task stays PENDING_REBOOT");
    }
}

void UpgradeFsm::recover() {
    if (!mStore) return;
    ALOGI("[upgrade] recovery start");

    // 上次 AB 升级结果检查（update_engine rollback-happened 标记）。
    if (OtaPlatform::readLastInstallResult() != 0) {
        ALOGW("[upgrade] last AB install failed/rolled back — skip pending recovery");
        return;
    }

    // pending 任务：AB 升级已应用到 inactive 槽位 → 标记 SUCCESS 并清理现场。
    // 仅当 boot_mask 标记升级进行中（applyAbUpdate 在调用 update_engine 前写入）时，
    // pending 文件才是有效的“已应用待重启”状态；boot_mask=0（应用失败/崩溃在写标记前）
    // 时 pending 只是残留，直接清理，不做 SUCCESS 恢复。
    if (OtaPlatform::getBootMask() != 0) {
        std::string taskId, path;
        if (OtaPlatform::loadPending(&taskId, &path) == 0 && !taskId.empty()) {
            Task t;
            auto loaded = mStore->load(taskId);
            if (loaded) {
                t = std::move(*loaded);
            } else {
                t.task_id = taskId;
                t.local_path = path;
            }
            t.state = State::Success;
            t.last_status = "0";
            t.last_msg = "installed (recovered)";
            mStore->save(t);
            ALOGI("[upgrade] recovered pending task %s → SUCCESS", taskId.c_str());
            if (mReport) mReport(t);
        }
    } else {
        ALOGI("[upgrade] boot_mask=0: no upgrade in progress, clear stale pending");
        OtaPlatform::clearPending();
    }
    OtaPlatform::clearBootMask();

    // 崩溃遗留的中间状态任务（无 pending 标记）→ 标记 FAILED，避免悬空。
    for (auto& t : mStore->listIncomplete()) {
        if (t.state == State::PendingReboot) {
            // 已应用但未见 pending 文件（如已被清理）：直接视为成功。
            t.state = State::Success;
            t.last_status = "0";
            t.last_msg = "applied (recovered)";
        } else if (t.state != State::Failed) {
            t.state = State::Failed;
            t.last_status = "-1";
            t.last_msg = "interrupted by restart";
            t.fail_code = 4;
        }
        mStore->save(t);
        if (mReport) mReport(t);
        ALOGI("[upgrade] recovered task %s → %s", t.task_id.c_str(), StateName(t.state));
    }
}

void UpgradeFsm::workerLoop() {
    while (mRunning.load()) {
        Task t;
        {
            std::unique_lock<std::mutex> lk(mMu);
            mCv.wait(lk, [this] { return !mQueue.empty() || !mRunning.load(); });
            if (!mRunning.load()) return;
            t = mQueue.front();
            mQueue.pop();
        }
        // 任务处理期间声明业务占用（来源：emu_0907 同事方案）：升级下载/应用可能
        // 超过短连空闲租约，忙碌期间控制器不会触发空闲离线。
        if (mBusy) mBusy(true);
        runSync(t);
        if (mBusy) mBusy(false);
    }
}

}  // namespace upgrade
}  // namespace emu
