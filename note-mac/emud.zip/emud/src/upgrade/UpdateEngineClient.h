// update_engine 稳定 AIDL binder 客户端。
//
// 通过稳定接口 system/update_engine/stable/android/os/IUpdateEngineStable.aidl
// 把 payload 就地（zip 内偏移）提交给 update_engine，并等待完成回调。
#ifndef EMU_UPGRADE_UPDATE_ENGINE_CLIENT_H
#define EMU_UPGRADE_UPDATE_ENGINE_CLIENT_H

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace emu {
namespace upgrade {

// 把 |packagePath| 中从 |payloadOffset| 起 |payloadSize| 字节的 payload
// 提交给 update_engine，|headers| 为 payload_properties.txt 的 KEY=VALUE 行。
// 阻塞直到 update_engine 上报应用完成。
//
// 返回 0 成功（设备应重启切换槽位），负值失败。
int ApplyUpdateEngine(const std::string& packagePath, int64_t payloadOffset, int64_t payloadSize,
                      const std::vector<std::string>& headers,
                      std::function<void(float)> onProgress = nullptr);

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_UPDATE_ENGINE_CLIENT_H
