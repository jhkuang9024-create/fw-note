#define LOG_TAG "emud"
#include <log/log.h>

#include "upgrade/UpgradeFeature.h"

#include <cctype>
#include <cstdlib>
#include <string>

#include "upgrade/Md5Verifier.h"
#include "upgrade/OtaDownloader.h"
#include "SetUpgrade.pb.h"
#include "upgrade/UpdateEngineApplier.h"
#include "util/StringUtil.h"
#include "util/UrlUtil.h"

namespace emu {
namespace upgrade {

namespace {

// URL 仅允许 http/https，无控制字符；
// 可选 EMU_UPG_URL_HOST_ALLOW 主机白名单。
bool UrlAllowed(const std::string& url) {
    if (!util::IsHttpUrl(url)) return false;
    const char* allow = std::getenv("EMU_UPG_URL_HOST_ALLOW");
    if (allow && *allow) {
        // 从 URL 中取出 host（util::UrlHost，小写且不带端口/路径）与白名单匹配（前缀匹配，逐项）。
        const std::string host = util::UrlHost(url);
        std::string allowList = allow;
        size_t pos = 0;
        bool matched = false;
        while (pos <= allowList.size()) {
            size_t comma = allowList.find(',', pos);
            if (comma == std::string::npos) comma = allowList.size();
            std::string item = allowList.substr(pos, comma - pos);
            if (!item.empty() && host.compare(0, item.size(), item) == 0) {
                matched = true;
                break;
            }
            if (comma == allowList.size()) break;
            pos = comma + 1;
        }
        if (!matched) return false;
    }
    return true;
}

}  // namespace

UpgradeFeature::UpgradeFeature(Framework& fw) : mFw(fw) {
    mStore = std::make_unique<TaskStore>("/data/system/emud/upgrade");
    // 真实流水线：libcurl 下载 → OpenSSL MD5 校验 → ziparchive 解析 + update_engine
    // stable binder 应用。
    mFsm = std::make_unique<UpgradeFsm>(std::make_shared<CurlDownloader>(),
                                        std::make_shared<Md5Verifier>(),
                                        std::make_shared<UpdateEngineApplier>(), mStore.get());
    mFsm->setReportCallback([this](const Task& t) { onReport(t); });
    // 升级执行期对连接工作模式声明占用（来源：emu_0907 同事方案）
    mFsm->setBusyCallback([this](bool busy) {
        if (busy)
            mFw.businessStart("ota");
        else
            mFw.businessEnd("ota");
    });
    // 启动恢复：上次 AB 升级成功后补发 SUCCESS，清理现场。
    mFsm->recover();
}

UpgradeFeature::~UpgradeFeature() = default;

std::unique_ptr<UpgradeFeature> UpgradeFeature::create(Framework& fw) {
    auto self = std::make_unique<UpgradeFeature>(fw);
    auto* raw = self.get();
    fw.registerCmdHandler("SET_UPGRADE",
                          [raw](const InboundCommand& c) { return raw->onSetUpgrade(c); });
    return self;
}

std::optional<Response> UpgradeFeature::onSetUpgrade(const InboundCommand& cmd) {
    Task t;

    proto::SetUpgrade upg;
    if (!upg.ParseFromString(cmd.payload)) {
        return Response{"-1", "invalid upgrade payload"};
    }
    t.task_id = upg.taskid();
    t.upg_url = upg.upgurl();
    t.md5 = upg.md5();
    t.has_next = upg.hasnext();
    t.traffic = upg.traffic();

    // 多包级联（hasNext=true）暂未实现：后续包会被忽略，仅记录告警便于平台侧感知。
    if (t.has_next) {
        ALOGW("[upgrade] task=%s hasNext=true: multi-package cascade not implemented, "
              "follow-up packages will be ignored",
              t.task_id.c_str());
    }

    // 输入校验。
    if (!util::TaskIdSafe(t.task_id, 64)) {
        return Response{"-1", "illegal taskId"};
    }
    if (t.upg_url.empty() || !UrlAllowed(t.upg_url)) {
        return Response{"-1", "illegal upgUrl"};
    }
    if (mFsm->pendingCount() >= 4) {
        ALOGW("[upgrade] queue full, reject task=%s", t.task_id.c_str());
        return Response{"-1", "upgrade queue full"};
    }

    // 记录下行 correlation_data（cmd.task_id 即 SET_UPGRADE 的 MQTT v5 correlation_data），
    // 供后续 upgradeReport 事件回显对账。
    mFw.correlation().put(t.task_id, cmd.task_id);

    t.state = State::Accepted;

    mStore->save(t);
    mFsm->enqueue(std::move(t));

    ALOGI("[upgrade] accepted task=%s", t.task_id.c_str());
    // 即时 ack：status=1（终端已接收），msg=received；
    // 后续状态经 upgradeReport（E_UPGRADE）上报。
    return Response{"1", "received"};
}

void UpgradeFeature::onReport(const Task& t) {
    // 上报 upgradeReport 事件（protobuf EventUpgradeRet）；终态（成功/失败）后清理
    // 对账缓存，防止长期运行无界增长。构造 / 路由判断 / 清理统一走 Framework helper。
    const bool terminal = (t.state == State::Success || t.state == State::Failed);
    mFw.publishTaskEvent("upgradeReport", t.task_id, t.last_status, t.last_msg, terminal);
}

}  // namespace upgrade
}  // namespace emu
