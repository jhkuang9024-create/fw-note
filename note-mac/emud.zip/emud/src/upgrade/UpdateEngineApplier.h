// 真实升级执行器：解析 OTA 包 → 平台 AB 应用（update_engine binder）。
#ifndef EMU_UPGRADE_UPDATE_ENGINE_APPLIER_H
#define EMU_UPGRADE_UPDATE_ENGINE_APPLIER_H

#include <string>

#include "upgrade/Pipeline.h"

namespace emu {
namespace upgrade {

// 应用流程：
//  ota_package_parse（zip/裸 payload）
//  platform_ota_set_boot_mask(0x02) + save_pending
//  platform_ota_apply_ab_update（update_engine stable binder）
//
// Apply 返回值：<0 失败；0 stub 成功；1 成功且需重启切换槽位。
class UpdateEngineApplier : public IApplier {
  public:
    int apply(const std::string& localPath, const std::string& taskId) override;
};

}  // namespace upgrade
}  // namespace emu

#endif  // EMU_UPGRADE_UPDATE_ENGINE_APPLIER_H
