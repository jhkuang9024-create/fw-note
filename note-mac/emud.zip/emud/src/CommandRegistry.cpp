#define LOG_TAG "emud"
#include <log/log.h>

#include "CommandRegistry.h"

namespace emu {

void CommandRegistry::registerHandler(const std::string& cmdType, CommandHandler h) {
    mHandlers[cmdType] = std::move(h);
}

void CommandRegistry::registerBuiltin(const std::string& cmdType, CommandHandler h) {
    mBuiltin[cmdType] = std::move(h);
}

void CommandRegistry::loadRoutes(const Config& cfg) {
    mRoutes = cfg.routes;
}

std::optional<Response> CommandRegistry::dispatch(const InboundCommand& cmd) const {
    // 1. 核心内置
    auto bit = mBuiltin.find(cmd.cmd_type);
    if (bit != mBuiltin.end()) return bit->second(cmd);

    // 2. 业务域注册
    auto it = mHandlers.find(cmd.cmd_type);
    if (it != mHandlers.end()) return it->second(cmd);

    // 3. 配置路由（仅产生 ack / 无域 handler 的声明式路由）
    for (const auto& r : mRoutes) {
        if (r.cmd_type == cmd.cmd_type) {
            Response resp;
            resp.code = r.ack_status.empty() ? "0" : r.ack_status;
            resp.msg = r.ack_msg.empty() ? "received" : r.ack_msg;
            return resp;
        }
    }

    ALOGW("[router] no handler for cmdType=%s", cmd.cmd_type.c_str());
    return std::nullopt;
}

}  // namespace emu
