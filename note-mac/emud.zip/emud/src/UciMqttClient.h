// 真实 MQTT 客户端：封装 libmosquitto（MQTT v5），对应 §5.1 的 IMqttClient 实现。
#ifndef EMU_UCI_MQTT_CLIENT_H
#define EMU_UCI_MQTT_CLIENT_H

#include <condition_variable>
#include <mutex>
#include <string>
#include <utility>
#include <vector>

#include "MqttClient.h"

// libmosquitto 的不透明类型，避免在头文件暴露第三方头文件。
struct mosquitto;
struct mosquitto_message;
struct mqtt5__property;
typedef struct mqtt5__property mosquitto_property;

namespace emu {

class UciMqttClient : public IMqttClient {
  public:
    UciMqttClient();
    ~UciMqttClient() override;

    int connect(const MqttConnectConfig& cfg) override;
    int subscribe(const std::string& topic, int qos) override;
    int publish(const std::string& topic, const std::string& payload, int qos) override;
    bool isConnected() const override;
    int disconnect() override;

    void setV5Header(const MqttHeader& h) override;
    void setMessageCallback(MqttMessageCallback cb) override;
    void setDisconnectCallback(MqttDisconnectCallback cb) override;
    int updateCredentials(const std::string& username, const std::string& password) override;

  private:
    static void onConnect(struct mosquitto* mosq, void* obj, int rc);
    static void onConnectV5(struct mosquitto* mosq, void* obj, int rc, int flags,
                            const mosquitto_property* props);
    static void onMessageV5(struct mosquitto* mosq, void* obj, const struct mosquitto_message* msg,
                            const mosquitto_property* props);
    static void onDisconnect(struct mosquitto* mosq, void* obj, int rc);
    static void onDisconnectV5(struct mosquitto* mosq, void* obj, int rc,
                               const mosquitto_property* props);
    static void onLog(struct mosquitto* mosq, void* obj, int level, const char* str);

    // 把最近设置的 v5 header 组装为 libmosquitto 属性链。
    int buildV5Properties(mosquitto_property** props, const MqttHeader& hdr) const;
    // 从入站消息属性解析 v5 header。
    static MqttHeader parseV5Header(const mosquitto_property* props);
    // 在 libmosquitto 回调线程中投递一条入站消息。
    void deliverMessage(const struct mosquitto_message* msg, const mosquitto_property* props);

    // 断开并销毁当前连接（锁外调用）：先触发断开，再锁外等待网络线程退出，最后销毁。
    // 不能在持 mu_ 时等待网络线程——网络线程可能在用户回调（锁外）中等待 mu_ 发布消息，
    // 锁内等待会互相死锁。
    void stopAndDestroy();
    // 断开并销毁当前连接（调用方需已持有 mu_，仅用于无并发网络线程的场景：
    // 首次连接失败/析构）。
    void cleanupLocked();

    mutable std::mutex mMu;
    std::condition_variable mCv;
    struct mosquitto* mMosq = nullptr;
    bool mConnected = false;
    bool mLoopStarted = false;
    bool mConnackReceived = false;
    int mConnackRc = -1;

    MqttHeader mLastSendHeader;
    bool mHeaderValid = false;
    MqttMessageCallback mCb;
    MqttDisconnectCallback mDisconnectCb;
    // 已订阅的 (topic, qos) 列表：clean session 下断线后 broker 侧订阅清空，
    // 重连成功（onConnect）时重放。
    std::vector<std::pair<std::string, int>> mSubs;
};

}  // namespace emu

#endif  // EMU_UCI_MQTT_CLIENT_H
