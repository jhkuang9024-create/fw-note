// nmproxy 反向隧道生命周期（RAII）+ SSH 隧道命令处理。
#ifndef EMU_SSH_TUNNEL_H
#define EMU_SSH_TUNNEL_H

#include <atomic>
#include <memory>
#include <optional>
#include <string>

#include "Command.h"
#include "Framework.h"

namespace emu {
namespace ssh_tunnel {

// nmproxy 隧道参数（对应 SetRemoteControl 下发内容）
struct TunnelConfig {
    std::string connect_key;
    std::string relay_server_address;
    int relay_server_port = 0;
    std::string relay_dest_address = "127.0.0.1";
    int relay_dest_port = 0;
    std::string nmproxy_path = "/system/bin/nmproxy";
    // SSH 场景: 先拉起 dropbear 监听本机 SSH 端口（与 nmproxy -l 一致）。
    // 路径与 sepolicy (sshd_exec) 保持一致。
    std::string dropbear_path = "/system/xbin/dropbear";
    bool enable_dropbear = true;
};

// nmproxy 进程生命周期：fork + execve；析构时 SIGTERM → SIGKILL → waitpid。
// SSH 场景同时托管 dropbear：Start 时先拉起 dropbear，Stop 时一并回收。
class SshTunnelSession {
  public:
    SshTunnelSession() = default;
    ~SshTunnelSession();

    SshTunnelSession(const SshTunnelSession&) = delete;
    SshTunnelSession& operator=(const SshTunnelSession&) = delete;

    bool start(const TunnelConfig& cfg);
    void stop();
    bool isAlive() const;

  private:
    // fork + execve 拉起 dropbear（-p <port> -R -F，前台常驻），返回是否成功
    bool startDropbear(const std::string& path, int port);
    // 子进程回收（SIGTERM → 超时 SIGKILL → waitpid）统一走 util::TerminateProcess

    pid_t mPid = -1;           // nmproxy 子进程
    pid_t mDropbearPid = -1;  // dropbear 子进程（SSH 场景）
};

class SshTunnelFeature {
  public:
    explicit SshTunnelFeature(Framework& fw);
    ~SshTunnelFeature();

    // 构造 + 注册 handler；实例由调用方（main）持有，保证析构先于 Framework。
    static std::unique_ptr<SshTunnelFeature> create(Framework& fw);

    std::optional<Response> onSetRemoteSsh(const InboundCommand& cmd);

  private:
    SshTunnelSession mTunnel;
    TunnelConfig mCfg;
    Framework& mFw;
    bool mTunnelActive = false;  // 隧道运行中（业务占用标记用）
};

}  // namespace ssh_tunnel
}  // namespace emu

#endif  // EMU_SSH_TUNNEL_H
