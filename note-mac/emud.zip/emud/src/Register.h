// 注册服务：构造 DeviceRegister、发布到 reg_topic、订阅 reg_resp_topic、解析注册响应。
#ifndef EMU_REGISTER_H
#define EMU_REGISTER_H

#include <memory>

#include "Config.h"
#include "MqttClient.h"

namespace emu {

struct RegisterResult {
    bool success = false;
    std::string code;
    std::string msg;
    std::string work_mode;
    std::string period;
    bool has_next = false;
    // reg_resp 是否真的携带了 hasNext 字段（proto2 optional Has 方法判定）；
    // 未携带时不改控制器里维护的 hasNext 旧值。
    // （来源：emu_0907 同事方案）
    bool has_has_next = false;
};

class RegisterService {
  public:
    // net_ip：认证 token 返回的 clientIP，写入注册报文字段 19（netIp）
    RegisterService(const Config& cfg, std::shared_ptr<IMqttClient> mqtt,
                    const std::string& netIp = "");

    // 订阅注册响应 topic，并向 reg_topic 发送注册请求（返回结果）
    RegisterResult run();

    // 处理注册响应（由 Framework 在收到 acs/{dt}/{id}/reg_resp 时调用，回填结果）
    void handleRegResp(const MqttMessage& msg);

    const RegisterResult& result() const { return mResult; }

    static std::string buildRegRespTopic(const std::string& deviceType,
                                         const std::string& deviceId);

  private:
    Config mCfg;
    std::shared_ptr<IMqttClient> mMqtt;
    std::string mNetIp;
    RegisterResult mResult;
};

}  // namespace emu

#endif  // EMU_REGISTER_H
