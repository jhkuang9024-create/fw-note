// CmdEnvelope：把 MQTT 载荷解析为 InboundCommand。入站统一为 protobuf 二进制，
// cmdType / correlation_data 取自 MQTT v5 header。
#ifndef EMU_ENVELOPE_H
#define EMU_ENVELOPE_H

#include <optional>
#include <string>

#include "Command.h"
#include "MqttClient.h"

namespace emu {

class Envelope {
  public:
    // 从 MQTT 消息解析入站命令（protobuf 二进制载荷）
    static std::optional<InboundCommand> parse(const MqttMessage& msg);

    // 从 protobuf 载荷提取业务 taskId（各命令 proto 的 field 1 均为 taskId，
    // wire type 2 string）。载荷为空 / 非 protobuf / 无该字段时返回空串。
    static std::string extractTaskId(const std::string& payload);
};

}  // namespace emu

#endif  // EMU_ENVELOPE_H
