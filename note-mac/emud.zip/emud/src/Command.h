// 命令与响应数据模型（统一 Handler 模型 §5.3）。
#ifndef EMU_COMMAND_H
#define EMU_COMMAND_H

#include <functional>
#include <optional>
#include <string>
#include <vector>

#include "MqttClient.h"

namespace emu {

// 入站命令：由 MQTT 消息解析得到，统一交给 CommandRegistry 分发。
// 载荷统一为 protobuf 二进制（src/messages.proto）。
struct InboundCommand {
    std::string cmd_type;  // MQTT v5 header 的 cmdType
    std::string task_id;   // correlation_data
    std::string payload;   // protobuf 二进制载荷
    MqttHeader header;     // 原始 v5 header
};

// 命令响应（回执 / 结果）
struct Response {
    std::string code;  // "0"成功 / "-1"失败 / ack 时用路由的 ack_status
    std::string msg;   // 消息；GET_* 结果（JSON 字符串）经此字段返回
    // GET_CAPTURE_PACKET_INTERFACE 专用：支持抓包的接口数组。
    std::vector<std::string> interface_list;

    Response() = default;
    Response(std::string code, std::string msg) : code(std::move(code)), msg(std::move(msg)) {}
    Response(std::string code, std::string msg, std::vector<std::string> interfaceList)
        : code(std::move(code)), msg(std::move(msg)), interface_list(std::move(interfaceList)) {}
};

using CommandHandler = std::function<std::optional<Response>(const InboundCommand&)>;

}  // namespace emu

#endif  // EMU_COMMAND_H
