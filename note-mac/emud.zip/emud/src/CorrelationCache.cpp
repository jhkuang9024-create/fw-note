#include "CorrelationCache.h"

namespace emu {

void CorrelationCache::put(const std::string& taskId, const std::string& correlationData) {
    if (taskId.empty() || correlationData.empty()) return;
    std::lock_guard<std::mutex> lk(mMu);
    mMap[taskId] = correlationData;
}

std::string CorrelationCache::resolve(const std::string& taskId,
                                      const std::string& explicitCorr) const {
    if (!explicitCorr.empty()) return explicitCorr;
    std::lock_guard<std::mutex> lk(mMu);
    auto it = mMap.find(taskId);
    if (it != mMap.end()) return it->second;
    return taskId;  // taskId 兜底
}

void CorrelationCache::clear(const std::string& taskId) {
    std::lock_guard<std::mutex> lk(mMu);
    mMap.erase(taskId);
}

}  // namespace emu
