#define LOG_TAG "emud"
#include <log/log.h>

#include "Framework.h"

#include <chrono>
#include <cstdio>
#include <thread>

#include <android-base/file.h>

#include "Disconnect.pb.h"
#include "Envelope.h"
#include "EventUpgradeRet.pb.h"
#include "GetCapturePacketInterfaceRsp.pb.h"
#include "SetCommonRsp.pb.h"
#include "SetWorkMode.pb.h"

namespace emu {

namespace {

// 把服务端下发的 sslCert 写入 CA 文件（还原 JSON 转义的 \n）。
// CA 证书写入数据目录（/data/system/emud/，可读写；配置目录 system 分区只读不可写）。
std::string WriteSslCert(const std::string& clientId, const std::string& sslCert) {
    std::string path = std::string(kDataDir) + "/devops_ca_" + clientId + ".pem";
    if (sslCert.empty()) return {};

    // 还原 JSON 转义（\\n → 换行）后经 libbase 落盘。
    std::string pem;
    pem.reserve(sslCert.size() + 1);
    for (size_t i = 0; i < sslCert.size(); ++i) {
        if (sslCert[i] == '\\' && i + 1 < sslCert.size() && sslCert[i + 1] == 'n') {
            pem.push_back('\n');
            ++i;
        } else {
            pem.push_back(sslCert[i]);
        }
    }
    pem.push_back('\n');
    if (!android::base::WriteStringToFile(pem, path)) {
        ALOGE("[fw] write CA cert %s failed", path.c_str());
        return {};
    }
    ALOGI("[fw] wrote CA cert %s (%zu bytes)", path.c_str(), sslCert.size());
    return path;
}

}  // namespace

Framework::Framework(Config cfg, std::shared_ptr<IMqttClient> mqtt,
                     std::shared_ptr<IHttpClient> http)
    : mCfg(std::move(cfg)), mMqtt(std::move(mqtt)), mHttp(std::move(http)), mActionHandler(mCfg) {
    mRegistry.loadRoutes(mCfg);
    mActionHandler.registerBuiltins(mRegistry);
}

Framework::~Framework() {
    stop();
}

std::unique_ptr<Framework> Framework::create(std::shared_ptr<IMqttClient> mqtt,
                                             std::shared_ptr<IHttpClient> http) {
    auto cfg = ConfigLoad();
    if (!cfg) return nullptr;
    return std::unique_ptr<Framework>(
            new Framework(std::move(*cfg), std::move(mqtt), std::move(http)));
}

std::string Framework::buildCmdRespTopic(const std::string& deviceType,
                                         const std::string& deviceId) {
    return "cpe/" + deviceType + "/" + deviceId + "/cmd_resp";
}
std::string Framework::buildEventTopic(const std::string& deviceType) {
    return "cpe/" + deviceType + "/all/event";
}

int Framework::start() {
    if (mRunning.exchange(true)) return 0;
    mStopRequested = false;

    // 连接工作模式控制器 + SET_WORK_MODE 处理器：进程生命周期内仅初始化一次
    // （boot 管道失败由 main 循环重试 start()，控制器状态不随失败重置；
    //   来源：emu_0907 同事方案）。
    if (!mWorkMode) {
        mWorkMode = std::make_unique<WorkModeController>();
        mWorkMode->start(kDataDir, [this](const char* r) { workModeOffline(r); },
                         [this](const char* r) { return workModeOnline(r); });
        registerCmdHandler("SET_WORK_MODE",
                           [this](const InboundCommand& c) { return onSetWorkMode(c); });
    }

    const int rc = doConnectAndRegister();
    if (rc != 0) {
        mRunning = false;
        return rc;
    }
    ALOGI("[fw] started");
    return 0;
}

// 完整上线管道（boot 由 main 循环重试调用 / 短连唤醒由 workModeOnline 调用）：
// 门闩检查 → 主动断开旧会话 → auth → connDelay → connect → 订阅/注册/心跳。
int Framework::doConnectAndRegister() {
    if (mStopRequested.load()) return -1;
    if (workModeBlocksConnect()) {
        ALOGI("[workmode] pipeline abort gate mode=%d sleeping=%d wake=%d",
              mWorkMode ? mWorkMode->connMode() : -1,
              mWorkMode && mWorkMode->isSleeping() ? 1 : 0, mWorkmodeWake.load() ? 1 : 0);
        return -1;
    }

    // 主动断开：保持门闩直到管道就绪，避免 stop/重连竞态（期间断线回调被抑制）。
    // 先清回调再断：旧实例可能仍在 mosquitto 网络线程自动重连，先停掉再建新会话。
    mIntentionalDisconnect = true;
    if (mMqtt) {
        mMqtt->setDisconnectCallback(nullptr);
        mMqtt->setMessageCallback(nullptr);
        mMqtt->disconnect();
    }
    if (mStopRequested.load()) return -1;

    // 1. 认证（可选）
    if (mCfg.auth.enable && mHttp) {
        mAuth = std::make_unique<AuthSession>(mCfg.auth, mCfg.device, mHttp);
        mAuthResult = mAuth->run();
        ALOGI("[fw] auth done: success=%d error=%s", mAuthResult.success ? 1 : 0,
              mAuthResult.error.c_str());
    } else {
        ALOGW("[fw] auth skipped (enable=%d http=%s)", mCfg.auth.enable ? 1 : 0,
              mHttp ? "yes" : "no");
    }
    if (mStopRequested.load()) return -1;

    // 1.5 connDelay：服务端要求首次连接前等待（EMU 规范 token 响应中的 connDelay 字段）；
    // 分段等待以便 stop 时能退出。
    if (mAuthResult.conn_delay > 0) {
        ALOGI("[fw] connDelay: waiting %d seconds before MQTT connect...", mAuthResult.conn_delay);
        for (int i = 0; i < mAuthResult.conn_delay && mRunning.load() && !mStopRequested.load();
             ++i) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        if (!mRunning.load() || mStopRequested.load()) {
            ALOGW("[fw] connDelay interrupted by stop, abort connect");
            return -1;
        }
        ALOGI("[fw] connDelay: done, connecting now");
    }

    // 2. 连接 MQTT
    MqttConnectConfig mc;
    mc.client_id = DeviceId(mCfg.device);  // MAC 优先，SN 兜底
    mc.username = mCfg.device.sn;
    if (!mAuthResult.mqtt_ip.empty()) {
        mc.host = mAuthResult.mqtt_ip;
        mc.port = mAuthResult.mqtt_port;
        mc.password = mAuthResult.jwt;
        mc.keep_alive = mAuthResult.keep_alive;
        // 服务端 mode: 0=TLS长连接, 1=TCP短连接, 2=不连接。
        mc.use_ssl = (mAuthResult.mode == "0");
        if (mc.use_ssl && !mAuthResult.ssl_cert.empty()) {
            // 服务端下发的 CA 证书优先（写入 /data/system/emud/devops_ca_<client_id>.pem），
            // 兜底才用 config.json 的 ca_cert_path。
            std::string ca = WriteSslCert(mc.client_id, mAuthResult.ssl_cert);
            mc.ca_cert_path = ca.empty() ? mCfg.auth.ca_cert_path : ca;
        } else {
            mc.ca_cert_path = mCfg.auth.ca_cert_path;
        }
        ALOGI("[fw] mqtt broker from auth: %s:%d ssl=%d ca=%s", mc.host.c_str(), mc.port,
              mc.use_ssl ? 1 : 0, mc.ca_cert_path.c_str());
    } else {
        // 未认证成功：用 config 兜底（dry-run 场景）
        mc.host = "127.0.0.1";
        mc.port = 1883;
        mc.keep_alive = 60;
        ALOGW("[fw] mqtt broker FALLBACK to localhost %s:%d (auth unavailable)", mc.host.c_str(),
              mc.port);
    }

    // LWT 遗嘱：异常掉线时由 broker 代发 cpe/{dt}/all/offline（Disconnect protobuf，
    // status=offline 表示遗嘱异常离线）。
    mc.will_enable = true;
    mc.will_topic = Offline::buildTopic(mCfg.device.device_type);
    {
        proto::Disconnect will;
        will.set_sn(mCfg.device.sn);
        will.set_status("offline");
        will.set_reason("");
        will.SerializeToString(&mc.will_payload);
    }

    ALOGI("[fw] mqtt connect → %s:%d client=%s", mc.host.c_str(), mc.port, mc.client_id.c_str());

    // 6. 入站消息回调 + 断线回调（断线重认证/重连编排）必须在 connect 之前注册：
    // libmosquitto 连接建立/断开事件随时可能先于本线程注册到达（#10）。
    // （回调内部经 mIntentionalDisconnect / allowFaultReconnect 门闩，不会在
    //   本管道就绪前触发重连编排。）
    mMqtt->setMessageCallback([this](const MqttMessage& m) { onMqttMessage(m); });
    mMqtt->setDisconnectCallback([this](int rc) { onMqttDisconnected(rc); });

    if (mMqtt->connect(mc) != 0) {
        ALOGE("[fw] mqtt connect failed host=%s:%d", mc.host.c_str(), mc.port);
        return -1;
    }
    if (mStopRequested.load()) {
        ALOGW("[fw] stop during connect, teardown");
        mIntentionalDisconnect = true;
        if (mMqtt) {
            mMqtt->setDisconnectCallback(nullptr);
            mMqtt->setMessageCallback(nullptr);
            mMqtt->disconnect();
        }
        return -1;
    }

    // 3. 订阅
    doSubscribe();

    // 4. 注册
    doRegister();

    // 5. 心跳（重建：旧会话心跳已随 offline 停止）
    if (mHeartbeat) mHeartbeat->stop();
    mHeartbeat = std::make_unique<Heartbeat>(mMqtt, mCfg.device.sn, mCfg.device.mac,
                                             mCfg.device.device_type);
    mHeartbeat->start(mAuthResult.server_keep_alive > 0 ? mAuthResult.server_keep_alive : 1800);

    mOffline = std::make_unique<Offline>(mMqtt, mCfg.device.sn, mCfg.device.device_type);

    // 管道就绪后才允许断线回调触发重连编排。
    if (mStopRequested.load()) {
        mIntentionalDisconnect = true;
        if (mMqtt) {
            mMqtt->setDisconnectCallback(nullptr);
            mMqtt->setMessageCallback(nullptr);
            mMqtt->disconnect();
        }
        return -1;
    }
    mIntentionalDisconnect = false;

    ALOGI("[fw] pipeline OK");
    if (mWorkMode) {
        mWorkMode->onPipelineOnline();
        std::string off_reason;
        if (mWorkMode->consumePendingOffline(&off_reason)) {
            ALOGI("[workmode] pipeline reject → offline reason=%s", off_reason.c_str());
            workModeOffline(off_reason.c_str());
        }
    }
    return 0;
}

void Framework::stop() {
    mStopRequested = true;
    mIntentionalDisconnect = true;
    const bool was_running = mRunning.exchange(false);

    // 停工作模式控制器（join 内部 timer；timer 若在 online 管道中会因
    // stop_requested 快速退出）
    if (mWorkMode) mWorkMode->stop();

    // 回收断线重认证线程（HTTP 有超时上限），再断 MQTT，避免线程使用已释放资源。
    if (mReauthThread.joinable()) mReauthThread.join();

    // 回收离线线程：锁外 join（不持锁等待——网络线程可能在 workModeOffline 等锁，
    // 持锁 join 会与 offline 线程内的 disconnect(loop_stop) 互相等待死锁）。
    // inflight 线程体见 stop_requested 会快速退出。
    std::thread t;
    {
        std::lock_guard<std::mutex> lk(mOfflineMu);
        mOfflineDone = true;
        if (mOfflineThread.joinable()) t = std::move(mOfflineThread);
    }
    if (t.joinable()) t.join();
    {
        std::lock_guard<std::mutex> lk(mOfflineMu);
        if (mOfflineThread.joinable()) mOfflineThread.join();
    }

    if (!was_running) {
        if (mMqtt) {
            mMqtt->setDisconnectCallback(nullptr);
            mMqtt->setMessageCallback(nullptr);
            mMqtt->disconnect();
        }
        ALOGI("[fw] stopped (idle)");
        return;
    }

    if (mOffline) mOffline->send("disconnect", "normal");
    if (mHeartbeat) mHeartbeat->stop();
    if (mMqtt) {
        mMqtt->setDisconnectCallback(nullptr);
        mMqtt->setMessageCallback(nullptr);
        mMqtt->disconnect();
    }
    ALOGI("[fw] stopped");
}

int Framework::doSubscribe() {
    // %s 展开为设备 id（MAC 优先，SN 兜底）；展开逻辑仅此一处，内联。
    for (const auto& t : mCfg.subscribe_topics) {
        std::string topic = t.topic;
        size_t pos = topic.find("%s");
        if (pos != std::string::npos) topic.replace(pos, 2, DeviceId(mCfg.device));
        mMqtt->subscribe(topic, t.qos);
    }
    // 注册响应 topic 在 RegisterService::run() 内订阅
    return 0;
}

int Framework::doRegister() {
    // netIp：认证 token 返回的 clientIP 传入注册报文
    mRegister = std::make_unique<RegisterService>(mCfg, mMqtt, mAuthResult.client_ip);
    mRegister->run();
    return 0;
}

void Framework::onMqttDisconnected(int rc) {
    if (!mRunning.load() || mStopRequested.load() || mIntentionalDisconnect.load()) return;
    // 工作模式门闩：短连休眠 / 不连模式下不触发断线重连编排
    // （来源：emu_0907 同事方案）
    if (mWorkMode && !mWorkMode->allowFaultReconnect()) {
        ALOGI("[workmode] gate block disconnect_reauth rc=%d mode=%d", rc,
              mWorkMode->connMode());
        return;
    }
    ALOGW("[fw] mqtt disconnected rc=%d, re-authenticate & refresh credentials", rc);
    if (!mCfg.auth.enable || !mHttp || !mAuth) {
        ALOGW("[fw] auth disabled or not initialized, wait auto-reconnect with old credentials");
        return;
    }

    // joinable() 陷阱：完成而未 join 的线程 joinable() 恒 true，老代码在第二次断线时
    // 误判“已在重认证”直接 skip，导致凭据过期后永不刷新。
    // 正确语义：同一时刻只允许一个重认证线程；上一轮结束（mReauthRunning==false）
    // 但线程未回收时先 join 回收再起新线程。
    if (mReauthThread.joinable()) {
        if (mReauthRunning.exchange(true)) {
            ALOGW("[fw] re-auth already in progress, skip");
            return;
        }
        mReauthThread.join();  // 上一轮已完成，仅回收线程资源（快速返回）
    } else {
        mReauthRunning.store(true);
    }

    // 网络线程内只起线程，不在回调里做阻塞 HTTP。
    mReauthThread = std::thread([this] {
        mAuth->reset();
        AuthResult ar = mAuth->run();
        if (ar.success && mMqtt) {
            mAuthResult = ar;
            mMqtt->updateCredentials(mCfg.device.sn, ar.jwt);
            ALOGI("[fw] mqtt credentials refreshed, waiting auto-reconnect");
        } else {
            ALOGE("[fw] re-auth failed, keep old credentials (err=%s)", ar.error.c_str());
        }
        mReauthRunning.store(false);
    });
}

void Framework::onMqttMessage(const MqttMessage& msg) {
    // 注册响应分流：解析并回填注册结果（code/workMode/period/hasNext）
    std::string regRespTopic =
            RegisterService::buildRegRespTopic(mCfg.device.device_type, DeviceId(mCfg.device));
    if (msg.topic == regRespTopic) {
        if (mRegister) mRegister->handleRegResp(msg);
        // 注册响应带回 workMode/period/hasNext：驱动短连/不连模式切换
        // （来源：emu_0907 同事方案）
        applyRegisterWorkMode();
        return;
    }

    // 事件回执：心跳等事件响应（v5 header 无 cmdType），当前协议未定义回执处理，仅记录。
    std::string eventRespTopic =
            "acs/" + mCfg.device.device_type + "/" + DeviceId(mCfg.device) + "/event_resp";
    if (msg.topic == eventRespTopic) {
        ALOGD("[fw] event_resp ignored topic=%s (%zu bytes)", msg.topic.c_str(),
              msg.payload.size());
        return;
    }

    auto cmd = Envelope::parse(msg);
    if (!cmd) return;

    // 空闲期轻量指令：滑动刷新短连接空闲租约（来源：emu_0907 同事方案）
    if (mWorkMode) mWorkMode->onLightActivity();

    // 业务 taskId 在 protobuf 载荷 field 1（如 TASK_ONE_3953）；
    // cmd.task_id 是 v5 header 的 correlation_data（平台消息关联 ID），两者是两套字段。
    const std::string taskId = Envelope::extractTaskId(cmd->payload);
    ALOGI("[fw] cmd %s taskId=%s corr=%s", cmd->cmd_type.c_str(),
          taskId.empty() ? "-" : taskId.c_str(), cmd->task_id.c_str());

    auto resp = mRegistry.dispatch(*cmd);
    if (!resp) {
        // 无 handler 时回显"-1 unsupported cmd"，提升平台侧可观测性
        // （来源：emu_0827 同事方案）。
        ALOGW("[fw] no handler for %s taskId=%s corr=%s", cmd->cmd_type.c_str(),
              taskId.empty() ? "-" : taskId.c_str(), cmd->task_id.c_str());
        publishCmdRespRaw(cmd->cmd_type.c_str(), taskId.c_str(), "-1", "unsupported cmd",
                          cmd->task_id.empty() ? nullptr : cmd->task_id.c_str());
        return;
    }

    // handler 返回 "__async_ack__" 表示已自行异步回执（如 GET_LOG_FILE 两段回执），
    // 主线程不再补发。
    if (resp->msg == "__async_ack__") return;

    publishCmdResp(*cmd, *resp);
}

int Framework::publishCmdResp(const InboundCommand& cmd, const Response& resp) {
    std::string payload;

    // 业务 taskId（proto field 1），供回执日志对账。
    const std::string taskId = Envelope::extractTaskId(cmd.payload);

    // GET_CAPTURE_PACKET_INTERFACE：返回支持抓包的接口列表（规范 §4.3.2.18）。
    if (cmd.cmd_type == "GET_CAPTURE_PACKET_INTERFACE") {
        proto::GetCapturePacketInterfaceRsp out;
        out.set_code(resp.code);
        out.set_msg(resp.msg);
        auto* body = out.mutable_response();
        body->set_status(resp.code.empty() ? "0" : resp.code);
        body->set_msg(resp.msg);
        for (const auto& iface : resp.interface_list) body->add_interfacelist(iface);
        out.SerializeToString(&payload);
    } else {
        // 默认操作响应（附录 A）：SetCommonRsp。
        // 顶层 code/msg 恒为 0/ok（传输帧），业务状态放 response.status/msg。
        proto::SetCommonRsp out;
        out.set_code("0");
        out.set_msg("ok");
        auto* body = out.mutable_response();
        body->set_status(resp.code.empty() ? "0" : resp.code);
        body->set_msg(resp.msg);
        out.SerializeToString(&payload);
    }

    MqttHeader hdr;
    // ack 头部 cmdType 回显实际命令类型（非字面 cmd_resp）。
    hdr.cmd_type = cmd.cmd_type;
    hdr.correlation_data = cmd.task_id;
    mMqtt->setV5Header(hdr);
    std::string topic = buildCmdRespTopic(mCfg.device.device_type, DeviceId(mCfg.device));
    mMqtt->publish(topic, payload, 1);
    ALOGI("[fw] cmd_resp %s taskId=%s corr=%s → %s (%zu bytes)", cmd.cmd_type.c_str(),
          taskId.empty() ? "-" : taskId.c_str(), cmd.task_id.c_str(), topic.c_str(),
          payload.size());
    return 0;
}

// 异步回执原语（来源：emu_0827 同事方案）：业务 worker 线程补发 SetCommonRsp 回执。
// corr 优先（平台 correlation_data），否则用 task_id（proto field 1）。
int Framework::publishCmdRespRaw(const char* cmdType, const char* taskId, const char* status,
                                 const char* msg, const char* corr) {
    proto::SetCommonRsp out;
    out.set_code("0");
    out.set_msg("ok");
    auto* body = out.mutable_response();
    body->set_status(status);
    body->set_msg(msg);
    std::string payload;
    out.SerializeToString(&payload);

    MqttHeader hdr;
    hdr.cmd_type = cmdType;
    hdr.correlation_data = (corr && *corr) ? corr : (taskId ? taskId : "");
    mMqtt->setV5Header(hdr);
    std::string topic = buildCmdRespTopic(mCfg.device.device_type, DeviceId(mCfg.device));
    mMqtt->publish(topic, payload, 1);
    ALOGI("[fw] cmd_resp %s taskId=%s corr=%s status=%s msg=%s → %s (%zu bytes)", cmdType,
          taskId ? taskId : "-", hdr.correlation_data.c_str(), status, msg, topic.c_str(),
          payload.size());
    return 0;
}

int Framework::publishEvent(const std::string& eventClass, const std::string& payload,
                            const std::string& correlationData) {
    auto route = mCfg.findEventRoute(eventClass);
    if (!route) {
        ALOGW("[fw] no event route for %s", eventClass.c_str());
        return -1;
    }

    MqttHeader hdr;
    hdr.event_type = route->mqtt_event;
    // 回显下行 correlation_data（升级等异步回传对账用，由业务域 resolve 后传入）。
    hdr.correlation_data = correlationData;
    mMqtt->setV5Header(hdr);
    mMqtt->publish(buildEventTopic(mCfg.device.device_type), payload, 1);
    ALOGI("[fw] event %s → %s (%zu bytes)", eventClass.c_str(), route->mqtt_event.c_str(),
          payload.size());
    return 0;
}

// 异步任务状态事件上报（protobuf EventUpgradeRet）helper：
// 合并 UpgradeFeature::onReport 与 NioFeature::onFileResult 两处重复构造；
// correlation_data 回显下行（cache 命中）或 taskId 兜底。
// clearCorr：终态由调用方传 true 清理对账缓存，防长期运行无界增长。
int Framework::publishTaskEvent(const std::string& eventClass, const std::string& taskId,
                                const std::string& status, const std::string& msg,
                                bool clearCorr) {
    if (hasRoute(eventClass)) {
        proto::EventUpgradeRet evt;
        evt.set_sn(mCfg.device.sn);
        evt.set_mac(mCfg.device.mac);
        auto* params = evt.mutable_params();
        params->set_taskid(taskId);
        params->set_status(status.empty() ? "0" : status);
        params->set_msg(msg);
        publishEvent(eventClass, evt.SerializeAsString(), mCorrCache.resolve(taskId, ""));
    }
    if (clearCorr) mCorrCache.clear(taskId);
    return 0;
}

// ---------------- 连接工作模式编排（来源：emu_0907 同事方案） ----------------

void Framework::businessStart(const char* reason) {
    if (mWorkMode) mWorkMode->onBusinessStart(reason);
}

void Framework::businessEnd(const char* reason) {
    if (mWorkMode) mWorkMode->onBusinessEnd(reason);
}

bool Framework::workModeBlocksConnect() const {
    if (mWorkmodeWake.load()) return false;
    if (!mWorkMode) return false;
    return !mWorkMode->allowFaultReconnect();
}

void Framework::workModeOfflineSync(const char* reason) {
    ALOGI("[workmode] offline sync begin reason=%s", reason ? reason : "-");
    mIntentionalDisconnect = true;
    if (mHeartbeat) mHeartbeat->stop();
    if (mMqtt) {
        mMqtt->setDisconnectCallback(nullptr);
        mMqtt->setMessageCallback(nullptr);
        mMqtt->disconnect();
    }
    ALOGI("[workmode] offline sync done reason=%s mqtt=down heartbeat=off",
          reason ? reason : "-");
}

void Framework::workModeOffline(const char* reason) {
    // 立即关门闩，真正 disconnect 放独立线程：
    // 1) 避免在 mosquitto 回调线程里 loop_stop；
    // 2) 给 QoS1 ACK 留出离开 loop 的窗口。
    mIntentionalDisconnect = true;
    const std::string why = reason ? reason : "workmode_offline";
    ALOGI("[workmode] offline schedule reason=%s", why.c_str());

    std::lock_guard<std::mutex> lk(mOfflineMu);
    // 已结束的 offline 线程仍 joinable，必须 reap 后再启，否则第二次 Idle 永不 disconnect。
    // 若仍在飞行中：只 coalesce（门闩已立），禁止在 MQTT 回调里 join→与 loop_stop 死锁。
    if (mOfflineThread.joinable()) {
        if (!mOfflineDone.load()) {
            ALOGI("[workmode] offline coalesce inflight=1");
            return;
        }
        ALOGI("[workmode] offline reap prior thread");
        mOfflineThread.join();
    }

    mOfflineDone = false;
    mOfflineThread = std::thread([this, why] {
        for (int i = 0; i < 5 && mRunning.load() && !mStopRequested.load(); ++i)
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        if (!mStopRequested.load()) workModeOfflineSync(why.c_str());
        mOfflineDone = true;
    });
}

int Framework::workModeOnline(const char* reason) {
    if (!mRunning.load() || mStopRequested.load()) {
        ALOGE("[workmode] online abort reason=%s running=0", reason ? reason : "-");
        return -1;
    }
    ALOGI("[workmode] online begin reason=%s", reason ? reason : "-");
    mWorkmodeWake = true;
    const int rc = doConnectAndRegister();
    mWorkmodeWake = false;
    ALOGI("[workmode] online end reason=%s rc=%d", reason ? reason : "-", rc);
    return rc;
}

void Framework::applyRegisterWorkMode() {
    if (!mWorkMode || !mRegister) return;
    const RegisterResult& r = mRegister->result();
    if (!r.success) {
        ALOGI("[workmode] reg_resp skip reason=unpack_or_fail");
        return;
    }
    if (!r.code.empty() && r.code != "0") {
        ALOGI("[workmode] reg_resp skip reason=code code=%s", r.code.c_str());
        return;
    }

    WorkModeApplyIn in;
    in.work_mode = r.work_mode;
    in.period = r.period;
    in.has_next = r.has_next;
    in.has_has_next = r.has_has_next;

    if (r.work_mode.empty() && !r.has_has_next && r.period.empty()) {
        ALOGI("[workmode] reg_resp skip reason=empty keep=%d", mWorkMode->connMode());
        return;
    }

    std::string err;
    // reg 在 MQTT 回调线程：需断连时 defer，随后异步 offline（与 SET 同路径）
    const bool may_offline = !r.work_mode.empty();
    if (mWorkMode->apply("reg_resp", in, &err, may_offline) != 0) {
        ALOGE("[workmode] reg_resp apply FAIL err=%s keep=1", err.c_str());
        return;
    }
    if (!r.work_mode.empty()) mCfg.device.work_mode = r.work_mode;

    std::string off_reason;
    if (mWorkMode->consumePendingOffline(&off_reason)) {
        ALOGI("[workmode] reg_resp ack_keep_then_offline reason=%s", off_reason.c_str());
        workModeOffline(off_reason.c_str());
    }
    ALOGI("[workmode] reg_resp apply OK mode=%s period=%s hasNext=%d",
          r.work_mode.empty() ? "-" : r.work_mode.c_str(),
          r.period.empty() ? "-" : r.period.c_str(), r.has_next ? 1 : 0);
}

std::optional<Response> Framework::onSetWorkMode(const InboundCommand& cmd) {
    if (!mWorkMode) return Response{"-1", "workmode unavailable"};

    proto::SetWorkMode msg;
    if (!msg.ParseFromString(cmd.payload)) {
        ALOGE("[workmode] SET_WORK_MODE FAIL reason=parse");
        return Response{"-1", "parse error"};
    }

    WorkModeApplyIn in;
    in.work_mode = msg.workmode();
    in.period = msg.period();
    in.has_has_next = msg.has_hasnext();
    in.has_next = in.has_has_next && msg.hasnext();

    ALOGI("[workmode] SET_WORK_MODE rx workMode=%s period=%s hasNext=%d present=%d",
          in.work_mode.empty() ? "-" : in.work_mode.c_str(),
          in.period.empty() ? "-" : in.period.c_str(), in.has_next ? 1 : 0,
          in.has_has_next ? 1 : 0);

    std::string err;
    // defer_offline：先关门闩，ACK 成功回执后再异步断 MQTT
    if (mWorkMode->apply("SET_WORK_MODE", in, &err, true) != 0) {
        ALOGE("[workmode] SET_WORK_MODE FAIL err=%s", err.c_str());
        return Response{"-1", err.empty() ? "reject" : err};
    }
    if (!in.work_mode.empty()) mCfg.device.work_mode = in.work_mode;

    std::string off_reason;
    const bool need_off = mWorkMode->consumePendingOffline(&off_reason);

    ALOGI("[workmode] SET_WORK_MODE OK mode=%d period_h=%d hasNext=%d pending_off=%d",
          mWorkMode->connMode(), mWorkMode->periodH(), mWorkMode->hasNext() ? 1 : 0,
          need_off ? 1 : 0);

    if (!need_off) return Response{"0", "ok"};

    // 需离线：先补发成功回执，再异步断 MQTT（回执发不出去会丢平台确认）。
    const std::string task_id = Envelope::extractTaskId(cmd.payload);
    publishCmdRespRaw(cmd.cmd_type.c_str(), task_id.c_str(), "0", "ok",
                      cmd.task_id.empty() ? nullptr : cmd.task_id.c_str());
    ALOGI("[workmode] SET_WORK_MODE ack_then_offline reason=%s", off_reason.c_str());
    workModeOffline(off_reason.c_str());

    Response r;
    r.msg = "__async_ack__";  // 已自行补发回执，主线程不再补发
    return r;
}

int Framework::registerCmdHandler(const std::string& cmdType, CommandHandler handler) {
    mRegistry.registerHandler(cmdType, std::move(handler));
    return 0;
}

bool Framework::hasRoute(const std::string& eventClass) const {
    return mCfg.findEventRoute(eventClass).has_value();
}

}  // namespace emu
