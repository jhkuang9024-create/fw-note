// 认证会话：HTTP Digest (SHA-256) → JWT/token → MQTT 连接参数。
#ifndef EMU_AUTH_H
#define EMU_AUTH_H

#include <memory>
#include <string>

#include "Config.h"
#include "HttpClient.h"

namespace emu {

struct AuthResult {
    bool success = false;
    std::string error;

    // Step 3 (authAddress POST) 返回的 token/MQTT 参数
    std::string jwt;
    std::string mqtt_ip;
    int mqtt_port = 0;
    int keep_alive = 60;
    int server_keep_alive = 0;
    int conn_delay = 0;
    std::string mode;
    std::string ssl_cert;
    std::string client_ip;
};

class AuthSession {
  public:
    AuthSession(const AuthConfig& cfg, const DeviceConfig& device,
                std::shared_ptr<IHttpClient> http);
    ~AuthSession() = default;

    // 执行完整认证流程；结果缓存在内部
    const AuthResult& run();

    // 重置会话状态（断线重认证时复用同一 AuthSession 重新走完整流程）
    void reset();

  private:
    std::string buildAuthorization(const std::string& method, const std::string& uri,
                                   const std::string& realm, const std::string& nonce,
                                   const std::string& qop);

    AuthConfig mCfg;
    DeviceConfig mDevice;
    std::shared_ptr<IHttpClient> mHttp;
    AuthResult mResult;
    int mNc = 0;
    std::string mCnonce;
    bool mDone = false;
};

}  // namespace emu

#endif  // EMU_AUTH_H
