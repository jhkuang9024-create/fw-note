// 业务占用标记（RAII）：任务执行期间对连接工作模式控制器声明“忙”，
// 短连（mode=1）在线时不会因 5 分钟空闲租约到期而下线休眠。
// 来源：emu_0907 同事方案 businessStart/businessEnd。
#ifndef EMU_BUSY_GUARD_H
#define EMU_BUSY_GUARD_H

#include "Framework.h"

namespace emu {

class BusyGuard {
  public:
    BusyGuard(Framework& fw, const char* tag) : mFw(fw), mTag(tag) {
        mFw.businessStart(mTag);
    }
    ~BusyGuard() { mFw.businessEnd(mTag); }

    BusyGuard(const BusyGuard&) = delete;
    BusyGuard& operator=(const BusyGuard&) = delete;

  private:
    Framework& mFw;
    const char* mTag;
};

}  // namespace emu

#endif  // EMU_BUSY_GUARD_H
