// WorkModeController：连接工作模式状态机。
// （移植自 emu_0907 参考实现；日志宏 mqtt_log_i/e → ALOGI/ALOGE）
#define LOG_TAG "emud"
#include <log/log.h>

#include "WorkModeController.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <fstream>

namespace emu {
namespace {

const char* ModeName(int m) {
    switch (m) {
        case kWorkModeShort:
            return "short";
        case kWorkModeNone:
            return "none";
        default:
            return "long";
    }
}

}  // namespace

WorkModeController::~WorkModeController() {
    stop();
}

void WorkModeController::start(std::string runtime_dir, OfflineFn offline, OnlineFn online) {
    stop();
    {
        std::lock_guard<std::mutex> lk(mu_);
        runtime_dir_ = std::move(runtime_dir);
        offline_fn_ = std::move(offline);
        online_fn_ = std::move(online);
        const int file_p = loadPeriodFile();
        if (file_p > 0) period_h_ = file_p;
        conn_mode_ = kWorkModeLong;
        phase_ = kOnline;
        busy_ = 0;
        has_next_ = false;
        idle_deadline_ = 0;
        wake_at_ = 0;
        auto_reconnect_ = true;
        pending_offline_ = false;
        pending_offline_reason_.clear();
        running_ = true;
    }
    timer_ = std::thread([this]() { timerMain(); });
    ALOGI("[workmode] start runtime=%s period_h=%d", runtime_dir_.c_str(), period_h_);
}

void WorkModeController::stop() {
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!running_) return;
        running_ = false;
    }
    cv_.notify_all();
    if (timer_.joinable()) timer_.join();
    ALOGI("[workmode] stop");
}

void WorkModeController::timerMain() {
    while (true) {
        std::unique_lock<std::mutex> lk(mu_);
        cv_.wait_for(lk, std::chrono::seconds(1), [this]() { return !running_; });
        if (!running_) break;
        evaluateLocked(lk);
    }
}

void WorkModeController::evaluateLocked(std::unique_lock<std::mutex>& lk) {
    if (conn_mode_ == kWorkModeLong) return;
    if (conn_mode_ == kWorkModeNone) return;

    // mode=1
    if (phase_ == kSleeping) {
        if (wake_at_ > 0 && std::time(nullptr) >= wake_at_) {
            ALOGI("[workmode] decide wake reason=period_elapsed period_h=%d", period_h_);
            requestWakeLocked("period_wake", lk);
        }
        return;
    }

    // online short
    if (has_next_) {
        return;
    }
    if (busy_ > 0) {
        return;
    }
    if (idle_deadline_ <= 0) return;
    if (std::time(nullptr) < idle_deadline_) return;

    ALOGI("[workmode] decide offline reason=idle_lease_expired lease_sec=%d", kIdleLeaseSec);
    enterSleepLocked("active_idle", lk, false);
}

void WorkModeController::armIdleLocked(const char* why) {
    idle_deadline_ = std::time(nullptr) + kIdleLeaseSec;
    ALOGD("[workmode] active arm_sec=%d why=%s deadline=%lld", kIdleLeaseSec, why ? why : "-",
          static_cast<long long>(idle_deadline_));
}

void WorkModeController::enterSleepLocked(const char* reason, std::unique_lock<std::mutex>& lk,
                                          bool defer_offline) {
    if (phase_ == kSleeping) return;
    auto_reconnect_ = false;
    phase_ = kSleeping;
    idle_deadline_ = 0;
    if (conn_mode_ == kWorkModeShort) {
        wake_at_ = std::time(nullptr) + static_cast<time_t>(period_h_) * 3600;
        ALOGI("[workmode] sleep wake_in_sec=%lld period_h=%d reason=%s gate=fault_off",
              static_cast<long long>(wake_at_ - std::time(nullptr)), period_h_,
              reason ? reason : "-");
    } else {
        wake_at_ = 0;
        ALOGI("[workmode] offline sticky mode=none reason=%s gate=fault_off",
              reason ? reason : "-");
    }
    ALOGI("[workmode] gate fault_reconnect=0 reason=%s",
          conn_mode_ == kWorkModeShort ? "mode1_sleep" : "mode2");

    if (defer_offline) {
        pending_offline_ = true;
        pending_offline_reason_ = reason ? reason : "workmode_offline";
        ALOGD("[workmode] offline deferred reason=%s", pending_offline_reason_.c_str());
        return;
    }

    pending_offline_ = false;
    pending_offline_reason_.clear();
    OfflineFn fn = offline_fn_;
    lk.unlock();
    if (fn) fn(reason ? reason : "workmode_offline");
    lk.lock();
}

bool WorkModeController::consumePendingOffline(std::string* reason) {
    std::lock_guard<std::mutex> lk(mu_);
    if (!pending_offline_) return false;
    pending_offline_ = false;
    if (reason) *reason = pending_offline_reason_;
    pending_offline_reason_.clear();
    return true;
}

void WorkModeController::requestWakeLocked(const char* reason, std::unique_lock<std::mutex>& lk) {
    wake_at_ = 0;
    OnlineFn fn = online_fn_;
    lk.unlock();
    int rc = fn ? fn(reason ? reason : "workmode_online") : -1;
    lk.lock();
    if (rc == 0) {
        // onPipelineOnline 会由 Framework 在成功后调用；此处兜底
        if (phase_ == kSleeping && conn_mode_ == kWorkModeShort) {
            phase_ = kOnline;
            auto_reconnect_ = true;
            armIdleLocked("wake_ok");
        }
        ALOGI("[workmode] online start reason=%s rc=0", reason ? reason : "-");
    } else {
        // 失败则短连稍后重试（60s）
        if (conn_mode_ == kWorkModeShort) {
            wake_at_ = std::time(nullptr) + 60;
            phase_ = kSleeping;
            auto_reconnect_ = false;
            ALOGE("[workmode] online FAIL reason=%s retry_in_sec=60", reason ? reason : "-");
        }
    }
}

void WorkModeController::onPipelineOnline() {
    std::lock_guard<std::mutex> lk(mu_);
    if (conn_mode_ == kWorkModeNone) {
        auto_reconnect_ = false;
        phase_ = kSleeping;
        wake_at_ = 0;
        pending_offline_ = true;
        pending_offline_reason_ = "mode2_reject_online";
        ALOGI("[workmode] pipeline online rejected mode=none pending_off=1");
        return;
    }
    phase_ = kOnline;
    wake_at_ = 0;
    auto_reconnect_ = true;
    if (conn_mode_ == kWorkModeShort) {
        armIdleLocked("pipeline_online");
    } else {
        idle_deadline_ = 0;
    }
    ALOGI("[workmode] pipeline online mode=%d(%s) fault_reconnect=1", conn_mode_,
          ModeName(conn_mode_));
}

bool WorkModeController::allowFaultReconnect() const {
    std::lock_guard<std::mutex> lk(mu_);
    if (conn_mode_ == kWorkModeNone) return false;
    if (conn_mode_ == kWorkModeShort && phase_ == kSleeping) return false;
    return auto_reconnect_;
}

int WorkModeController::connMode() const {
    std::lock_guard<std::mutex> lk(mu_);
    return conn_mode_;
}

int WorkModeController::periodH() const {
    std::lock_guard<std::mutex> lk(mu_);
    return period_h_;
}

bool WorkModeController::hasNext() const {
    std::lock_guard<std::mutex> lk(mu_);
    return has_next_;
}

bool WorkModeController::isSleeping() const {
    std::lock_guard<std::mutex> lk(mu_);
    return phase_ == kSleeping;
}

void WorkModeController::onBusinessStart(const char* reason) {
    std::lock_guard<std::mutex> lk(mu_);
    ++busy_;
    ALOGD("[workmode] busy start reason=%s count=%d freeze=1", reason ? reason : "-", busy_);
}

void WorkModeController::onBusinessEnd(const char* reason) {
    std::lock_guard<std::mutex> lk(mu_);
    if (busy_ > 0) --busy_;
    ALOGD("[workmode] busy end reason=%s count=%d mode=%d phase=%d", reason ? reason : "-",
          busy_, conn_mode_, static_cast<int>(phase_));
    if (busy_ == 0 && conn_mode_ == kWorkModeShort && phase_ == kOnline) {
        armIdleLocked("busy_idle");
    }
}

void WorkModeController::onLightActivity() {
    std::lock_guard<std::mutex> lk(mu_);
    if (conn_mode_ != kWorkModeShort || phase_ != kOnline) return;
    if (busy_ > 0) return;
    armIdleLocked("light_cmd");
}

int WorkModeController::parseMode(const std::string& s, bool* ok) {
    if (ok) *ok = false;
    if (s.empty()) return kWorkModeLong;
    char* end = nullptr;
    long v = std::strtol(s.c_str(), &end, 10);
    if (!end || *end != '\0') return kWorkModeLong;
    if (v < 0 || v > 2) return kWorkModeLong;
    if (ok) *ok = true;
    return static_cast<int>(v);
}

bool WorkModeController::parsePeriodH(const std::string& s, int* out) {
    if (s.empty() || !out) return false;
    char* end = nullptr;
    long v = std::strtol(s.c_str(), &end, 10);
    if (!end || *end != '\0') return false;
    if (v < kMinPeriodH || v > kMaxPeriodH) return false;
    *out = static_cast<int>(v);
    return true;
}

int WorkModeController::loadPeriodFile() const {
    if (runtime_dir_.empty()) return -1;
    const std::string path = runtime_dir_ + "/workmode.conf";
    std::ifstream in(path);
    if (!in) return -1;
    std::string line;
    while (std::getline(in, line)) {
        if (line.compare(0, 9, "period_h=") == 0) {
            int v = 0;
            if (parsePeriodH(line.substr(9), &v)) return v;
        }
    }
    return -1;
}

int WorkModeController::savePeriodFile(int period_h) const {
    if (runtime_dir_.empty()) return -1;
    if (period_h < kMinPeriodH || period_h > kMaxPeriodH) return -1;
    const std::string path = runtime_dir_ + "/workmode.conf";
    std::ofstream out(path, std::ios::trunc);
    if (!out) return -1;
    out << "period_h=" << period_h << "\n";
    out.flush();
    return out.good() ? 0 : -1;
}

int WorkModeController::resolvePeriodH(const std::string& server_period, const char** src_out) const {
    int v = 0;
    if (parsePeriodH(server_period, &v)) {
        if (src_out) *src_out = "server";
        return v;
    }
    const int file_p = loadPeriodFile();
    if (file_p > 0) {
        if (src_out) *src_out = "file";
        return file_p;
    }
    if (src_out) *src_out = "default";
    return kDefaultPeriodH;
}

int WorkModeController::applyIncrementalLocked(const WorkModeApplyIn& in, std::string* err_msg,
                                               std::unique_lock<std::mutex>& lk) {
    (void)lk;
    if (!in.has_has_next && in.period.empty()) {
        if (err_msg) *err_msg = "empty";
        ALOGE("[workmode] reject reason=empty_incremental");
        return -1;
    }

    if (!in.period.empty()) {
        int period_v = 0;
        if (!parsePeriodH(in.period, &period_v)) {
            if (err_msg) *err_msg = "bad_period";
            ALOGE("[workmode] reject reason=bad_period raw=%s keep=1", in.period.c_str());
            return -1;
        }
        if (conn_mode_ != kWorkModeShort) {
            if (err_msg) *err_msg = "period_not_short";
            ALOGE("[workmode] reject reason=period_not_short mode=%d keep=1", conn_mode_);
            return -1;
        }
        const int prc = savePeriodFile(period_v);
        period_h_ = period_v;
        ALOGI("[workmode] persist period_h=%d path=%s/workmode.conf rc=%d src=incremental",
              period_v, runtime_dir_.c_str(), prc);
        if (phase_ == kSleeping) {
            wake_at_ = std::time(nullptr) + static_cast<time_t>(period_h_) * 3600;
            ALOGI("[workmode] sleep refresh wake_in_sec=%lld period_h=%d",
                  static_cast<long long>(wake_at_ - std::time(nullptr)), period_h_);
        }
    }
    if (in.has_has_next) {
        has_next_ = in.has_next;
        ALOGI("[workmode] incremental hasNext=%d mode=%d", has_next_ ? 1 : 0, conn_mode_);
    }
    return 0;
}

int WorkModeController::apply(const char* src, const WorkModeApplyIn& in, std::string* err_msg,
                              bool defer_offline) {
    // 文档字段均为 optional：无 workMode 时仅增量更新 hasNext / period
    if (in.work_mode.empty()) {
        std::unique_lock<std::mutex> lk(mu_);
        const int rc = applyIncrementalLocked(in, err_msg, lk);
        if (rc == 0) {
            ALOGI("[workmode] apply src=%s incremental=1 mode=%d period_h=%d hasNext=%d",
                  src ? src : "-", conn_mode_, period_h_, has_next_ ? 1 : 0);
        }
        return rc;
    }

    bool mode_ok = false;
    const int new_mode = parseMode(in.work_mode, &mode_ok);
    if (!mode_ok) {
        if (err_msg) *err_msg = "bad_mode";
        ALOGE("[workmode] reject reason=bad_mode raw=%s src=%s", in.work_mode.c_str(),
              src ? src : "-");
        return -1;
    }

    // mode=1 且显式带了非法 period → 拒绝（不改态）
    if (new_mode == kWorkModeShort && !in.period.empty()) {
        int tmp = 0;
        if (!parsePeriodH(in.period, &tmp)) {
            if (err_msg) *err_msg = "bad_period";
            ALOGE("[workmode] reject reason=bad_period raw=%s src=%s keep=1",
                  in.period.c_str(), src ? src : "-");
            return -1;
        }
    }

    std::unique_lock<std::mutex> lk(mu_);
    const int old_mode = conn_mode_;
    const char* period_src = "default";
    int new_period = period_h_;
    if (new_mode == kWorkModeShort) {
        new_period = resolvePeriodH(in.period, &period_src);
    }

    bool persist_ok = true;
    if (new_mode == kWorkModeShort && period_src && std::strcmp(period_src, "server") == 0) {
        const int prc = savePeriodFile(new_period);
        persist_ok = (prc == 0);
        ALOGI("[workmode] persist period_h=%d path=%s/workmode.conf rc=%d", new_period,
              runtime_dir_.c_str(), prc);
    }

    conn_mode_ = new_mode;
    period_h_ = new_period;
    if (in.has_has_next) has_next_ = in.has_next;

    ALOGI("[workmode] apply src=%s from=%d to=%d period_h=%d period_src=%s hasNext=%d "
          "persist=%d defer_off=%d",
          src ? src : "-", old_mode, new_mode, period_h_, period_src, has_next_ ? 1 : 0,
          persist_ok ? 1 : 0, defer_offline ? 1 : 0);

    if (new_mode == kWorkModeLong) {
        auto_reconnect_ = true;
        wake_at_ = 0;
        idle_deadline_ = 0;
        pending_offline_ = false;
        pending_offline_reason_.clear();
        if (phase_ == kSleeping) {
            ALOGI("[workmode] decide wake reason=SET_mode0");
            requestWakeLocked("SET_mode0", lk);
        } else {
            phase_ = kOnline;
        }
        return 0;
    }

    if (new_mode == kWorkModeNone) {
        if (phase_ == kOnline) {
            enterSleepLocked("SET_mode2", lk, defer_offline);
        } else {
            auto_reconnect_ = false;
            wake_at_ = 0;
            ALOGI("[workmode] gate fault_reconnect=0 reason=mode2");
        }
        return 0;
    }

    // short
    pending_offline_ = false;
    pending_offline_reason_.clear();
    if (phase_ == kOnline) {
        auto_reconnect_ = true;
        armIdleLocked("apply_short");
    } else if (phase_ == kSleeping) {
        auto_reconnect_ = false;
        wake_at_ = std::time(nullptr) + static_cast<time_t>(period_h_) * 3600;
        ALOGI("[workmode] sleep refresh wake_in_sec=%lld period_h=%d",
              static_cast<long long>(wake_at_ - std::time(nullptr)), period_h_);
    } else {
        phase_ = kOnline;
        auto_reconnect_ = true;
        armIdleLocked("apply_short");
    }
    return 0;
}

}  // namespace emu
