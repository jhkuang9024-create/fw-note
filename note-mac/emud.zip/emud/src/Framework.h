// Framework：进程内编排（auth → mqtt → subscribe → register → 主循环）。
// 事件上报、命令回执均为进程内方法调用（无 IChannel）。
#ifndef EMU_FRAMEWORK_H
#define EMU_FRAMEWORK_H

#include <atomic>
#include <memory>
#include <string>
#include <thread>

#include "ActionHandler.h"
#include "Auth.h"
#include "Command.h"
#include "CommandRegistry.h"
#include "Config.h"
#include "CorrelationCache.h"
#include "Heartbeat.h"
#include "HttpClient.h"
#include "MqttClient.h"
#include "Offline.h"
#include "Register.h"
#include "WorkModeController.h"

namespace emu {

class Framework {
  public:
    Framework(Config cfg, std::shared_ptr<IMqttClient> mqtt, std::shared_ptr<IHttpClient> http);
    ~Framework();

    // 配置 / 数据目录完全硬编码（见 Config.h 的 kSystemConfigPath / kDataDir）。
    static std::unique_ptr<Framework> create(std::shared_ptr<IMqttClient> mqtt,
                                             std::shared_ptr<IHttpClient> http);

    int start();  // auth → mqtt → subscribe → register → 主循环
    void stop();  // offline → 停心跳 → 断 mqtt

    // 进程内事件 / 回执
    // payload 为已序列化的 protobuf 二进制（对应 event_routes 配置的 mqtt_event 路由）。
    // correlationData：随事件回显的下行 correlation_data（为空则不带）；升级等异步回传
    // 由业务域传入对账值。
    int publishEvent(const std::string& eventClass, const std::string& payload,
                     const std::string& correlationData = "");
    int publishCmdResp(const InboundCommand& cmd, const Response& resp);

    // 异步回执原语（来源：emu_0827 同事方案）：
    // 供业务 worker 线程在命令处理完成后主动补发 SetCommonRsp 回执
    // （cmd_type 回显命令类型，corr 优先于 task_id 作为 correlation_data）。
    int publishCmdRespRaw(const char* cmdType, const char* taskId, const char* status,
                          const char* msg, const char* corr);

    // 异步任务状态事件 helper（合并 UpgradeFeature::onReport / NioFeature::onFileResult
    // 重复的 EventUpgradeRet 构造 + correlation 清理逻辑）：
    //  - eventClass 无 event_routes 配置时不投递（不产生 ALOGW）；
    //  - status 为空统一 "0"；correlation_data 用 cache 命中值，否则 task_id 兜底；
    //  - clearCorr 为 true（调用方仅在业务终态时传）时清理对账缓存。
    int publishTaskEvent(const std::string& eventClass, const std::string& taskId,
                         const std::string& status, const std::string& msg, bool clearCorr);

    // 域注册入口
    int registerCmdHandler(const std::string& cmdType, CommandHandler handler);
    bool hasRoute(const std::string& eventClass) const;

    // 业务忙闲通知（来源：emu_0907 同事方案）：长任务（OTA/文件下载/抓包/抓日志/
    // 远程 shell）执行期间调用 businessStart/End，冻结短连接空闲下线的判断，
    // 避免任务执行到一半被 Idle Lease 断开。
    void businessStart(const char* reason);
    void businessEnd(const char* reason);

    // 工具
    const DeviceConfig& device() const { return mCfg.device; }
    CorrelationCache& correlation() { return mCorrCache; }
    std::shared_ptr<IHttpClient> http() { return mHttp; }

    // 入站消息入口（由 MQTT 回调调用）
    void onMqttMessage(const MqttMessage& msg);
    // 断线回调入口（由 MQTT 网络线程调用）：JWT 过期等导致断线时重新认证并刷新凭据，
    // 等待 libmosquitto 自动重连后以新凭据恢复连接。
    void onMqttDisconnected(int rc);

    // 命令回执 / 事件 topic 构造（deviceId：MAC 优先，SN 兜底）
    static std::string buildCmdRespTopic(const std::string& deviceType,
                                         const std::string& deviceId);
    static std::string buildEventTopic(const std::string& deviceType);

  private:
    int doSubscribe();
    int doRegister();

    // 完整上线管道（boot / wake 共用）：
    // 门闩检查 → 主动断开旧连接 → auth → connDelay → connect → 订阅/注册/心跳。
    int doConnectAndRegister();
    bool workModeBlocksConnect() const;
    void workModeOffline(const char* reason);
    void workModeOfflineSync(const char* reason);
    int workModeOnline(const char* reason);
    void applyRegisterWorkMode();
    std::optional<Response> onSetWorkMode(const InboundCommand& cmd);

    Config mCfg;
    std::shared_ptr<IMqttClient> mMqtt;
    std::shared_ptr<IHttpClient> mHttp;

    std::unique_ptr<AuthSession> mAuth;
    std::unique_ptr<RegisterService> mRegister;
    std::unique_ptr<Heartbeat> mHeartbeat;
    std::unique_ptr<Offline> mOffline;
    CommandRegistry mRegistry;
    CorrelationCache mCorrCache;
    ActionHandler mActionHandler;

    AuthResult mAuthResult;
    std::atomic<bool> mRunning{false};
    // 断线重认证线程（仅网络线程触发创建，stop 时 join）。
    // joinable() 无法表达“线程是否活跃”：完成未 join 的线程 joinable() 恒为 true，
    // 再次断线会误判“已在重认证”而永久跳过（#1）。用 mReauthRunning 表达运行态。
    std::atomic<bool> mReauthRunning{false};
    std::thread mReauthThread;

    // 连接工作模式编排（来源：emu_0907 同事方案）
    std::unique_ptr<WorkModeController> mWorkMode;
    std::atomic<bool> mStopRequested{false};          // 停止中：管道各阶段快速退出
    std::atomic<bool> mIntentionalDisconnect{false};  // 主动断开窗口：抑制断线回调重连编排
    std::atomic<bool> mWorkmodeWake{false};           // 主动上线窗口：绕过模式门闩
    // 离线执行线程（workModeOffline 只关门闩 + 起线程，真正 disconnect 放这里：
    // 避免在 mosquitto 回调线程里 loop_stop；也给 QoS1 ACK 留出离开 loop 的窗口）
    std::mutex mOfflineMu;
    std::thread mOfflineThread;
    std::atomic<bool> mOfflineDone{true};
};

}  // namespace emu

#endif  // EMU_FRAMEWORK_H
