#define LOG_TAG "emud"
#include <log/log.h>

#include "UciMqttClient.h"

#include <mosquitto.h>
#include <mqtt_protocol.h>

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>

namespace emu {

namespace {

// libmosquitto 全局初始化是引用计数的，避免多实例重复 init/cleanup。
std::mutex g_lib_mu;
int g_lib_refs = 0;

void LibInit() {
    std::lock_guard<std::mutex> lk(g_lib_mu);
    if (g_lib_refs++ == 0) mosquitto_lib_init();
}

void LibCleanup() {
    std::lock_guard<std::mutex> lk(g_lib_mu);
    if (--g_lib_refs == 0) mosquitto_lib_cleanup();
}

const char* MosqErrStr(int rc) {
    switch (rc) {
        case MOSQ_ERR_SUCCESS:
            return "success";
        case MOSQ_ERR_NOMEM:
            return "out of memory";
        case MOSQ_ERR_PROTOCOL:
            return "protocol error";
        case MOSQ_ERR_INVAL:
            return "invalid argument";
        case MOSQ_ERR_NO_CONN:
            return "not connected";
        case MOSQ_ERR_CONN_REFUSED:
            return "connection refused";
        case MOSQ_ERR_NOT_FOUND:
            return "not found";
        case MOSQ_ERR_CONN_LOST:
            return "connection lost";
        case MOSQ_ERR_TLS:
            return "TLS error";
        case MOSQ_ERR_PAYLOAD_SIZE:
            return "payload too large";
        case MOSQ_ERR_NOT_SUPPORTED:
            return "not supported";
        case MOSQ_ERR_AUTH:
            return "auth error";
        case MOSQ_ERR_ACL_DENIED:
            return "ACL denied";
        case MOSQ_ERR_UNKNOWN:
            return "unknown";
        case MOSQ_ERR_ERRNO:
            return "system error";
        case MOSQ_ERR_EAI:
            return "lookup error";
        case MOSQ_ERR_PROXY:
            return "proxy error";
        default:
            return "?";
    }
}

}  // namespace

UciMqttClient::UciMqttClient() {
    LibInit();
}

UciMqttClient::~UciMqttClient() {
    stopAndDestroy();
    LibCleanup();
}

void UciMqttClient::cleanupLocked() {
    if (mMosq) {
        if (mLoopStarted) {
            mosquitto_disconnect(mMosq);
            mosquitto_loop_stop(mMosq, true);
            mLoopStarted = false;
        }
        mosquitto_destroy(mMosq);
        mMosq = nullptr;
    }
    mConnected = false;
    mConnackReceived = false;
    mConnackRc = -1;
}

void UciMqttClient::stopAndDestroy() {
    struct mosquitto* mosq = nullptr;
    bool stopLoop = false;
    {
        std::lock_guard<std::mutex> lk(mMu);
        mosq = mMosq;
        stopLoop = mLoopStarted;
        if (mosq && stopLoop) mosquitto_disconnect(mosq);
    }
    if (mosq && stopLoop) {
        // 锁外等待网络线程退出：线程可能在用户回调（锁外）中等待 mu_ 发布消息，
        // 若持锁等待会互相死锁。
        mosquitto_loop_stop(mosq, true);
    }
    {
        std::lock_guard<std::mutex> lk(mMu);
        if (mosq) {
            mosquitto_destroy(mosq);
            mMosq = nullptr;
        }
        mLoopStarted = false;
        mConnected = false;
        mConnackReceived = false;
        mConnackRc = -1;
    }
}

int UciMqttClient::connect(const MqttConnectConfig& cfg) {
    std::string clientId = cfg.client_id.empty() ? "emud" : cfg.client_id;

    stopAndDestroy();  // 清理旧连接（首次调用时为空）

    {
        std::lock_guard<std::mutex> lk(mMu);
        mMosq = mosquitto_new(clientId.c_str(), true, this);
        if (!mMosq) {
            ALOGE("[mqtt] mosquitto_new failed");
            return MOSQ_ERR_NOMEM;
        }

        mosquitto_int_option(mMosq, MOSQ_OPT_PROTOCOL_VERSION, MQTT_PROTOCOL_V5);
        mosquitto_connect_v5_callback_set(mMosq, &UciMqttClient::onConnectV5);
        mosquitto_message_v5_callback_set(mMosq, &UciMqttClient::onMessageV5);
        mosquitto_disconnect_v5_callback_set(mMosq, &UciMqttClient::onDisconnectV5);
        mosquitto_log_callback_set(mMosq, &UciMqttClient::onLog);

        // LWT 遗嘱：异常掉线时由 broker 代发 cpe/{dt}/all/offline
        if (cfg.will_enable && !cfg.will_topic.empty()) {
            int rc = mosquitto_will_set(
                    mMosq, cfg.will_topic.c_str(), static_cast<int>(cfg.will_payload.size()),
                    cfg.will_payload.empty() ? nullptr : cfg.will_payload.data(), cfg.will_qos,
                    false);
            if (rc != MOSQ_ERR_SUCCESS) {
                ALOGW("[mqtt] will_set failed rc=%d (%s)", rc, MosqErrStr(rc));
            }
        }

        if (!cfg.username.empty()) {
            int rc = mosquitto_username_pw_set(mMosq, cfg.username.c_str(), cfg.password.c_str());
            if (rc != MOSQ_ERR_SUCCESS) {
                ALOGW("[mqtt] username_pw_set failed rc=%d (%s)", rc, MosqErrStr(rc));
            }
        }

        if (cfg.use_ssl) {
            const char* ca = cfg.ca_cert_path.empty() ? nullptr : cfg.ca_cert_path.c_str();
            int rc = mosquitto_tls_set(mMosq, ca, nullptr, nullptr, nullptr, nullptr);
            if (rc != MOSQ_ERR_SUCCESS) {
                ALOGE("[mqtt] tls_set failed rc=%d (%s)", rc, MosqErrStr(rc));
                cleanupLocked();
                return rc;
            }
            mosquitto_tls_insecure_set(mMosq, true);
        }
    }

    int rc = mosquitto_connect_async(mMosq, cfg.host.c_str(), cfg.port, cfg.keep_alive);
    if (rc != MOSQ_ERR_SUCCESS) {
        ALOGE("[mqtt] connect_async %s:%d failed rc=%d (%s)", cfg.host.c_str(), cfg.port, rc,
              MosqErrStr(rc));
        std::lock_guard<std::mutex> lk(mMu);
        cleanupLocked();
        return rc;
    }

    rc = mosquitto_loop_start(mMosq);
    if (rc != MOSQ_ERR_SUCCESS) {
        ALOGE("[mqtt] loop_start failed rc=%d (%s)", rc, MosqErrStr(rc));
        std::lock_guard<std::mutex> lk(mMu);
        cleanupLocked();
        return rc;
    }

    {
        std::lock_guard<std::mutex> lk(mMu);
        mLoopStarted = true;
    }

    // 等待 CONNACK（最多 5 秒），让 Connect 对上层表现为同步结果。
    bool connackTimeout = false;
    {
        std::unique_lock<std::mutex> lk(mMu);
        connackTimeout =
                !mCv.wait_for(lk, std::chrono::seconds(5), [this] { return mConnackReceived; });
        mConnected = (mConnackRc == 0);
        rc = mConnected ? 0 : mConnackRc;
    }

    if (connackTimeout) {
        ALOGW("[mqtt] connect %s:%d timed out waiting CONNACK (5s)", cfg.host.c_str(), cfg.port);
    }
    if (rc != 0) {
        ALOGE("[mqtt] connect %s:%d rc=%d (%s)", cfg.host.c_str(), cfg.port, rc, MosqErrStr(rc));
    } else {
        ALOGI("[mqtt] connected %s:%d client=%s", cfg.host.c_str(), cfg.port, clientId.c_str());
    }
    return rc;
}

int UciMqttClient::subscribe(const std::string& topic, int qos) {
    std::lock_guard<std::mutex> lk(mMu);

    // 记录订阅：断线重连（clean session 下 broker 侧订阅已清空）时由 onConnect 重放。
    bool found = false;
    for (auto& s : mSubs) {
        if (s.first == topic) {
            s.second = qos;
            found = true;
            break;
        }
    }
    if (!found) mSubs.emplace_back(topic, qos);

    if (!mMosq || !mConnected) {
        ALOGW("[mqtt] subscribe %s deferred until reconnect", topic.c_str());
        return MOSQ_ERR_NO_CONN;
    }
    int rc = mosquitto_subscribe_v5(mMosq, nullptr, topic.c_str(), qos, 0, nullptr);
    if (rc != MOSQ_ERR_SUCCESS) {
        ALOGW("[mqtt] subscribe %s failed rc=%d (%s)", topic.c_str(), rc, MosqErrStr(rc));
    } else {
        ALOGI("[mqtt] subscribe %s qos=%d", topic.c_str(), qos);
    }
    return rc;
}

int UciMqttClient::publish(const std::string& topic, const std::string& payload, int qos) {
    std::lock_guard<std::mutex> lk(mMu);
    if (!mMosq) return MOSQ_ERR_NO_CONN;

    int rc;
    if (mHeaderValid) {
        mosquitto_property* props = nullptr;
        rc = buildV5Properties(&props, mLastSendHeader);
        if (rc == MOSQ_ERR_SUCCESS) {
            rc = mosquitto_publish_v5(mMosq, nullptr, topic.c_str(),
                                      static_cast<int>(payload.size()), payload.data(), qos, false,
                                      props);
        }
        mosquitto_property_free_all(&props);
    } else {
        rc = mosquitto_publish(mMosq, nullptr, topic.c_str(), static_cast<int>(payload.size()),
                               payload.data(), qos, false);
    }

    // 一次性 header：本次发布消费后即失效，避免后续发布（如 Offline 离线通知）
    // 意外携带上次调用的 cmdType/eventType/correlation_data 属性。
    mHeaderValid = false;

    if (rc != MOSQ_ERR_SUCCESS) {
        ALOGE("[mqtt] publish %s failed rc=%d (%s)", topic.c_str(), rc, MosqErrStr(rc));
    }
    return rc;
}

bool UciMqttClient::isConnected() const {
    std::lock_guard<std::mutex> lk(mMu);
    return mConnected;
}

int UciMqttClient::disconnect() {
    stopAndDestroy();
    ALOGI("[mqtt] disconnected");
    return MOSQ_ERR_SUCCESS;
}

void UciMqttClient::setV5Header(const MqttHeader& h) {
    std::lock_guard<std::mutex> lk(mMu);
    mLastSendHeader = h;
    mHeaderValid = true;
}

void UciMqttClient::setMessageCallback(MqttMessageCallback cb) {
    std::lock_guard<std::mutex> lk(mMu);
    mCb = std::move(cb);
}

void UciMqttClient::setDisconnectCallback(MqttDisconnectCallback cb) {
    std::lock_guard<std::mutex> lk(mMu);
    mDisconnectCb = std::move(cb);
}

int UciMqttClient::updateCredentials(const std::string& username, const std::string& password) {
    std::lock_guard<std::mutex> lk(mMu);
    if (!mMosq) return MOSQ_ERR_NO_CONN;
    int rc = mosquitto_username_pw_set(mMosq, username.c_str(), password.c_str());
    if (rc != MOSQ_ERR_SUCCESS) {
        ALOGE("[mqtt] updateCredentials failed rc=%d (%s)", rc, MosqErrStr(rc));
    } else {
        ALOGI("[mqtt] credentials updated (username=%s)", username.c_str());
    }
    return rc;
}

int UciMqttClient::buildV5Properties(mosquitto_property** props, const MqttHeader& hdr) const {
    if (!hdr.correlation_data.empty()) {
        uint16_t len = static_cast<uint16_t>(hdr.correlation_data.size() > UINT16_MAX
                                                     ? UINT16_MAX
                                                     : hdr.correlation_data.size());
        int rc = mosquitto_property_add_binary(props, MQTT_PROP_CORRELATION_DATA,
                                               hdr.correlation_data.data(), len);
        if (rc != MOSQ_ERR_SUCCESS) return rc;
    }
    if (!hdr.cmd_type.empty()) {
        int rc = mosquitto_property_add_string_pair(props, MQTT_PROP_USER_PROPERTY, "cmdType",
                                                    hdr.cmd_type.c_str());
        if (rc != MOSQ_ERR_SUCCESS) return rc;
    }
    if (!hdr.event_type.empty()) {
        int rc = mosquitto_property_add_string_pair(props, MQTT_PROP_USER_PROPERTY, "eventType",
                                                    hdr.event_type.c_str());
        if (rc != MOSQ_ERR_SUCCESS) return rc;
    }
    int rc = mosquitto_property_add_string_pair(props, MQTT_PROP_USER_PROPERTY, "hasNext",
                                                hdr.has_next ? "true" : "false");
    if (rc != MOSQ_ERR_SUCCESS) return rc;
    if (!hdr.response_topic.empty()) {
        rc = mosquitto_property_add_string(props, MQTT_PROP_RESPONSE_TOPIC,
                                           hdr.response_topic.c_str());
        if (rc != MOSQ_ERR_SUCCESS) return rc;
    }
    return MOSQ_ERR_SUCCESS;
}

MqttHeader UciMqttClient::parseV5Header(const mosquitto_property* props) {
    MqttHeader hdr;
    if (!props) return hdr;

    for (const mosquitto_property* p = props; p; p = mosquitto_property_next(p)) {
        int id = mosquitto_property_identifier(p);

        if (id == MQTT_PROP_CORRELATION_DATA) {
            void* data = nullptr;
            uint16_t len = 0;
            if (mosquitto_property_read_binary(p, MQTT_PROP_CORRELATION_DATA, &data, &len, false) &&
                data && len > 0) {
                hdr.correlation_data.assign(static_cast<const char*>(data), len);
            }
            std::free(data);
        } else if (id == MQTT_PROP_USER_PROPERTY) {
            char* key = nullptr;
            char* val = nullptr;
            if (mosquitto_property_read_string_pair(p, MQTT_PROP_USER_PROPERTY, &key, &val,
                                                    false) &&
                key && val) {
                if (std::strcmp(key, "cmdType") == 0) {
                    hdr.cmd_type = val;
                } else if (std::strcmp(key, "eventType") == 0) {
                    hdr.event_type = val;
                } else if (std::strcmp(key, "hasNext") == 0) {
                    hdr.has_next = (std::strcmp(val, "true") == 0);
                }
            }
            std::free(key);
            std::free(val);
        } else if (id == MQTT_PROP_RESPONSE_TOPIC) {
            char* val = nullptr;
            if (mosquitto_property_read_string(p, MQTT_PROP_RESPONSE_TOPIC, &val, false) && val) {
                hdr.response_topic = val;
            }
            std::free(val);
        }
    }
    return hdr;
}

void UciMqttClient::deliverMessage(const struct mosquitto_message* msg,
                                   const mosquitto_property* props) {
    if (!msg) return;

    MqttMessage m;
    if (msg->topic) m.topic = msg->topic;
    if (msg->payload && msg->payloadlen > 0) {
        m.payload.assign(static_cast<const char*>(msg->payload),
                         static_cast<size_t>(msg->payloadlen));
    }
    m.header = parseV5Header(props);

    MqttMessageCallback cb;
    {
        std::lock_guard<std::mutex> lk(mMu);
        cb = mCb;
    }

    if (cb) cb(m);
}

void UciMqttClient::onConnect(struct mosquitto*, void* obj, int rc) {
    auto* self = static_cast<UciMqttClient*>(obj);
    std::lock_guard<std::mutex> lk(self->mMu);
    self->mConnackRc = rc;
    self->mConnackReceived = true;
    self->mConnected = (rc == 0);
    ALOGI("[mqtt] CONNACK rc=%d (%s)", rc, rc == 0 ? "accepted" : MosqErrStr(rc));
    if (rc == 0 && self->mMosq) {
        // clean session 下断线后 broker 侧订阅已清空：重连成功后重放订阅列表。
        for (const auto& s : self->mSubs) {
            int rc2 = mosquitto_subscribe_v5(self->mMosq, nullptr, s.first.c_str(), s.second, 0,
                                             nullptr);
            if (rc2 != MOSQ_ERR_SUCCESS) {
                ALOGE("[mqtt] resubscribe %s failed rc=%d (%s)", s.first.c_str(), rc2,
                      MosqErrStr(rc2));
            } else {
                ALOGI("[mqtt] resubscribed %s qos=%d (reconnect)", s.first.c_str(), s.second);
            }
        }
    }
    self->mCv.notify_all();
}

void UciMqttClient::onConnectV5(struct mosquitto*, void* obj, int rc, int,
                                const mosquitto_property*) {
    onConnect(nullptr, obj, rc);
}

void UciMqttClient::onMessageV5(struct mosquitto*, void* obj, const struct mosquitto_message* msg,
                                const mosquitto_property* props) {
    static_cast<UciMqttClient*>(obj)->deliverMessage(msg, props);
}

void UciMqttClient::onDisconnect(struct mosquitto*, void* obj, int rc) {
    auto* self = static_cast<UciMqttClient*>(obj);
    MqttDisconnectCallback cb;
    {
        std::lock_guard<std::mutex> lk(self->mMu);
        self->mConnected = false;
        ALOGI("[mqtt] disconnected rc=%d (%s)", rc, MosqErrStr(rc));
        cb = self->mDisconnectCb;
    }
    // 锁外调用：回调内可能执行重认证（HTTP）或重新发布。
    if (cb) cb(rc);
}

void UciMqttClient::onDisconnectV5(struct mosquitto*, void* obj, int rc,
                                   const mosquitto_property*) {
    onDisconnect(nullptr, obj, rc);
}

void UciMqttClient::onLog(struct mosquitto*, void*, int level, const char* str) {
    if (!str) return;
    switch (level) {
        case MOSQ_LOG_WARNING:
            ALOGW("[mqtt-lib] %s", str);
            break;
        case MOSQ_LOG_ERR:
            ALOGE("[mqtt-lib] %s", str);
            break;
        default:
            ALOGD("[mqtt-lib] %s", str);
            break;
    }
}

}  // namespace emu
