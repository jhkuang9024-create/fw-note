// WorkMode：连接工作模式（长连/短连/不连）— 内存态 + Idle Lease + period 落盘。
// （移植自 emu_0907 参考实现 WorkModeController，日志宏由 mqtt_log_* 改为 ALOGI/W/E）
#ifndef EMU_WORK_MODE_CONTROLLER_H
#define EMU_WORK_MODE_CONTROLLER_H

#include <atomic>
#include <condition_variable>
#include <ctime>
#include <functional>
#include <mutex>
#include <string>
#include <thread>

namespace emu {

inline constexpr int kWorkModeLong = 0;
inline constexpr int kWorkModeShort = 1;
inline constexpr int kWorkModeNone = 2;
inline constexpr int kIdleLeaseSec = 300;       // 短连空闲租约 5 分钟
inline constexpr int kDefaultPeriodH = 24;      // 缺省休眠周期（小时）
inline constexpr int kMinPeriodH = 1;
inline constexpr int kMaxPeriodH = 168;

struct WorkModeApplyIn {
    std::string work_mode;  // "0"|"1"|"2"
    std::string period;     // 可空
    bool has_next = false;
    bool has_has_next = false;  // 未带 hasNext 时不改旧值
};

class WorkModeController {
  public:
    using OfflineFn = std::function<void(const char* reason)>;
    using OnlineFn = std::function<int(const char* reason)>;

    WorkModeController() = default;
    ~WorkModeController();

    WorkModeController(const WorkModeController&) = delete;
    WorkModeController& operator=(const WorkModeController&) = delete;

    void start(std::string runtime_dir, OfflineFn offline, OnlineFn online);
    void stop();

    // 管道上线成功后调用（boot / wake / 切回长连）
    void onPipelineOnline();

    // reg_resp / SET_WORK_MODE；返回 0 成功，-1 校验失败（不改态）
    // defer_offline=true：先改态关门闩，由调用方 ACK 后再 consumePendingOffline + 真正断连
    int apply(const char* src, const WorkModeApplyIn& in, std::string* err_msg,
              bool defer_offline = false);
    bool consumePendingOffline(std::string* reason);

    void onBusinessStart(const char* reason);
    void onBusinessEnd(const char* reason);
    void onLightActivity();  // 空闲期轻量 cmd：滑动刷新 5min

    bool allowFaultReconnect() const;
    int connMode() const;
    int periodH() const;
    bool hasNext() const;
    bool isSleeping() const;

  private:
    enum Phase { kOnline = 0, kSleeping = 1 };

    void timerMain();
    void evaluateLocked(std::unique_lock<std::mutex>& lk);
    void armIdleLocked(const char* why);
    void enterSleepLocked(const char* reason, std::unique_lock<std::mutex>& lk,
                          bool defer_offline);
    void requestWakeLocked(const char* reason, std::unique_lock<std::mutex>& lk);
    int applyIncrementalLocked(const WorkModeApplyIn& in, std::string* err_msg,
                               std::unique_lock<std::mutex>& lk);

    int resolvePeriodH(const std::string& server_period, const char** src_out) const;
    int loadPeriodFile() const;
    int savePeriodFile(int period_h) const;
    static int parseMode(const std::string& s, bool* ok);
    static bool parsePeriodH(const std::string& s, int* out);

    std::string runtime_dir_;
    OfflineFn offline_fn_;
    OnlineFn online_fn_;

    mutable std::mutex mu_;
    std::condition_variable cv_;
    bool running_ = false;
    std::thread timer_;

    int conn_mode_ = kWorkModeLong;
    int period_h_ = kDefaultPeriodH;
    bool has_next_ = false;
    Phase phase_ = kOnline;
    int busy_ = 0;
    time_t idle_deadline_ = 0;
    time_t wake_at_ = 0;
    bool auto_reconnect_ = true;  // 与 allowFaultReconnect 一致
    bool pending_offline_ = false;
    std::string pending_offline_reason_;
};

}  // namespace emu

#endif  // EMU_WORK_MODE_CONTROLLER_H
