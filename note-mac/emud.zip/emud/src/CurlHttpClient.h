// 真实 HTTP 客户端：封装 libcurl，对应 §5.1 的 IHttpClient 实现。
#ifndef EMU_CURL_HTTP_CLIENT_H
#define EMU_CURL_HTTP_CLIENT_H

#include <curl/curl.h>

#include <string>

#include "HttpClient.h"

namespace emu {

class CurlHttpClient : public IHttpClient {
  public:
    CurlHttpClient();
    ~CurlHttpClient() override;

    HttpResponse get(const std::string& url, const HttpHeaders& headers = {}) override;
    HttpResponse post(const std::string& url, const std::string& body,
                      const HttpHeaders& headers = {}) override;
    HttpResponse postFile(const std::string& url, const std::string& filePath,
                          const std::string& formField, const HttpHeaders& headers = {},
                          const std::atomic<bool>* cancel = nullptr) override;

  private:
    // 公共请求执行体：GET / POST（body）/ multipart（mime 非空时走 MIMEPOST）。
    // stall=true（仅大文件上传用）：去掉 60s 总超时，改用“低网速持续 180s 才中止”，
    // 避免大包在慢网络下被总超时掐死（#11）。
    HttpResponse perform(const std::string& url, const std::string& method, const std::string& body,
                         const HttpHeaders& headers, curl_mime* mime = nullptr,
                         const std::atomic<bool>* cancel = nullptr, bool stall = false);
};

}  // namespace emu

#endif  // EMU_CURL_HTTP_CLIENT_H
