// HTTP 网络抽象（对应 §5.1 IHttpClient）。
#ifndef EMU_HTTP_CLIENT_H
#define EMU_HTTP_CLIENT_H

#include <atomic>
#include <map>
#include <string>

namespace emu {

using HttpHeaders = std::map<std::string, std::string>;

struct HttpResponse {
    int status = 0;  // HTTP 状态码，0 表示网络失败
    std::string body;
    HttpHeaders headers;

    bool ok() const { return status >= 200 && status < 300; }
};

class IHttpClient {
  public:
    virtual ~IHttpClient() = default;
    virtual HttpResponse get(const std::string& url, const HttpHeaders& headers = {}) = 0;
    virtual HttpResponse post(const std::string& url, const std::string& body,
                              const HttpHeaders& headers = {}) = 0;
    // multipart/form-data 文件上传（form 字段名 formField，值为文件内容）。
    // cancel 非空时支持中途中止（置位即终止本次传输），供进程收尾快速退出；
    // 未置位仍受实现层总超时兜底。
    virtual HttpResponse postFile(const std::string& url, const std::string& filePath,
                                  const std::string& formField,
                                  const HttpHeaders& headers = {},
                                  const std::atomic<bool>* cancel = nullptr) = 0;
};

}  // namespace emu

#endif  // EMU_HTTP_CLIENT_H
