#define LOG_TAG "emud"
#include <log/log.h>

#include "Register.h"

#include "DeviceRegister.pb.h"
#include "DeviceRegisterResp.pb.h"

namespace emu {

RegisterService::RegisterService(const Config& cfg, std::shared_ptr<IMqttClient> mqtt,
                                 const std::string& netIp)
    : mCfg(cfg), mMqtt(std::move(mqtt)), mNetIp(netIp) {}

std::string RegisterService::buildRegRespTopic(const std::string& deviceType,
                                               const std::string& deviceId) {
    return "acs/" + deviceType + "/" + deviceId + "/reg_resp";
}

RegisterResult RegisterService::run() {
    const auto& d = mCfg.device;

    // 设备 id：MAC 优先，SN 兜底
    std::string respTopic = buildRegRespTopic(d.device_type, DeviceId(d));
    mMqtt->subscribe(respTopic, 1);

    proto::DeviceRegister reg;
    reg.set_mac(d.mac);
    reg.set_trigger(d.trigger == "BOOTSTRAP"
                            ? proto::DeviceRegister::BOOTSTRAP
                            : (d.trigger == "BOOT" ? proto::DeviceRegister::BOOT
                                                   : proto::DeviceRegister::OTHER));
    reg.set_vendor(d.vendor);
    reg.set_carrier(d.carrier);
    reg.set_firmwarever(d.firmware_ver);
    reg.set_hardwarever(d.hardware_ver);
    reg.set_firmwareinnerver(d.firmware_ver_inner);
    reg.set_hardwareinnerver(d.hardware_ver_inner);
    reg.set_model(d.model);
    reg.set_sn(d.sn);
    reg.set_devicetype(d.device_type);
    reg.set_netmethod(d.net_method);
    reg.set_province(d.province);

    // workMode：运行时配置优先（短连接模式），默认 0-标准长连接。
    // （来源：emu_0827 同事方案 — 读 d.work_mode，支持平台切换短连接）
    reg.set_workmode(d.work_mode.empty() ? "0" : d.work_mode);

    // funcList：设备能力列表。
    // 平台端依赖该字段判断设备能力 / 注册状态，缺失会导致平台功能字段不更新、设备不显示在线。
    // 已实现命令必须在此声明（诊断域抓包/抓日志、nio 资源文件下发 SET_FILE_DOWNLOAD 等），
    // 否则平台提示"设备不支持此功能"。
    static const char* kFuncList[] = {
            "GET_INSPECTION_INFO",
            "REBOOT",
            "REGISTER",
            "SET_REMOTE_SSH",
            "SET_UPGRADE",
            "SET_FILE_DOWNLOAD",
            "GET_CAPTURE_PACKET_INTERFACE",
            "GET_CAPTURE_PACKET_FILE",
            "GET_CAPTURE_PACKET_FILE_CANCEL",
            "SET_CAPTURE_LOG",
            "GET_LOG_FILE",
            "SET_WORK_MODE",
    };
    for (const char* f : kFuncList) reg.add_funclist(f);

    // netIp：认证 token 返回的外网 IP（字段 19）；无 token 时用 data.json 运行时值。
    if (!mNetIp.empty())
        reg.set_netip(mNetIp);
    else if (!d.net_ip.empty())
        reg.set_netip(d.net_ip);

    // pppoeAcc / parentSn：仅非空时填充（宽带账号 / 从设备父 SN）。
    if (!d.pppoe_acc.empty()) reg.set_pppoeacc(d.pppoe_acc);
    if (!d.parent_sn.empty()) reg.set_parentsn(d.parent_sn);

    // extendAttr（字段 21）：STB 扩展字段 chipModel / androidVersion / stbId。
    // （来源：emu_0827 同事方案；属性来源见 Config.cpp LoadDeviceFromProperties）
    auto addExt = [&](const char* key, const std::string& val) {
        if (val.empty()) return;
        auto* e = reg.add_extendattr();
        e->set_key(key);
        e->set_value(val);
    };
    addExt("chipModel", d.chip_model);
    addExt("androidVersion", d.android_version);
    addExt("stbId", d.stb_id);

    // softwareName / softwareVersion（字段 22/23）：平台校验软件信息。
    // model 兜底 "STB"；版本号 firmwareVer → firmwareInnerVer → unknown。
    reg.set_softwarename(d.model.empty() ? "STB" : d.model);
    reg.set_softwareversion(
            d.firmware_ver.empty()
                    ? (d.firmware_ver_inner.empty() ? "unknown" : d.firmware_ver_inner)
                    : d.firmware_ver);

    std::string payload;
    reg.SerializeToString(&payload);
    // reg topic 仅本处使用，直接内联构造。
    std::string topic = "cpe/" + d.device_type + "/all/reg";

    // 注册发布带 MQTT v5 response_topic，
    // 平台据此回 acs/{dt}/{id}/reg_resp。
    MqttHeader hdr;
    hdr.response_topic = respTopic;
    mMqtt->setV5Header(hdr);
    mMqtt->publish(topic, payload, 1);
    ALOGI("[register] → %s (%zu bytes)", topic.c_str(), payload.size());

    // 注册结果由 handleRegResp 异步回填（收到 reg_resp 时），run 仅表示请求已发出。
    mResult.success = true;
    return mResult;
}

void RegisterService::handleRegResp(const MqttMessage& msg) {
    proto::DeviceRegisterResp resp;
    if (!resp.ParseFromString(msg.payload)) {
        ALOGW("[register] invalid reg_resp payload (%zu bytes)", msg.payload.size());
        mResult.success = false;
        return;
    }
    mResult.success = true;
    mResult.code = resp.code();
    mResult.msg = resp.msg();
    mResult.work_mode = resp.workmode();
    mResult.period = resp.period();
    mResult.has_has_next = resp.has_hasnext();
    mResult.has_next = mResult.has_has_next && resp.hasnext();
    ALOGI("[register] reg_resp code=%s workMode=%s period=%s hasNext=%d present=%d msg=%s",
          mResult.code.c_str(), mResult.work_mode.c_str(), mResult.period.c_str(),
          mResult.has_next ? 1 : 0, mResult.has_has_next ? 1 : 0, mResult.msg.c_str());
}

}  // namespace emu
