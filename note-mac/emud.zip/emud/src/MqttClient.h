// MQTT 网络抽象：唯一保留的网络接口之一（对应 §5.1 IMqttClient）。
#ifndef EMU_MQTT_CLIENT_H
#define EMU_MQTT_CLIENT_H

#include <functional>
#include <memory>
#include <string>

namespace emu {

// MQTT v5 消息头（字段均为不定长 std::string）
struct MqttHeader {
    std::string cmd_type;          // cmdType
    std::string event_type;        // eventType
    std::string correlation_data;  // correlation_data
    std::string response_topic;    // response_topic
    bool has_next = false;         // hasNext
};

struct MqttConnectConfig {
    std::string host;
    int port = 1883;
    std::string client_id;
    std::string username;
    std::string password;  // JWT token 或密码
    int keep_alive = 60;
    bool use_ssl = false;
    std::string ca_cert_path;
    // LWT 遗嘱：异常掉线时由 broker 代发离线消息（对应 cpe/{dt}/all/offline）
    bool will_enable = false;
    std::string will_topic;
    std::string will_payload;
    int will_qos = 1;
};

struct MqttMessage {
    std::string topic;
    std::string payload;
    MqttHeader header;
};

// 收到消息回调（在客户端内部线程调用）
using MqttMessageCallback = std::function<void(const MqttMessage&)>;

// 断开回调（网络线程调用）：rc 为断开原因码。用于断线后刷新凭据/重连编排。
using MqttDisconnectCallback = std::function<void(int rc)>;

class IMqttClient {
  public:
    virtual ~IMqttClient() = default;

    virtual int connect(const MqttConnectConfig&) = 0;
    virtual int subscribe(const std::string& topic, int qos) = 0;
    virtual int publish(const std::string& topic, const std::string& payload, int qos) = 0;
    virtual bool isConnected() const = 0;
    virtual int disconnect() = 0;

    virtual void setV5Header(const MqttHeader&) = 0;

    // 注册消息回调（取代轮询 Receive）
    virtual void setMessageCallback(MqttMessageCallback cb) = 0;

    // 注册断开回调（断线/重连编排用）
    virtual void setDisconnectCallback(MqttDisconnectCallback cb) = 0;

    // 更新连接凭据（用户名/密码），供重认证后自动重连使用
    virtual int updateCredentials(const std::string& username, const std::string& password) = 0;
};

}  // namespace emu

#endif  // EMU_MQTT_CLIENT_H
