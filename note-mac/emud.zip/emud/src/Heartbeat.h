// 心跳服务：周期发布 Heartbeat protobuf 到 cpe/{dt}/all/event（eventType=H_BEAT）。
#ifndef EMU_HEARTBEAT_H
#define EMU_HEARTBEAT_H

#include <atomic>
#include <memory>
#include <string>
#include <thread>

#include "MqttClient.h"

namespace emu {

class Heartbeat {
  public:
    Heartbeat(std::shared_ptr<IMqttClient> mqtt, const std::string& sn, const std::string& mac,
              const std::string& deviceType);
    ~Heartbeat();

    void start(int intervalSeconds);
    void stop();

  private:
    void loop();

    std::shared_ptr<IMqttClient> mMqtt;
    std::string mSn;
    std::string mMac;
    std::string mDeviceType;
    int mInterval = 1800;
    std::atomic<bool> mRunning{false};
    std::thread mThread;
};

}  // namespace emu

#endif  // EMU_HEARTBEAT_H
