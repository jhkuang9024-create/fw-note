// taskId ↔ correlation_data 回显缓存。
#ifndef EMU_CORRELATION_CACHE_H
#define EMU_CORRELATION_CACHE_H

#include <map>
#include <mutex>
#include <optional>
#include <string>

namespace emu {

class CorrelationCache {
  public:
    // 记录 taskId 与 correlation_data 的映射
    void put(const std::string& taskId, const std::string& correlationData);

    // 回显规则：显式 corr → 缓存 corr → taskId 兜底
    std::string resolve(const std::string& taskId, const std::string& explicitCorr) const;

    void clear(const std::string& taskId);

  private:
    mutable std::mutex mMu;
    std::map<std::string, std::string> mMap;
};

}  // namespace emu

#endif  // EMU_CORRELATION_CACHE_H
