#define LOG_TAG "emud"
#include <log/log.h>

#include "Offline.h"

#include "Disconnect.pb.h"

namespace emu {

Offline::Offline(std::shared_ptr<IMqttClient> mqtt, const std::string& sn,
                 const std::string& deviceType)
    : mMqtt(std::move(mqtt)), mSn(sn), mDeviceType(deviceType) {}

std::string Offline::buildTopic(const std::string& deviceType) {
    return "cpe/" + deviceType + "/all/offline";
}

void Offline::send(const std::string& status, const std::string& reason) {
    proto::Disconnect off;
    off.set_sn(mSn);
    off.set_status(status);
    off.set_reason(reason);
    std::string payload;
    off.SerializeToString(&payload);
    mMqtt->publish(buildTopic(mDeviceType), payload, 1);
    ALOGI("[offline] → %s status=%s", buildTopic(mDeviceType).c_str(), status.c_str());
}

}  // namespace emu
