#define LOG_TAG "emud"
#include <log/log.h>

#include "CurlHttpClient.h"

#include <curl/curl.h>

#include <mutex>

namespace emu {

namespace {

// libcurl 全局初始化（引用计数，允许多个客户端实例共存）。
std::mutex g_curl_mu;
int g_curl_refs = 0;

void CurlGlobalInit() {
    std::lock_guard<std::mutex> lk(g_curl_mu);
    if (g_curl_refs++ == 0) curl_global_init(CURL_GLOBAL_DEFAULT);
}

void CurlGlobalCleanup() {
    std::lock_guard<std::mutex> lk(g_curl_mu);
    if (--g_curl_refs == 0) curl_global_cleanup();
}

std::string Trim(const std::string& s) {
    size_t b = 0;
    while (b < s.size() && (s[b] == ' ' || s[b] == '\t' || s[b] == '\r' || s[b] == '\n')) ++b;
    size_t e = s.size();
    while (e > b && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n'))
        --e;
    return s.substr(b, e - b);
}

struct CurlContext {
    HttpResponse resp;
};

// 连接/总超时（秒）：小请求（认证/命令）用总超时兜底，防止服务端挂起拉死 worker。
// 大文件上传走 stall 模式（见 perform 注释），不受 kTotalTimeoutSec 限制。
constexpr int kConnectTimeoutSec = 30;
constexpr int kTotalTimeoutSec = 60;
// stall 判定：持续低于 1KB/s 达 180s 视为链路僵死（对 100MB+ 慢速上传足够宽容）。
constexpr long kLowSpeedLimit = 1024;
constexpr long kLowSpeedTimeSec = 180;
// 重定向次数上限：跟随跳转但不允许无限重定向循环。
constexpr long kMaxRedirects = 5;

size_t WriteCallback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    size_t total = size * nmemb;
    auto* ctx = static_cast<CurlContext*>(userdata);
    ctx->resp.body.append(ptr, total);
    return total;
}

size_t HeaderCallback(char* buffer, size_t size, size_t nmemb, void* userdata) {
    size_t total = size * nmemb;
    auto* ctx = static_cast<CurlContext*>(userdata);

    std::string line(buffer, total);
    size_t colon = line.find(':');
    if (colon != std::string::npos) {
        std::string name = Trim(line.substr(0, colon));
        std::string value = Trim(line.substr(colon + 1));
        if (!name.empty()) ctx->resp.headers[name] = value;
    }
    return total;
}

// 进度回调：cancel 置位时返回非 0，令 curl 中止本次传输（进程收尾快速退出用）。
struct CurlXferInfo {
    const std::atomic<bool>* cancel = nullptr;
};

int XferInfoCb(void* clientp, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal,
               curl_off_t ulnow) {
    (void)dltotal;
    (void)dlnow;
    (void)ultotal;
    (void)ulnow;
    auto* x = static_cast<CurlXferInfo*>(clientp);
    if (x && x->cancel && x->cancel->load()) return 1;  // 非 0 = 中止传输
    return 0;
}

}  // namespace

CurlHttpClient::CurlHttpClient() {
    CurlGlobalInit();
}

CurlHttpClient::~CurlHttpClient() {
    CurlGlobalCleanup();
}

HttpResponse CurlHttpClient::get(const std::string& url, const HttpHeaders& headers) {
    return perform(url, "GET", "", headers);
}

HttpResponse CurlHttpClient::post(const std::string& url, const std::string& body,
                                  const HttpHeaders& headers) {
    return perform(url, "POST", body, headers);
}

HttpResponse CurlHttpClient::postFile(const std::string& url, const std::string& filePath,
                                      const std::string& formField, const HttpHeaders& headers,
                                      const std::atomic<bool>* cancel) {
    // multipart/form-data：form 字段 formField 对应本地文件（规范 §4.3.7.1 上传接口）。
    // mime 不关联具体句柄（curl_mime_init(nullptr)），由 perform 挂到其内部 curl 上。
    curl_mime* mime = curl_mime_init(nullptr);
    if (!mime) {
        ALOGE("[http] curl_mime_init failed");
        return HttpResponse{};
    }
    curl_mimepart* part = curl_mime_addpart(mime);
    curl_mime_name(part, formField.c_str());
    curl_mime_filedata(part, filePath.c_str());

    HttpResponse r = perform(url, "POST", "", headers, mime, cancel, /*stall=*/true);
    curl_mime_free(mime);
    return r;
}

HttpResponse CurlHttpClient::perform(const std::string& url, const std::string& method,
                                     const std::string& body, const HttpHeaders& headers,
                                     curl_mime* mime, const std::atomic<bool>* cancel,
                                     bool stall) {
    CurlContext ctx;

    CURL* curl = curl_easy_init();
    if (!curl) {
        ALOGE("[http] curl_easy_init failed");
        return ctx.resp;
    }

    struct curl_slist* hdrs = nullptr;
    for (const auto& kv : headers) {
        std::string line = kv.first + ": " + kv.second;
        hdrs = curl_slist_append(hdrs, line.c_str());
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    // 仅允许 http/https，且重定向后仍不得跨协议（SSRF 面收敛：如内网元数据
    // 169.254.169.254 等无法借重定向/自定义协议访问）；重定向次数封顶防循环。
    curl_easy_setopt(curl, CURLOPT_MAXREDIRS, kMaxRedirects);
#if LIBCURL_VERSION_NUM >= 0x075500  // 7.85.0+ 用字符串形式（老版本退位掩码）
    curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");
#else
    curl_easy_setopt(curl, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
#endif
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "emud/1.0");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, HeaderCallback);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, &ctx);

    // 认证场景由 HTTP Digest 负责（替代证书校验）。
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    if (kConnectTimeoutSec > 0) curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, kConnectTimeoutSec);
    if (stall) {
        // 大文件上传：无总超时，改“持续低网速 180s 判僵死”。慢链路（如 512kbps
        // 传 200MB）耗时远大于 60s 属正常，原固定总超时必然掐断上传（#11）。
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, kLowSpeedLimit);
        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, kLowSpeedTimeSec);
    } else if (kTotalTimeoutSec > 0) {
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, kTotalTimeoutSec);
    }

    // 取消支持：cancel 非空时挂进度回调，置位即中止传输（进程收尾路径用）。
    CurlXferInfo xfer;
    if (cancel) {
        xfer.cancel = cancel;
        curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
        curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, XferInfoCb);
        curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &xfer);
    }

    if (mime) {
        curl_easy_setopt(curl, CURLOPT_MIMEPOST, mime);
    } else if (method == "POST") {
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.data());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
    }

    if (hdrs) curl_easy_setopt(curl, CURLOPT_HTTPHEADER, hdrs);

    CURLcode rc = curl_easy_perform(curl);
    long status = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);

    if (rc == CURLE_ABORTED_BY_CALLBACK && cancel && cancel->load()) {
        // 主动取消（进程收尾）：不算网络错误，静默返回失败即可。
        ALOGI("[http] %s %s cancelled", method.c_str(), url.c_str());
    } else if (rc != CURLE_OK) {
        // 网络层失败：status 保持 0（HttpResponse::ok() 会返回 false）。
        ALOGE("[http] %s %s failed: %s", method.c_str(), url.c_str(), curl_easy_strerror(rc));
    } else {
        ctx.resp.status = static_cast<int>(status);
        ALOGI("[http] %s %s → HTTP %ld (%zu bytes)", method.c_str(), url.c_str(), status,
              ctx.resp.body.size());
    }

    curl_slist_free_all(hdrs);
    curl_easy_cleanup(curl);
    return ctx.resp;
}

}  // namespace emu
