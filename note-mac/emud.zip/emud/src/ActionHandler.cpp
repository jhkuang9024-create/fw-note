#define LOG_TAG "emud"
#include <log/log.h>

#include "ActionHandler.h"

#include <cstdlib>

#include <json/json.h>

#include "util/JsonUtil.h"

namespace emu {

std::optional<Response> ActionHandler::handleAction(const InboundCommand& cmd) {
    auto ac = mCfg.findAction(cmd.cmd_type);
    if (!ac) return std::nullopt;

    Response resp;
    if (ac->handler == "terminal") {
        if (ac->command.empty()) {
            resp.code = "-1";
            resp.msg = "empty terminal command";
            return resp;
        }
        ALOGI("[action] terminal: %s", ac->command.c_str());
        int rc = std::system(ac->command.c_str());
        resp.code = (rc == 0) ? "0" : "-1";
        resp.msg = (rc == 0) ? "success" : "command failed";
        return resp;
    }

    resp.code = "-1";
    resp.msg = "unknown handler " + ac->handler;
    return resp;
}

std::optional<Response> ActionHandler::handleGet(const InboundCommand& cmd) {
    const Json::Value& gh = mCfg.get_handlers[cmd.cmd_type];
    if (gh.isNull()) return std::nullopt;

    std::string dataKey = gh["data_key"].isString() ? gh["data_key"].asString() : "";
    if (dataKey.empty()) {
        // 直接用 cmd_type 做 data_key（如 GET_ROBOT_CONFIG）
        dataKey = cmd.cmd_type;
    }

    Json::Value data = mCfg.data[dataKey];
    if (data.isNull()) {
        Response r;
        r.code = "-1";
        r.msg = "no such data_key " + dataKey;
        return r;
    }

    // 若指定 fields，则只取这些字段
    const Json::Value& fields = gh["fields"];
    if (fields.isArray()) {
        Json::Value picked(Json::objectValue);
        for (const auto& f : fields) {
            if (f.isString()) picked[f.asString()] = data[f.asString()];
        }
        data = picked;
    }

    Response r;
    r.code = "0";
    // GET_* 结果（JSON 字符串）经 msg 字段返回（SetCommonRsp.msg）。
    r.msg = util::DumpJson(data);
    return r;
}

void ActionHandler::registerBuiltins(CommandRegistry& registry) {
    for (const auto& a : mCfg.action_handlers) {
        std::string action = a.action;
        registry.registerBuiltin(action,
                                 [this](const InboundCommand& c) { return handleAction(c); });
    }
    if (mCfg.get_handlers.isObject()) {
        for (const auto& name : mCfg.get_handlers.getMemberNames()) {
            registry.registerBuiltin(name,
                                     [this](const InboundCommand& c) { return handleGet(c); });
        }
    }
}

}  // namespace emu
