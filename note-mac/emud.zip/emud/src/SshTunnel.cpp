#define LOG_TAG "emud"
#include <log/log.h>

#include "SshTunnel.h"

#include <sys/types.h>
#include <unistd.h>

#include <string>
#include <vector>

#include "SetRemoteControl.pb.h"
#include "util/ProcessUtil.h"

namespace emu {
namespace ssh_tunnel {

namespace {

constexpr int kDefaultSshPort = 22;  // SSH 默认监听端口
constexpr int kDefaultRelayServerPort =
        8022;  // 中继服务器默认端口（与 C 参考实现 remote_control.c 一致）

// 解析端口字符串：仅接受纯数字 1~65535。
// 注意：AOSP 编译为 -fno-exceptions，不能用 stoi + try/catch 处理平台下发的
// 不可信字段，因此先逐字符校验数字，再手工累加并提前截断防溢出。
bool ParsePort(const std::string& s, int* out) {
    if (s.empty()) return false;
    long v = 0;
    for (char c : s) {
        if (c < '0' || c > '9') return false;
        v = v * 10 + (c - '0');
        if (v > 65535) return false;  // 提前截断，避免 long 溢出
    }
    if (v <= 0) return false;
    *out = static_cast<int>(v);
    return true;
}

}  // namespace

SshTunnelSession::~SshTunnelSession() {
    stop();
}

bool SshTunnelSession::start(const TunnelConfig& cfg) {
    if (mPid > 0 && isAlive()) return true;  // 已运行

    // SSH 场景: 先拉起 dropbear, 监听与 nmproxy -l 相同的本机 SSH 端口
    if (cfg.enable_dropbear) {
        const int sshPort = cfg.relay_dest_port > 0 ? cfg.relay_dest_port : kDefaultSshPort;
        if (!startDropbear(cfg.dropbear_path, sshPort)) {
            ALOGE("[nmproxy] dropbear start FAILED, abort tunnel");
            return false;
        }
    }

    // 用管道探测子进程 exec 结果（统一走 util::SpawnProbe）：
    // 成功 → CLOEXEC 关闭写端(EOF)；失败 → 回收并返回 -1。
    std::vector<std::string> args = {
            cfg.nmproxy_path,
            "-d",
            cfg.relay_server_address,
            "-r",
            std::to_string(cfg.relay_server_port),
            "-s",
            cfg.relay_dest_address,
            "-l",
            std::to_string(cfg.relay_dest_port),
            "-t",
            "0",
            "-k",
            cfg.connect_key,
    };
    const pid_t p = util::SpawnProbe(args, "nmproxy");
    if (p < 0) {
        ALOGE("[nmproxy] spawn FAILED, abort tunnel");
        // 回滚: 停止刚拉起的 dropbear
        util::TerminateProcess(mDropbearPid, "dropbear");
        return false;
    }

    mPid = p;
    ALOGI("[nmproxy] started pid=%d", mPid);
    return true;
}

void SshTunnelSession::stop() {
    // 先停隧道, 再停 SSH 场景拉起的 dropbear
    util::TerminateProcess(mPid, "nmproxy");
    util::TerminateProcess(mDropbearPid, "dropbear");
}

bool SshTunnelSession::isAlive() const {
    if (mPid <= 0) return false;
    return ::kill(mPid, 0) == 0;
}

bool SshTunnelSession::startDropbear(const std::string& path, int port) {
    if (mDropbearPid > 0 && ::kill(mDropbearPid, 0) == 0) {
        return true;  // 已在运行
    }

    // 管道探测统一走 util::SpawnProbe（exec 成功 → EOF；失败 → 回收并返回 -1）
    std::vector<std::string> args = {
            path,
            "-p",
            std::to_string(port),
            "-R",
            "-F",  // 前台常驻, 不 fork 后台
    };
    const pid_t p = util::SpawnProbe(args, "dropbear");
    if (p < 0) {
        ALOGE("[dropbear] start FAILED");
        return false;
    }

    mDropbearPid = p;
    ALOGI("[dropbear] started pid=%d port=%d", p, port);
    return true;
}

SshTunnelFeature::SshTunnelFeature(Framework& fw) : mFw(fw) {}

SshTunnelFeature::~SshTunnelFeature() {
    // 收尾释放业务占用（来源：emu_0907 同事方案；Framework 析构先于本对象）
    if (mTunnelActive) mFw.businessEnd("ssh");
    mTunnel.stop();
}

std::unique_ptr<SshTunnelFeature> SshTunnelFeature::create(Framework& fw) {
    auto self = std::make_unique<SshTunnelFeature>(fw);
    auto* raw = self.get();
    fw.registerCmdHandler("SET_REMOTE_SSH",
                          [raw](const InboundCommand& c) { return raw->onSetRemoteSsh(c); });
    return self;
}

std::optional<Response> SshTunnelFeature::onSetRemoteSsh(const InboundCommand& cmd) {
    proto::SetRemoteControl rc;
    if (!rc.ParseFromString(cmd.payload)) {
        return Response{"-1", "invalid remote control payload"};
    }

    if (!rc.relayenbable()) {
        mTunnel.stop();
        if (mTunnelActive) mFw.businessEnd("ssh");
        mTunnelActive = false;
        ALOGI("[rc] relay disabled");
        return Response{"0", "ok"};
    }

    // 与 C 参考实现 remote_control.c 保持一致的必填校验与默认值:
    // 空 key / 空 server 直接拒绝; 端口缺省时 server=8022, dest=22
    if (rc.relayconnectkey().empty()) {
        ALOGE("[rc] relayConnectKey is empty");
        return Response{"-1", "relay connect key is empty"};
    }
    if (rc.relayserveraddress().empty()) {
        ALOGE("[rc] relayServerAddress is empty");
        return Response{"-1", "relay server address is empty"};
    }

    mCfg.connect_key = rc.relayconnectkey();
    mCfg.relay_server_address = rc.relayserveraddress();

    int serverPort = kDefaultRelayServerPort;
    if (!rc.relayserverport().empty() && !ParsePort(rc.relayserverport(), &serverPort)) {
        ALOGE("[rc] illegal relayServerPort=%s", rc.relayserverport().c_str());
        return Response{"-1", "illegal relay server port"};
    }
    mCfg.relay_server_port = serverPort;

    if (!rc.relaydestaddress().empty()) mCfg.relay_dest_address = rc.relaydestaddress();
    int destPort = kDefaultSshPort;
    if (!rc.relaydestport().empty() && !ParsePort(rc.relaydestport(), &destPort)) {
        ALOGE("[rc] illegal relayDestPort=%s", rc.relaydestport().c_str());
        return Response{"-1", "illegal relay dest port"};
    }
    mCfg.relay_dest_port = destPort;

    if (!mTunnel.start(mCfg)) {
        return Response{"-1", "start tunnel failed"};
    }
    // 隧道长驻期间声明业务占用，避免短连空闲租约把它下线（来源：emu_0907 同事方案）
    if (!mTunnelActive) mFw.businessStart("ssh");
    mTunnelActive = true;
    return Response{"0", "ok"};
}

}  // namespace ssh_tunnel
}  // namespace emu
