// 离线服务：发布 Offline protobuf 到 cpe/{dt}/all/offline。
#ifndef EMU_OFFLINE_H
#define EMU_OFFLINE_H

#include <memory>
#include <string>

#include "MqttClient.h"

namespace emu {

class Offline {
  public:
    Offline(std::shared_ptr<IMqttClient> mqtt, const std::string& sn,
            const std::string& deviceType);

    // status: "disconnect"(正常离线) / "offline"(遗嘱异常离线)
    void send(const std::string& status, const std::string& reason);

    static std::string buildTopic(const std::string& deviceType);

  private:
    std::shared_ptr<IMqttClient> mMqtt;
    std::string mSn;
    std::string mDeviceType;
};

}  // namespace emu

#endif  // EMU_OFFLINE_H
