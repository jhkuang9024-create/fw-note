#define LOG_TAG "emud"
#include <log/log.h>

#include "Heartbeat.h"

#include <chrono>

#include "Config.h"
#include "Framework.h"
#include "Heartbeat.pb.h"

namespace emu {

Heartbeat::Heartbeat(std::shared_ptr<IMqttClient> mqtt, const std::string& sn,
                     const std::string& mac, const std::string& deviceType)
    : mMqtt(std::move(mqtt)), mSn(sn), mMac(mac), mDeviceType(deviceType) {}

Heartbeat::~Heartbeat() {
    stop();
}

void Heartbeat::start(int intervalSeconds) {
    if (mRunning.exchange(true)) return;
    mInterval = intervalSeconds > 0 ? intervalSeconds : 1800;
    mThread = std::thread([this] { loop(); });
}

void Heartbeat::stop() {
    if (!mRunning.exchange(false)) return;
    if (mThread.joinable()) mThread.join();
}

void Heartbeat::loop() {
    ALOGI("[heartbeat] started interval=%ds", mInterval);
    while (mRunning.load()) {
        for (int i = 0; i < mInterval && mRunning.load(); ++i)
            std::this_thread::sleep_for(std::chrono::seconds(1));
        if (!mRunning.load()) break;

        proto::Heartbeat hb;
        hb.set_sn(mSn);
        hb.set_mac(mMac);
        std::string payload;
        hb.SerializeToString(&payload);

        MqttHeader hdr;
        hdr.event_type = "H_BEAT";
        // 心跳 header：response_topic 用设备 id（MAC 优先，SN 兜底），
        // 与 Framework 订阅的 event_resp topic（%s 同规则）保持一致。
        hdr.response_topic =
                "acs/" + mDeviceType + "/" + DeviceIdFrom(mMac, mSn) + "/event_resp";
        mMqtt->setV5Header(hdr);
        // 事件 topic 与 Framework 事件上报共用同一模板（防止格式漂移）。
        mMqtt->publish(Framework::buildEventTopic(mDeviceType), payload, 1);
    }
    ALOGI("[heartbeat] stopped");
}

}  // namespace emu
