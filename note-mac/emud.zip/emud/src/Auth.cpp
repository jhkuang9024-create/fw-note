#define LOG_TAG "emud"
#include <log/log.h>

#include "Auth.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <utility>

#include <json/json.h>

#include "Digest.h"
#include "util/JsonUtil.h"
#include "util/RandUtil.h"

namespace emu {

AuthSession::AuthSession(const AuthConfig& cfg, const DeviceConfig& device,
                         std::shared_ptr<IHttpClient> http)
    : mCfg(cfg), mDevice(device), mHttp(std::move(http)) {}

std::string AuthSession::buildAuthorization(const std::string& method, const std::string& uri,
                                            const std::string& realm, const std::string& nonce,
                                            const std::string& qop) {
    char nc[16];
    std::snprintf(nc, sizeof(nc), "%08x", ++mNc);
    std::string username = mDevice.mac;
    std::string response = DigestResponse(username, realm, mDevice.sn, mCfg.digest_password, method,
                                          uri, nonce, nc, mCnonce, qop);
    std::string auth = "Digest username=\"" + username + "\", realm=\"" + realm + "\", nonce=\"" +
                       nonce + "\", uri=\"" + uri + "\", qop=" + qop + ", nc=" + nc +
                       ", cnonce=\"" + mCnonce + "\", response=\"" + response + "\"";
    return auth;
}

void AuthSession::reset() {
    mDone = false;
    mResult = AuthResult{};
    mNc = 0;
    mCnonce.clear();
}

const AuthResult& AuthSession::run() {
    if (mDone) return mResult;
    mDone = true;
    mCnonce = util::MakeRandomHex(16);
    std::string base = mCfg.auth_server;
    while (!base.empty() && base.back() == '/') base.pop_back();

    // Step 1: 触发 401
    std::string uri1 = "/api/ems/web/mqtt/auth/rest/plugin/v1/ne-auth-mgr/" + mDevice.mac;
    ALOGI("[auth] step1 GET %s%s", base.c_str(), uri1.c_str());
    HttpResponse r1 = mHttp->get(base + uri1);
    std::string wwwAuth;
    auto it = r1.headers.find("WWW-Authenticate");
    if (it == r1.headers.end()) it = r1.headers.find("www-authenticate");
    if (it != r1.headers.end()) wwwAuth = it->second;
    ALOGI("[auth] step1 resp http=%d www_auth=%s (body=%.200s)", r1.status,
          wwwAuth.empty() ? "(none)" : "(found)", r1.body.c_str());

    std::string realm = ParseWwwAuthParam(wwwAuth, "realm");
    std::string nonce = ParseWwwAuthParam(wwwAuth, "nonce");
    std::string qop = ParseWwwAuthParam(wwwAuth, "qop");
    if (qop.empty()) qop = "auth";
    if (realm.empty() || nonce.empty()) {
        mResult.error = "no digest challenge (missing realm/nonce)";
        ALOGE("[auth] %s realm='%s' nonce='%s'", mResult.error.c_str(), realm.c_str(),
              nonce.c_str());
        return mResult;
    }
    ALOGI("[auth] step1 challenge realm=%s nonce=%.16s... qop=%s", realm.c_str(), nonce.c_str(),
          qop.c_str());

    // Step 2: 带 Digest 授权的 GET
    std::string uri2 = "/api/ems/web/mqtt/auth/rest/plugin/v1/ne-auth-mgr?sn=" + mDevice.sn;
    HttpHeaders h2;
    h2["Authorization"] = buildAuthorization("GET", uri2, realm, nonce, qop);
    ALOGI("[auth] step2 GET %s%s", base.c_str(), uri2.c_str());
    HttpResponse r2 = mHttp->get(base + uri2, h2);
    if (!r2.ok()) {
        mResult.error = "auth step2 HTTP " + std::to_string(r2.status);
        ALOGE("[auth] %s (body=%.200s)", mResult.error.c_str(), r2.body.c_str());
        return mResult;
    }
    auto j2 = util::ParseJson(r2.body);
    if (!j2) {
        mResult.error = "auth step2 invalid json";
        ALOGE("[auth] %s (body=%.200s)", mResult.error.c_str(), r2.body.c_str());
        return mResult;
    }
    std::string authAddress = util::GetString(*j2, "authAddress");
    std::string authToken = util::GetString(*j2, "authToken");
    ALOGI("[auth] step2 ok http=%d authAddress=%s authToken=%s", r2.status,
          authAddress.empty() ? "(empty)" : authAddress.c_str(),
          authToken.empty() ? "(empty)" : "(present)");

    // Step 3: POST authAddress 获取 jwt/mqtt 参数
    if (authAddress.empty()) {
        mResult.error = "auth step2 missing authAddress";
        ALOGE("[auth] %s", mResult.error.c_str());
        return mResult;
    }
    // 服务端会校验该报文（否则 HTTP 400）：
    //  - nonce：客户端新生成的 32 位十六进制随机串，不能复用服务端 challenge nonce
    //  - ts：毫秒时间戳，且以字符串类型传输
    std::string nonce32 = util::MakeRandomHex(32);
    std::string tsMs = std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(
                                               std::chrono::system_clock::now().time_since_epoch())
                                               .count());
    Json::Value body(Json::objectValue);
    body["deviceId"] = mDevice.sn;
    body["deviceType"] = mDevice.device_type;
    body["nonce"] = nonce32;
    body["ts"] = tsMs;
    ALOGI("[auth] step3 POST %s body=%s", authAddress.c_str(), util::DumpJson(body).c_str());
    HttpHeaders h3;
    h3["Authorization"] = "Bearer " + authToken;
    h3["Content-Type"] = "application/json";
    ALOGI("[auth] step3 POST %s", authAddress.c_str());
    HttpResponse r3 = mHttp->post(authAddress, util::DumpJson(body), h3);
    if (!r3.ok()) {
        mResult.error = "auth step3 HTTP " + std::to_string(r3.status);
        ALOGE("[auth] %s (body=%.200s)", mResult.error.c_str(), r3.body.c_str());
        return mResult;
    }
    auto j3 = util::ParseJson(r3.body);
    if (!j3) {
        mResult.error = "auth step3 invalid json";
        ALOGE("[auth] %s (body=%.200s)", mResult.error.c_str(), r3.body.c_str());
        return mResult;
    }
    // 字段解析（服务端字段名/类型/兜底值）：
    mResult.jwt = util::GetString(*j3, "jwt");
    mResult.mqtt_ip = util::GetString(*j3, "mqttIP");
    mResult.mqtt_port = util::GetInt(*j3, "mqttPort", 0);
    if (mResult.mqtt_port <= 0) mResult.mqtt_port = 1883;  // 兜底 "1883"
    mResult.keep_alive = util::GetInt(*j3, "keepAlive", 0);
    if (mResult.keep_alive <= 0) mResult.keep_alive = 300;  // 兜底 300
    mResult.server_keep_alive = util::GetInt(*j3, "serverKeepAlive", 0);
    if (mResult.server_keep_alive <= 0) mResult.server_keep_alive = 1800;  // 兜底 1800
    mResult.conn_delay = util::GetInt(*j3, "connDelay", 0);
    // mode: 0=TLS长连接, 1=TCP短连接, 2=不连接（服务端返回字符串，如 "0"）
    mResult.mode = util::GetString(*j3, "mode");
    mResult.ssl_cert = util::GetString(*j3, "sslCert");
    mResult.client_ip = util::GetString(*j3, "clientIP");

    mResult.success = !mResult.jwt.empty();
    if (!mResult.success) {
        mResult.error = "auth step3 missing jwt";
        ALOGE("[auth] %s (body=%.200s)", mResult.error.c_str(), r3.body.c_str());
    }
    ALOGI("[auth] success=%d error=%s mqtt=%s:%d keep_alive=%d server_keep_alive=%d mode=%s "
          "conn_delay=%d ssl_cert=%zuB",
          mResult.success ? 1 : 0, mResult.error.c_str(), mResult.mqtt_ip.c_str(),
          mResult.mqtt_port, mResult.keep_alive, mResult.server_keep_alive,
          mResult.mode.empty() ? "(empty)" : mResult.mode.c_str(), mResult.conn_delay,
          mResult.ssl_cert.size());
    return mResult;
}

}  // namespace emu
