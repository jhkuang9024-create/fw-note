// 配置加载：config.json（静态配置，只读）+ data.json（运行时数据，独立可写回）。
// 配置 / 数据目录拆分（v2）：
//   - 配置固定从 /system/etc/emud/ 只读加载（config.json 优先、emud.json 兜底），
//     永不回写、启动不复制到 /data。
//   - 数据目录固定 /data/system/emud/（可读写）：data.json、CA 证书、日志、升级任务。
// 注意：设备信息（DeviceConfig）不读 config.json，直接读系统属性，
// config.json 中的 device 段不使用。
#ifndef EMU_CONFIG_H
#define EMU_CONFIG_H

#include <json/json.h>

#include <optional>
#include <string>
#include <vector>

namespace emu {

// 配置 / 数据路径（完全硬编码，无运行参数）。
// 配置：system 分区只读，优先 config.json，兜底 emud.json（兼容单文件布局）。
// 数据：/data/system/emud/ 可读写；data.json 首启时从系统初始值 seed，之后永不覆盖。
inline constexpr const char* kSystemConfigPath = "/system/etc/emud/config.json";
inline constexpr const char* kSystemConfigFallbackPath = "/system/etc/emud.json";
inline constexpr const char* kSystemDataSeedPath = "/system/etc/emud/data.json";
inline constexpr const char* kDataDir = "/data/system/emud";
inline constexpr const char* kDataPath = "/data/system/emud/data.json";

struct DeviceConfig {
    // 设备信息（运行时读系统属性，非 config.json；见 Config.cpp）
    std::string vendor;
    std::string model;
    std::string sn;
    std::string mac;
    std::string firmware_ver;
    std::string hardware_ver;
    std::string firmware_ver_inner;
    std::string hardware_ver_inner;
    std::string carrier;
    std::string device_type;
    std::string net_method;
    std::string province;
    std::string trigger;
    // ---- 注册扩展字段（来源：emu_0827 同事方案）----
    std::string pppoe_acc;  // 宽带账号（data.json 运行时）
    std::string parent_sn;  // 从设备时父设备 SN（data.json 运行时）
    std::string net_ip;     // 外网 IP（token 接口返回 / data.json）
    std::string work_mode;  // 连接工作模式：0-标准长连接 1-短连接（data.json 运行时）
    // STB extendAttr（读系统属性）
    std::string chip_model;       // ro.product.board
    std::string android_version;  // ro.build.version.release
    std::string stb_id;           // ro.product.stb.stbid
};

struct AuthConfig {
    bool enable = true;
    std::string auth_server;
    std::string digest_password;
    std::string ca_cert_path;
};

struct SubscribeTopic {
    std::string topic;
    int qos = 1;
};

struct RouteConfig {
    std::string cmd_type;
    std::string ack_status;
    std::string ack_msg;
};

struct EventRoute {
    std::string event_class;
    std::string mqtt_event;
};

struct ActionConfig {
    std::string action;
    std::string handler;  // terminal / local
    std::string command;
};

struct Config {
    DeviceConfig device;
    AuthConfig auth;
    std::vector<SubscribeTopic> subscribe_topics;
    std::vector<RouteConfig> routes;
    std::vector<EventRoute> event_routes;
    std::vector<ActionConfig> action_handlers;
    Json::Value get_handlers;  // GET_ROBOT_* 映射（config.json）
    Json::Value data;          // 本地 data 对象（独立 data.json，运行时可写回）

    // 便捷查询
    std::optional<EventRoute> findEventRoute(const std::string& eventClass) const;
    std::optional<ActionConfig> findAction(const std::string& action) const;
};

// 从固定路径加载（读取 /system/etc/emud 的 config.json + /data/system/emud 的 data.json）
std::optional<Config> ConfigLoad();

// 设备 ID：MAC 优先，SN 兜底
// （用于 MQTT client_id 与 topic 拼接）
std::string DeviceId(const DeviceConfig& d);

// 设备 ID 独立字段版（MAC 优先，SN 兜底），供持独立 sn/mac 的对象（如 Heartbeat）复用。
std::string DeviceIdFrom(const std::string& mac, const std::string& sn);

}  // namespace emu

#endif  // EMU_CONFIG_H
