// 极简测试框架 + 核心模块单测（host 零依赖）。
#include <cstdio>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include <json/json.h>

#include "../src/CommandRegistry.h"
#include "../src/Config.h"
#include "../src/Digest.h"
#include "../src/Envelope.h"
#include "../src/upgrade/TaskStore.h"

// 生成的 proto 头（由 emud_proto 模块编译产出，编译测试时需 -I 指向 gen 目录）
#include "EventUpgradeRet.pb.h"
#include "SetUpgrade.pb.h"

namespace {

int g_fail = 0;
int g_pass = 0;

std::optional<Json::Value> ParseJson(const std::string& text) {
    Json::CharReaderBuilder builder;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    Json::Value root;
    std::string errs;
    if (!reader->parse(text.data(), text.data() + text.size(), &root, &errs)) {
        return std::nullopt;
    }
    return root;
}

std::string DumpJson(const Json::Value& v) {
    Json::StreamWriterBuilder builder;
    builder["indentation"] = "";
    return Json::writeString(builder, v);
}

void Check(bool cond, const std::string& name) {
    if (cond) {
        ++g_pass;
        std::printf("[PASS] %s\n", name.c_str());
    } else {
        ++g_fail;
        std::printf("[FAIL] %s\n", name.c_str());
    }
}

void CheckEq(const std::string& actual, const std::string& expect, const std::string& name) {
    Check(actual == expect, name + " (got=" + actual + " want=" + expect + ")");
}

// ---------- JSON（jsoncpp） ----------
void TestJson() {
    auto v = ParseJson(R"({"a":1,"b":"x","c":[1,2,3],"d":true})");
    Check(v.has_value(), "json parse");
    if (!v) return;
    Check((*v)["a"].isNumeric() && (*v)["a"].asInt() == 1, "json int");
    CheckEq((*v)["b"].asString(), "x", "json string");
    Check((*v)["c"].isArray() && (*v)["c"].size() == 3, "json array");
    Check((*v)["d"].isBool() && (*v)["d"].asBool(), "json bool");

    // dump 再 parse 应稳定
    auto v2 = ParseJson(DumpJson(*v));
    Check(v2 && (*v2)["a"].asInt() == 1, "json dump round-trip");
}

// ---------- protobuf wire ----------
void TestProto() {
    emu::proto::SetUpgrade m;
    m.set_taskid("T1");
    m.set_upgurl("http://x/fw.bin");
    m.set_md5("abc");
    m.set_hasnext(true);
    m.set_traffic("10M");

    emu::proto::SetUpgrade u;
    Check(u.ParseFromString(m.SerializeAsString()), "set_upgrade unpack");
    CheckEq(u.taskid(), "T1", "set_upgrade task_id");
    CheckEq(u.upgurl(), "http://x/fw.bin", "set_upgrade url");
    CheckEq(u.md5(), "abc", "set_upgrade md5");
    Check(u.hasnext(), "set_upgrade has_next");
    CheckEq(u.traffic(), "10M", "set_upgrade traffic");

    emu::proto::EventUpgradeRet evt;
    evt.set_sn("SN1");
    evt.set_mac("MAC1");
    evt.mutable_params()->set_taskid("T1");
    evt.mutable_params()->set_status("2");
    evt.mutable_params()->set_msg("ok");

    emu::proto::EventUpgradeRet e2;
    Check(e2.ParseFromString(evt.SerializeAsString()), "event_upgrade_ret unpack");
    Check(e2.params().taskid() == "T1" && e2.params().status() == "2", "event_upgrade_ret nested");
}

// ---------- digest ----------
void TestDigest() {
    // 幂等性
    std::string r1 = emu::DigestResponse("user", "realm", "SN", "pass", "GET", "/x", "n",
                                         "00000001", "c", "auth");
    std::string r2 = emu::DigestResponse("user", "realm", "SN", "pass", "GET", "/x", "n",
                                         "00000001", "c", "auth");
    CheckEq(r1, r2, "digest deterministic");
    Check(r1.size() == 64, "digest is sha256 hex");

    std::string header = "Digest realm=\"abc\", nonce=\"n1\", qop=\"auth\", opaque=\"op\"";
    CheckEq(emu::ParseWwwAuthParam(header, "realm"), "abc", "www-auth realm");
    CheckEq(emu::ParseWwwAuthParam(header, "nonce"), "n1", "www-auth nonce");
}

// ---------- envelope ----------
void TestEnvelope() {
    emu::MqttMessage m;
    m.topic = "acs/CPE/SN1/cmd";
    m.header.cmd_type = "SET_UPGRADE";
    m.header.correlation_data = "T9";
    m.payload = "binary-payload";
    auto cmd = emu::Envelope::parse(m);
    Check(cmd.has_value(), "envelope parse");
    if (!cmd) return;
    CheckEq(cmd->cmd_type, "SET_UPGRADE", "envelope cmdType");
    CheckEq(cmd->task_id, "T9", "envelope taskId (correlation_data)");
    CheckEq(cmd->payload, "binary-payload", "envelope payload passthrough");
}

// ---------- envelope: extractTaskId ----------
void TestExtractTaskId() {
    // 空 / 非 protobuf / JSON 载荷 → 空串
    CheckEq(emu::Envelope::extractTaskId(""), "", "taskId empty payload");
    CheckEq(emu::Envelope::extractTaskId("binary"), "", "taskId non-proto payload");
    CheckEq(emu::Envelope::extractTaskId("{\"taskId\":\"T1\"}"), "", "taskId json payload");

    // field 1 = taskId（wire type 2 string）：tag 0x0A + len + bytes
    {
        const std::string payload = {'\x0a', 9, 'T', 'A', 'S', 'K', '_', 'O', 'N', 'E'};
        CheckEq(emu::Envelope::extractTaskId(payload), "TASK_ONE", "taskId proto field1");
    }
    // 长度 varint 跨字节（>=128）
    {
        std::string payload;
        payload.push_back('\x0a');
        payload.push_back('\x80');  // len 128 的 varint 低字节
        payload.push_back('\x01');
        payload.append(128, 'a');
        CheckEq(emu::Envelope::extractTaskId(payload), std::string(128, 'a'),
                "taskId proto long string");
    }
    // 首字段不是 taskId → 空串
    {
        const std::string payload = {'\x12', 1, 'x'};  // field 2
        CheckEq(emu::Envelope::extractTaskId(payload), "", "taskId not first field");
    }
}

// ---------- registry ----------
void TestRegistry() {
    emu::CommandRegistry reg;
    reg.registerHandler("PING", [](const emu::InboundCommand&) {
        return emu::Response{"0", "pong"};
    });

    emu::InboundCommand c;
    c.cmd_type = "PING";
    auto r = reg.dispatch(c);
    Check(r && r->msg == "pong", "registry dispatch registered handler");

    emu::InboundCommand c2;
    c2.cmd_type = "NOPE";
    Check(!reg.dispatch(c2).has_value(), "registry unknown → nullopt");
}

// ---------- task store ----------
void TestTaskStore() {
    emu::upgrade::TaskStore store("/tmp/emud_test_upgrade");
    emu::upgrade::Task t;
    t.task_id = "T42";
    t.upg_url = "http://x/fw";
    t.md5 = "md5";
    t.state = emu::upgrade::State::Accepted;
    Check(store.save(t), "task store save");

    auto l = store.load("T42");
    Check(l && l->task_id == "T42" && l->upg_url == "http://x/fw", "task store load");
}

}  // namespace

int main() {
    TestJson();
    TestProto();
    TestDigest();
    TestEnvelope();
    TestExtractTaskId();
    TestRegistry();
    TestTaskStore();

    std::printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
