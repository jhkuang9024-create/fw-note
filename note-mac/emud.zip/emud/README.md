# emud（C++17 内嵌单进程）架构与开发文档

> 本文档基于 `vendor/starnet/modules/emud` 当前源码（2026-08）重新生成，包含：
> **总体架构与流程**、**分模块架构与流程**（升级 / 远程 SSH / 诊断）、**新特性适配指导**。
> emud 是星网（starnet）设备的云端接入代理（CPE agent），以**内嵌单进程**模式运行：
> 认证、MQTT 长连接、注册/心跳/离线、命令路由、升级、远程 SSH、诊断全部在**同一个进程**内以
> **纯函数调用**协作，**不引入任何模块间 IPC**（无 EventBus / Binder 业务 AIDL / Unix Socket / 独立服务进程）。

## 1. 目标与范围

| 维度 | 现状 |
|------|------|
| 部署模型 | **内嵌单进程**：一个 `emud` 常驻进程，框架与各业务能力在进程内直调 |
| 进程模型 | 单进程；模块间**纯函数调用**，无 IPC / EventBus / AIDL / Unix Socket |
| 语言 | 现代 C++17（RAII、`std::string`、`std::thread`、`std::optional`、依赖注入） |
| 命名空间 | `emu`（业务域：`emu::upgrade` / `emu::ssh_tunnel` / `emu::diagnostics`） |
| 网络 | MQTT v5（`libmosquitto`）+ HTTP（`libcurl`），均为设备 ↔ 平台的网络交互，不属于 IPC |
| 运行身份 | root（`emud.rc`：`user root; group root shell; class late_start`） |
| 构建 | AOSP/Soong 单轨：`source build/envsetup.sh && lunch cmcc_bj-userdebug && m emud` |

### 1.1 「无 IPC」的边界

「无 IPC」指**模块间**没有进程内通信中间件。以下**网络 / 平台能力 / 外部工具交互必须保留**——它们不是模块间通信：

- MQTT（`src/UciMqttClient.*` 封装 `libmosquitto`，MQTT v5）—— 设备 ↔ 平台 Broker；
- HTTP（`src/CurlHttpClient.*` 封装 `libcurl`）—— Digest 认证、文件上传等；
- `update_engine`（`src/upgrade/UpdateEngineClient.*`，`android.os.IUpdateEngineStable` binder）—— 升级链路对系统服务的**平台能力调用**（非模块间 IPC；因此 `libemud` 只能作为 core 模块，不能 vendor_available）；
- 外部工具（业务域以子进程方式托管）：`nmproxy`（反向隧道）、`dropbear`（SSH）、`tcpdump`（抓包）、`tar`（打包）。

## 2. 总体架构与流程

### 2.1 架构分层：共享核心 + 业务域

采用**「共享核心 + 业务域」**（feature-first + shared core）：核心沉淀跨功能复用能力，业务域各自成闭环，通过「注册」接入核心路由，核心不反向依赖任何域。

```mermaid
graph TD
    subgraph CORE[共享核心 core（不依赖任何域）]
        FW[Framework]
        RT[CommandRegistry / CorrelationCache]
        AH[ActionHandler]
        AUTH[Auth]
        REG[Register]
        HB[Heartbeat]
        OF[Offline]
        ENV[Envelope]
        FU[FileUpload]
        CFG[Config]
        MQ[IMqttClient → UciMqttClient]
        HTTP[IHttpClient → CurlHttpClient]
        PROTO[proto/*.proto → emud_proto]
    end
    subgraph UPG[upgrade 域]
        UH[UpgradeFeature]
        UF[UpgradeFsm]
        TS[TaskStore]
        PL[Pipeline: CurlDownloader / Md5Verifier / UpdateEngineApplier]
        OP[OtaPlatform / OtaPackage / PkgCleanup]
        UE[UpdateEngineClient → update_engine binder]
    end
    subgraph RC[ssh_tunnel 域]
        RCH[SshTunnelFeature]
        SSH[SshTunnelSession → dropbear + nmproxy]
    end
    subgraph DIA[diagnostics 域]
        DIAF[DiagnosticsFeature]
        CAP[CaptureService → tcpdump]
        UPL[FileUpload → HTTP multipart 上传]
    end

    FW --> RT
    FW --> AH
    FW --> AUTH
    FW --> REG
    FW --> HB
    FW --> OF
    FW --> MQ
    AUTH --> HTTP
    UH --> UF
    UF --> PL
    UF --> TS
    UF --> OP
    OP --> UE
    RCH --> SSH
    DIAF --> CAP
    DIAF --> UPL

    UPG -->|注册 SET_UPGRADE| RT
    RC  -->|注册 SET_REMOTE_SSH| RT
    DIA -->|注册 5 个诊断命令| RT
```

> 关键点：
> - 图中**无独立 channel 抽象**：事件上报（`publishEvent`）、命令回执（`publishCmdResp`）均为进程内函数调用。
> - 依赖方向单向：**域 → 核心**。核心通过 `CommandRegistry` 接收各域的「注册」，不 import 任何域。
> - 加新功能 = 在 `src/` 加一组 `XxxFeature.{h,cpp}` + `main.cpp` 里加一行 `emu::xxx::XxxFeature::registerSelf(*fw)`。

### 2.2 进程生命周期与启动流程

`main.cpp`：`Framework::create`（加载配置）→ 注册三个业务域（`registerSelf`）→ `fw->start()` → 主循环等待 SIGINT/SIGTERM → `fw->stop()`。

```mermaid
sequenceDiagram
    participant main as main.cpp
    participant fw as Framework
    participant auth as AuthSession
    participant mqtt as UciMqttClient
    participant reg as RegisterService
    participant hb as Heartbeat

    main->>fw: create(mqtt, http)
    fw->>fw: ConfigLoad()（config.json + data.json 首启 seed）
    main->>fw: UpgradeFeature / SshTunnelFeature / DiagnosticsFeature::registerSelf
    main->>fw: start()
    fw->>auth: AuthSession::run()（3 步 HTTP Digest，见 §4.3）
    alt auth 成功
        fw->>fw: 等待 connDelay（可选）
        fw->>mqtt: connect（jwt 密码；mode=0 走 TLS+CA；LWT 遗嘱）
        fw->>mqtt: subscribe(acs/mtv/{id}/cmd、acs/mtv/{id}/event_resp)
        fw->>reg: RegisterService::run()（订阅 reg_resp → 发布 DeviceRegister）
        fw->>hb: Heartbeat::start(server_keep_alive 默认 1800s)
        fw->>fw: setMessageCallback(onMqttMessage)
    else auth 不可用（dry-run）
        fw->>mqtt: connect(127.0.0.1:1883 兜底)
    end
```

`stop()` 顺序：`Offline::send("disconnect","normal")` → 停心跳 → 断 MQTT。

### 2.3 MQTT 主题契约

| 方向 | 主题模板 | 说明 |
|------|----------|------|
| 订阅 | `acs/{dt}/{id}/cmd` | 下行命令（`%s` 展开为设备 id：MAC 优先，SN 兜底） |
| 订阅 | `acs/{dt}/{id}/event_resp` | 平台对事件/心跳的响应 |
| 订阅 | `acs/{dt}/{id}/reg_resp` | 注册响应（`RegisterService::run` 动态订阅） |
| 发布 | `cpe/{dt}/all/reg` | 注册请求（`DeviceRegister`，带 v5 `response_topic`） |
| 发布 | `cpe/{dt}/{id}/cmd_resp` | 命令回执（`SetCommonRsp` / `GetCapturePacketInterfaceRsp`） |
| 发布 | `cpe/{dt}/all/event` | 事件上报（心跳 `H_BEAT`、升级 `E_UPGRADE` 等） |
| 发布 | `cpe/{dt}/all/offline` | 正常离线 + LWT 遗嘱异常离线（`Disconnect`） |

> `{dt}` = device_type（固定 `"mtv"`）；`{id}` = `DeviceId`（MAC 去冒号优先，SN 兜底）。

### 2.4 命令分发流程

```mermaid
sequenceDiagram
    participant mqtt as UciMqttClient(回调线程)
    participant fw as Framework::onMqttMessage
    participant env as Envelope::parse
    participant reg as CommandRegistry::dispatch
    participant domain as 业务域 handler
    participant mqtt2 as UciMqttClient

    mqtt->>fw: onMqttMessage(msg)
    fw->>fw: 主题 == reg_resp？→ handleRegResp 分流
    fw->>env: Envelope::parse(msg)（cmdType/corr 取自 v5 header，payload 直通）
    env-->>fw: InboundCommand
    fw->>reg: registry.dispatch(cmd)
    reg->>reg: ① 核心内置(ActionHandler) → ② 业务域注册 → ③ 配置 routes 兜底
    reg-->>fw: optional<Response>
    fw->>mqtt2: publishCmdResp → SetCommonRsp 发往 cpe/mtv/{id}/cmd_resp（回显 cmdType / correlation_data）
```

> ⚠️ **taskId 两套字段**：业务 taskId（如 `TASK_ONE_3953`，带 `TASK` 字样/下划线）在 **protobuf 载荷 field 1**（`Envelope::extractTaskId` 提取，各命令 proto 均定义 `taskId = 1`）；v5 header 的 `correlation_data`（32 位无横线 UUID）是平台消息关联 ID，两者可能不同。上行 cmd_resp/事件的 correlation_data **必须回显下行 corr**（不得用 body.taskId 覆盖，见 §4.5）。

## 3. 目录结构

```
emud/
├── Android.bp                    # libemud（cc_library）+ emud（cc_binary）+ emud_config/emud_data（prebuilt_etc）
├── emud.rc                       # init 服务定义（user root；初始化 /data/system/emud 目录；config 只读加载）
├── config/
│   ├── config.json               # 静态配置（只读，安装至 /system/etc/emud/，见 §8.2）
│   └── data.json                 # 运行时数据初始值（首启 seed 至 /data/system/emud/，见 §8.3）
├── proto/                        # 对外协议 wire 契约（proto2，aprotoc 生成 pb.h；66 个文件仅编 13 个）
│   ├── Android.bp                # emud_proto（cc_library_static，proto type:lite）
│   ├── SetUpgrade.proto          # SET_UPGRADE 入站
│   ├── SetCommonRsp.proto        # cmd_resp 通用回执
│   ├── EventUpgradeRet.proto     # 升级结果事件
│   ├── Heartbeat.proto / Disconnect.proto / DeviceRegister.proto / DeviceRegisterResp.proto
│   ├── SetRemoteControl.proto    # SET_REMOTE_SSH
│   ├── CommonReq.proto           # 无参命令
│   ├── GetCapturePacketInterfaceRsp.proto / GetCapturePacketParam.proto
│   ├── SetCaptureLog.proto / GetLogFile.proto
│   └── 其余 *.proto              # 纯文档定义（顶层 message 名冲突，未编入，见 §8.3）
├── src/                          # 全部源码（平铺）
│   ├── main.cpp                  # 程序入口（注入真实网络实现 + 注册 3 个业务域）
│   ├── Framework.{h,cpp}         # 进程内编排（start/stop/注册/事件上报/命令回执）
│   ├── Config.{h,cpp}            # ConfigLoad（config.json + data.json；设备信息读系统属性）
│   ├── MqttClient.h              # IMqttClient 抽象（MQTT v5 header 结构）
│   ├── UciMqttClient.{h,cpp}     # IMqttClient 实现（libmosquitto，MQTT v5，回调线程）
│   ├── HttpClient.h              # IHttpClient 抽象（get/post/postFile）
│   ├── CurlHttpClient.{h,cpp}    # IHttpClient 实现（libcurl，multipart 上传）
│   ├── Auth.{h,cpp}              # AuthSession（3 步 HTTP Digest → JWT/MQTT 参数）
│   ├── Digest.{h,cpp}            # Digest SHA-256（HA1/response/rspauth/WWW-Authenticate 解析）
│   ├── Register.{h,cpp}          # RegisterService（DeviceRegister 发布 + reg_resp 订阅）
│   ├── Heartbeat.{h,cpp}         # Heartbeat（周期心跳，H_BEAT）
│   ├── Offline.{h,cpp}           # Offline（正常离线 / 遗嘱离线）
│   ├── Command.h                 # InboundCommand / Response / CommandHandler
│   ├── CommandRegistry.{h,cpp}   # 命令注册与分发（内置 → 域 → routes）
│   ├── CorrelationCache.{h,cpp}  # taskId ↔ correlation_data 关联缓存
│   ├── ActionHandler.{h,cpp}     # 核心内置 handler（terminal / local / get_handlers）
│   ├── Envelope.{h,cpp}          # MQTT 消息 → InboundCommand 解析
│   ├── FileUpload.{h,cpp}        # UploadFile（HTTP multipart 上传，form 字段 file）
│   ├── UpgradeFeature.{h,cpp}    # 升级域：SET_UPGRADE 入口 + upgradeReport 上报
│   ├── UpgradeFsm.{h,cpp}        # 升级状态机（单 worker 线程 + recover 启动恢复）
│   ├── TaskStore.{h,cpp}         # 任务持久化（State 枚举 + save/load/listIncomplete）
│   ├── Pipeline.h                # IDownloader / IVerifier / IApplier 抽象
│   ├── OtaPackage.{h,cpp}        # OTA 包解析（libziparchive：payload.bin + payload_properties.txt）
│   ├── OtaDownloader.{h,cpp}     # CurlDownloader（libcurl：断点续传/重试/卡死检测/限速/空间检查）
│   ├── Md5Verifier.{h,cpp}       # Md5Verifier（OpenSSL MD5）
│   ├── UpdateEngineClient.{h,cpp}  # update_engine stable binder 客户端（applyPayloadFd）
│   ├── UpdateEngineApplier.{h,cpp} # 应用器（解析 OTA 包 → 平台 AB 应用）
│   ├── OtaPlatform.{h,cpp}       # 平台 OTA（boot mask / pending / TR069 / 重启 / 回滚检测）
│   ├── PkgCleanup.{h,cpp}        # 包目录空间管理（下载前清理 / 空间保证 / 任务包删除）
│   ├── SshTunnel.{h,cpp}         # 远程 SSH 域：SshTunnelFeature + SshTunnelSession（dropbear + nmproxy）
│   ├── DiagnosticsFeature.{h,cpp}  # 诊断域：抓包/取消/抓日志/批量日志（5 命令）
│   └── Capture.{h,cpp}           # CaptureService（tcpdump 子进程托管，多网卡）
└── tests/
    └── TestMain.cpp             # host 零依赖单测（注意：与当前 API 不同步，见 §10.6）
```

### 3.1 为什么按「业务域」而非「纯分层」

- 功能是**横向扩展**的：升级、远程 SSH、抓包、抓日志……平级、互不依赖，且都遵循同一模板（收命令 → 解析 → 状态/会话 → 执行 → 上报/上传）。
- 每个功能**自成闭环**：一组 `XxxFeature.{h,cpp}` = 一个功能，加/删功能只动对应文件，功能边界一眼可见（平铺于 `src/`，暂未按目录分层）。
- 跨功能复用显式下沉到 `core`（如 `UploadFile`、`CommandRegistry`），**守住「core 不依赖域」**。
- 各域通过「注册」接入核心，而非被核心引用：

```cpp
// src/main.cpp（节选）
auto fw = emu::Framework::create(std::make_shared<emu::UciMqttClient>(),
                                 std::make_shared<emu::CurlHttpClient>());
emu::upgrade::UpgradeFeature::registerSelf(*fw);            // 注册 SET_UPGRADE
emu::ssh_tunnel::SshTunnelFeature::registerSelf(*fw);       // 注册 SET_REMOTE_SSH
emu::diagnostics::DiagnosticsFeature::registerSelf(*fw);    // 注册诊断 5 命令
fw->start();
```

## 4. 共享核心（core）模块

### 4.1 Config（配置加载）

路径完全硬编码（`src/Config.h`）：

| 常量 | 路径 | 说明 |
|------|------|------|
| `kSystemConfigPath` | `/system/etc/emud/config.json` | 静态配置（只读，永不回写） |
| `kSystemConfigFallbackPath` | `/system/etc/emud.json` | 单文件布局兜底 |
| `kSystemDataSeedPath` | `/system/etc/emud/data.json` | 运行时数据初始值（seed 源） |
| `kDataDir` | `/data/system/emud` | 数据目录（CA 证书、log/、upgrade/） |
| `kDataPath` | `/data/system/emud/data.json` | 运行时数据（首启 seed，之后绝不覆盖） |

- `ConfigLoad()`：读 `config.json` → 解析为类型化 `Config`（auth / subscribe_topics / routes / event_routes / action_handlers / get_handlers）→ 读 `data.json`。
- **设备信息（`DeviceConfig`）不读 config.json**，运行时直接读系统属性（`src/Config.cpp`）：sn=`ro.serialno`、mac=`ro.mac`→`/sys/class/net/eth0/address`（去冒号）、model=`ro.product.model`、vendor=`ro.product.manufacturer`、firmware_ver=`ro.build.display.id`→release+incremental、firmware_ver_inner=`ro.build.version.incremental`→`ro.build.fingerprint`、hardware_ver=`ro.boot.hardware`、hardware_ver_inner=`ro.boot.hardware.revision`→`ro.boot.board.revision`→`ro.hardware.version`、carrier=`ro.product.carrier`→`persist.sys.operator`、province=`persist.sys.province`→`ro.product.province`、net_method=`persist.sys.netmethod`→`ro.boot.netmode`；`device_type` 固定 `"mtv"`、`trigger` 固定 `"BOOT"`。
- `DeviceId()`：MAC 优先，SN 兜底（用于 client_id 与 topic 拼接）；`ExpandTopic()` 展开 `%s`。

### 4.2 网络抽象（真实实现，无 mock）

```cpp
// src/MqttClient.h
struct MqttHeader {
  std::string cmd_type, event_type, correlation_data, response_topic;
  bool has_next = false;
};

class IMqttClient {
 public:
  virtual ~IMqttClient() = default;
  virtual int connect(const MqttConnectConfig&) = 0;
  virtual int subscribe(const std::string& topic, int qos) = 0;
  virtual int publish(const std::string& topic, const std::string& payload, int qos) = 0;
  virtual bool isConnected() const = 0;
  virtual int disconnect() = 0;
  virtual void setV5Header(const MqttHeader&) = 0;
  virtual void setMessageCallback(MqttMessageCallback cb) = 0;    // 消息回调（取代轮询）
  virtual void setDisconnectCallback(MqttDisconnectCallback cb) = 0;  // 断线回调（断线重认证/重连编排）
  virtual int updateCredentials(const std::string& username, const std::string& password) = 0;  // 更新凭据，自动重连生效
};

// src/HttpClient.h
class IHttpClient {
 public:
  virtual ~IHttpClient() = default;
  virtual HttpResponse get (const std::string& url, const HttpHeaders& = {}) = 0;
  virtual HttpResponse post(const std::string& url, const std::string& body,
                            const HttpHeaders& = {}) = 0;
  virtual HttpResponse postFile(const std::string& url, const std::string& filePath,
                                const std::string& formField, const HttpHeaders& = {}) = 0;  // multipart
};
```

实现（均编入 `libemud`）：

| 接口 | 实现 | 要点 |
|------|------|------|
| `IMqttClient` | `UciMqttClient` | libmosquitto MQTT v5；`mosquitto_loop_start` 回调线程；v5 property（cmdType/eventType/hasNext/correlation_data/response_topic）编解码；LWT 遗嘱；CONNACK 同步等待 5s；**断线重连自动重放订阅**（clean session 下 broker 侧订阅会清空）；`publish` 的 v5 header 为**一次性**（发布后即失效，避免 Offline 等携带过期属性） |
| `IHttpClient` | `CurlHttpClient` | libcurl；`get/post` + `postFile`（curl_mime multipart）；SSL 校验关闭（认证由 Digest 承担） |

`main.cpp` 直接注入真实实现（无 mock）。

### 4.3 Auth（认证：HTTP Digest → JWT/MQTT 参数）

`Framework::start` 中（`cfg.auth.enable && http_` 时）执行 `AuthSession::run()`，三步 HTTP 流程：

```mermaid
sequenceDiagram
    participant dev as 设备(AuthSession)
    participant srv as 认证服务端
    dev->>srv: ① GET /api/ems/web/mqtt/auth/rest/plugin/v1/ne-auth-mgr/{mac}
    srv-->>dev: 401 + WWW-Authenticate(realm, nonce, qop=auth)
    dev->>dev: Digest 授权头（HA1=SHA256(mac:realm:sn:digest_password)，SHA-256）
    dev->>srv: ② GET .../ne-auth-mgr?sn={sn}（Digest 授权）
    srv-->>dev: { authAddress, authToken }
    dev->>srv: ③ POST authAddress（Bearer authToken；body: deviceId/deviceType/nonce(32位hex)/ts(毫秒字符串)）
    srv-->>dev: { jwt, mqttIP, mqttPort, keepAlive, serverKeepAlive, connDelay, mode, sslCert, clientIP }
```

关键点：

- `AuthResult`：`jwt`（MQTT 密码）、`mqtt_ip/mqtt_port`、`keep_alive`（默认兜底 300）、`server_keep_alive`（默认兜底 1800，即心跳周期）、`conn_delay`（连接前等待秒数）、`mode`（`"0"`=TLS 长连接 / `"1"`=TCP 短连接 / `"2"`=不连接）、`ssl_cert`（服务端下发 CA，优先于 config 的 `ca_cert_path`）、`client_ip`（写入注册报文 netIp）。
- **断线重认证**：MQTT 断线（含 JWT 过期导致的拒绝连接）时，`Framework` 收到断线回调 → 复用同一 `AuthSession`（`reset()` 后重走三步认证）→ `updateCredentials` 刷新 MQTT 用户名/密码 → 等待 libmosquitto 自动重连。
- Digest 相关工具在 `src/Digest.*`（`DigestResponse` / `ParseWwwAuthParam`，OpenSSL SHA-256）。

### 4.4 Register / Heartbeat / Offline

- **Register**（`RegisterService::run`）：先订阅 `acs/{dt}/{id}/reg_resp`，再向 `cpe/{dt}/all/reg` 发布 `DeviceRegister`（v5 header 带 `response_topic`）。报文含：sn/mac/model/vendor/carrier/firmwareVer/hardwareVer/firmwareInnerVer/hardwareInnerVer/deviceType/netMethod/province、`trigger`（BOOT/BOOTSTRAP/OTHER）、`workMode="0"`、`netIp`（字段 19，认证 token 的 clientIP），以及**能力列表 `funcList`**：`{"GET_INSPECTION_INFO","REBOOT","REGISTER","SET_REMOTE_SSH","SET_UPGRADE","SET_FILE_DOWNLOAD","GET_CAPTURE_PACKET_INTERFACE","GET_CAPTURE_PACKET_FILE","GET_CAPTURE_PACKET_FILE_CANCEL","SET_CAPTURE_LOG","GET_LOG_FILE"}`（平台依赖它判断能力/在线状态，勿删；已实现命令必须声明，缺声明会导致平台提示"设备不支持此功能"——诊断域 5 个抓包/抓日志命令、nio 资源文件下发 `SET_FILE_DOWNLOAD` 均已声明）。注册结果（code/workMode/period/hasNext）由 `Framework` 在收到 `reg_resp` 时经 `RegisterService::handleRegResp` 回填（`result()` 可查）。
- **Heartbeat**（`Heartbeat::loop`）：周期（`server_keep_alive` 默认 1800s）发布 `Heartbeat{sn,mac}` 到 `cpe/{dt}/all/event`，v5 header `eventType=H_BEAT`、`response_topic=acs/{dt}/{id}/event_resp`（`{id}` 为设备 id：MAC 优先、SN 兜底，与 Framework 订阅的 event_resp topic 一致）。
- **Offline**（`Offline::send`）：发布 `Disconnect{sn,status,reason}` 到 `cpe/{dt}/all/offline`；`Framework::stop()` 正常离线发 `("disconnect","normal")`；MQTT 连接的 LWT 遗嘱异常掉线发 `status="offline"`。

### 4.5 命令分发与内置 handler

所有「处理能力」统一为一种形态 `CommandHandler`，按**优先级**分发：核心内置 → 业务域注册 → 配置 `routes` 兜底（`src/CommandRegistry.cpp`）。

```cpp
// src/Command.h
struct InboundCommand {
  std::string cmd_type;   // MQTT v5 header 的 cmdType
  std::string task_id;    // correlation_data
  std::string payload;    // protobuf 二进制载荷
  MqttHeader header;
};

struct Response {
  std::string code;   // "0"成功 / "-1"失败；ack 时用路由的 ack_status
  std::string msg;    // 消息；GET_* 的 JSON 结果经此字段返回
  std::vector<std::string> interface_list;  // GET_CAPTURE_PACKET_INTERFACE 的接口列表
};

using CommandHandler = std::function<std::optional<Response>(const InboundCommand&)>;

// src/CommandRegistry.h（当前 API）
class CommandRegistry {
 public:
  void registerHandler(const std::string& cmdType, CommandHandler h);         // 业务域（程序化）
  void registerBuiltin(const std::string& cmdType, CommandHandler h);         // 核心内置
  void loadRoutes(const Config& cfg);                                          // 配置 routes（兜底）
  std::optional<Response> dispatch(const InboundCommand& cmd) const;           // 内置 → 域 → routes
};
```

- **核心内置 handler**（`ActionHandler`）：`action_handlers`（如 `REBOOT` → `system("reboot")`）与 `get_handlers`（如 `GET_ROBOT_STATUS` → 从 `data.json` 取字段），由 `Framework` 构造时 `registerBuiltins` 注册。
- **业务域注册**：各域 `registerSelf` 里调 `fw.registerCmdHandler("SET_UPGRADE", handler)`。
- **配置兜底**：`routes` 中无域 handler 的命令直接回 `{ack_status, ack_msg}`。
- **回执封装**（`Framework::publishCmdResp`）：默认 `SetCommonRsp{code:"0",msg:"ok",response{status,msg}}`（顶层固定 0/ok，业务状态在 `response.status/msg`）；`GET_CAPTURE_PACKET_INTERFACE` 特判回 `GetCapturePacketInterfaceRsp{..., response.interfaceList}`。
- **事件上报**（`Framework::publishEvent`）：按 `event_routes` 查 `mqtt_event`/proto，发布到 `cpe/{dt}/all/event`，可回显下行 `correlation_data`。
- **`Envelope::parse`**：MQTT 消息 → `InboundCommand`（cmd_type/task_id 取自 v5 header，payload 直通）；`Envelope::extractTaskId(payload)` 从 protobuf 载荷 field 1 提取**业务 taskId**（框架日志打印用，区分 header corr）。
- **`CorrelationCache`**：`put(taskId, correlationData)` 缓存下行 corr；`resolve(taskId, explicit)` 返回显式值 → 缓存 → taskId 兜底（升级异步回传对账用）。

### 4.6 UploadFile（HTTP multipart 上传）

`UploadFile(http, path, url)`：`http->postFile(url, path, "file")`（curl_mime，form 字段名固定 `file`），供诊断域上传 tar.gz 结果包复用。

## 5. 业务域：升级特性（upgrade）

### 5.1 模块组成

| 文件 | 职责 |
|------|------|
| `UpgradeFeature.{h,cpp}` | 域入口：注册 `SET_UPGRADE`、输入校验、ack、`upgradeReport` 事件上报 |
| `UpgradeFsm.{h,cpp}` | 升级状态机：单 worker 线程按 `State` 顺序驱动任务；`recover()` 启动恢复 |
| `TaskStore.{h,cpp}` | 任务持久化（`/data/system/emud/upgrade/tasks/{taskId}.json`） |
| `Pipeline.h` | `IDownloader` / `IVerifier` / `IApplier` 三个抽象原语 |
| `OtaDownloader.{h,cpp}` | `CurlDownloader`：libcurl 下载（断点续传/重试/卡死检测/限速/空间检查） |
| `Md5Verifier.{h,cpp}` | OpenSSL MD5 校验 |
| `OtaPackage.{h,cpp}` | OTA 包解析（libziparchive：`payload.bin` 偏移/大小 + `payload_properties.txt` headers） |
| `UpdateEngineApplier.{h,cpp}` | 应用器：解析 OTA 包 → 平台 AB 应用 |
| `UpdateEngineClient.{h,cpp}` | `android.os.IUpdateEngineStable` binder 客户端（`applyPayloadFd`） |
| `OtaPlatform.{h,cpp}` | 平台 OTA 集成：boot mask / pending / TR069 忙检查 / 重启 / 回滚检测 |
| `PkgCleanup.{h,cpp}` | 包目录空间管理（`/data/system/emud/upgrade/packages`） |

```mermaid
graph LR
    subgraph UPG[upgrade 域]
        UH[UpgradeFeature]
        UF[UpgradeFsm]
        TS[TaskStore]
        DL[CurlDownloader]
        VF[Md5Verifier]
        AP[UpdateEngineApplier]
        OP[OtaPlatform]
        PC[PkgCleanup]
        UE[UpdateEngineClient]
        PK[OtaPackage]
    end
    UH --> UF
    UF --> TS
    UF --> DL
    UF --> VF
    UF --> AP
    UF --> PC
    AP --> PK
    AP --> OP
    OP --> UE
```

### 5.2 命令入口：SET_UPGRADE

`UpgradeFeature::onSetUpgrade`（`fw.registerCmdHandler("SET_UPGRADE", ...)`）：

1. 解析 `SetUpgrade{taskId, upgUrl, md5, hasNext, traffic}`；
2. 输入校验：
   - `TaskIdSafe`：仅字母数字与 `_-.`，长度 ≤ 64；
   - `UrlAllowed`：仅 `http(s)://`、无控制字符；可选环境变量 `EMU_UPG_URL_HOST_ALL` 主机白名单（逗号分隔前缀匹配）；
   - 队列上限：`fsm_->pendingCount() >= 4` 拒绝（`"upgrade queue full"`）；
3. **记录下行 corr**：`fw_.correlation().put(t.task_id, cmd.task_id)`（供升级事件回显对账）；
4. `store_->save(t)`（`State::Accepted`）→ `fsm_->enqueue(t)` 异步执行；
5. 即时 ack `Response{"1","received"}`（status=1 终端已接收）；后续状态经 `upgradeReport`（`E_UPGRADE`）事件上报。

### 5.3 升级状态机与状态契约

状态枚举（`TaskStore.h`，**持久化数值稳定，不得调整顺序**）：

```
Idle=0 → Accepted → Downloading → Downloaded → Verifying → Applying → PendingReboot → Success / Failed
```

| State | 上报 status（ContractStatus） | 说明 |
|-------|-------------------------------|------|
| `Accepted` | `"2"` | 已接收 |
| `Downloading` | `"2"`（**不触发事件**） | 下载开始只持久化不报事件（避免平台过早收「下载成功」） |
| `Downloaded` | `"2"` | 下载完成，**此处才首次报 status=2** |
| `Verifying` | `"2"` | MD5 校验中 |
| `Applying` | `"2"` | 应用中 |
| `PendingReboot` | `"0"` | AB 应用成功，重启前**只报一次** status=0 |
| `Success` | `"0"` | 成功（stub 模式 / 重启后 recover 补发） |
| `Failed` | fail_code==1 → `"-2"`（下载失败）；其余 → `"-1"` | 失败 |

fail_code 约定：1=下载失败，2=校验失败，3=应用失败/TR069 忙，4=重启中断。

`setState(t, s, report)`：持久化 + 可选上报；`report=false` 仅持久化（下载开始时用）。

### 5.4 流水线 Pipeline（worker 线程内 `runSync`）

```mermaid
sequenceDiagram
    participant fsm as UpgradeFsm::runSync
    participant pc as PkgCleanup
    participant dl as CurlDownloader
    participant vf as Md5Verifier
    participant ap as UpdateEngineApplier
    participant op as OtaPlatform

    fsm->>fsm: setState(Downloading, report=false)
    fsm->>pc: beforeDownload(保留当前任务的 .tmp/.bin) + ensureSpace(200MB)
    fsm->>dl: download(url, packages/{taskId}.bin, traffic)
    dl-->>fsm: ok / fail(fail_code=1, 保留 .tmp 断点续传)
    fsm->>fsm: setState(Downloaded) → 上报 status=2
    fsm->>vf: verify(path, md5)
    vf-->>fsm: ok / fail(fail_code=2, removeTask)
    fsm->>fsm: setState(Applying)
    fsm->>op: tr069Busy()？（sys.upgrade.router.status / sys.upgrade.stb.status=1）
    fsm->>ap: apply(localPath, taskId)  ← 解析 OTA 包 + AB 应用
    alt 返回 0（EMU_OTA_MODE=stub）
        fsm->>fsm: setState(Success) "success (stub)"
    else 返回 1（已应用到 inactive 槽位）
        fsm->>fsm: setState(PendingReboot, status=0 只报一次) → sleep(2)
        fsm->>op: rebootNormal()（sync + sys.powerctl reboot）
    else 返回 <0
        fsm->>fsm: setState(Failed, fail_code=3, removeTask)
    end
```

- **下载器**（`CurlDownloader`）：写 `<path>.tmp`，支持 `CURLOPT_RESUME_FROM_LARGE` 断点续传（`PkgCleanup::beforeDownload` 仅清理**其它任务**的产物，保留当前任务的 `.bin/.tmp` 供续传）；最多 10 次尝试（可重试错误：连接失败/超时/部分文件等）；卡死检测（180s 无进度 abort）；限速 `traffic`（`"10M"`=10MB/min）；下载前检查 ≥64MB 空闲；成功 `rename` 为 `.bin`。
- **校验**：md5 为空则跳过；失败删除任务包。
- **应用**（`UpdateEngineApplier`）：
  1. `OtaPackage::parse`：zip 包内找 `payload.bin`（记录 offset/uncompressed_size）+ `payload_properties.txt`（拆 KEY=VALUE 行，处理 CRLF）；非 zip 回退为裸 payload（offset=0）；
  2. `OtaPlatform::applyAbUpdate`：`EMU_OTA_MODE=stub` → 直接返回 0（跳过真实安装）；否则 `setBootMask(0x02)` → `savePending(taskId, path)` → `ApplyUpdateEngine`；
  3. `ApplyUpdateEngine`：bind 回调（`BnUpdateEngineStableCallback`）→ `applyPayloadFd(pfd, offset, size, headers)` → 阻塞等待完成回调（超时 2h）；`ErrorCode kSuccess(0)` / `kUpdatedButNotActive(52)` 视为成功；
  4. 返回：`0`=stub 成功（无需重启）、`1`=成功且需重启、`<0`=失败（清理 boot mask/pending）。

### 5.5 平台 OTA 集成（OtaPlatform）

- 数据根：`/data/system/emud/upgrade/`，含 `boot_mask`（应用前写 `0x02`）与 `pending_task`（两行：taskId + 包路径）。
- `tr069Busy()`：系统侧升级占中检查（`sys.upgrade.router.status` / `sys.upgrade.stb.status`）。
- `rebootNormal()`：`sync()` 后 `sys.powerctl = reboot` 触发普通重启切换槽位。
- `readLastInstallResult()`：检查 `/data/misc/update_engine/prefs/rollback-happened` 是否存在——存在说明上次 AB 升级失败回滚。

### 5.6 崩溃恢复 recover()

`UpgradeFeature` 构造时调用（进程每次启动）：

1. `readLastInstallResult() != 0`（回滚过）→ 跳过 pending 恢复；
2. 读 `boot_mask`：为 0 说明**没有升级在途**（上次应用前崩溃/被清），仅 `clearPending()` 清残留，不恢复任务；非 0 才读 `pending_task` 恢复；
3. 有 pending：将任务标记 `Success`（`"installed (recovered)"`）并**补发 status=0 事件**（解决「重启前只报 PENDING_REBOOT、重启后补发 SUCCESS」的平台对账）；
4. `clearBootMask()` + `clearPending()`；
5. `listIncomplete()`（非 Success 任务）兜底：`PendingReboot` → `Success`；其余 → `Failed`（`"interrupted by restart"`, fail_code=4）。

### 5.7 升级完整时序（一次成功 AB 升级）

```mermaid
sequenceDiagram
    participant p as 平台
    participant f as emud
    participant ue as update_engine
    f->>f: SET_UPGRADE → 校验 → corr 缓存 → save(Accepted) → enqueue
    f-->>p: cmd_resp SetCommonRsp{status:1, "received"}
    f->>f: Downloading(不报) → Downloaded(报 status=2)
    f->>f: Verifying → Applying
    f->>ue: applyPayloadFd(payload.bin)
    ue-->>f: 完成回调
    f-->>p: upgradeReport E_UPGRADE{status:0, "success, pending reboot"}
    f->>f: sleep(2) → rebootNormal（设备重启切换槽位）
    Note over f: 重启后
    f->>f: recover()：pending_task → Success → 补发 status=0
    f-->>p: upgradeReport E_UPGRADE{status:0, "installed (recovered)"}
```

## 6. 业务域：远程 SSH（ssh_tunnel）

### 6.1 模块组成与流程

`SshTunnelFeature`（注册 `SET_REMOTE_SSH`）→ `SshTunnelSession`（以 RAII 托管 `dropbear` + `nmproxy` 两个子进程）。

```mermaid
sequenceDiagram
    participant p as 平台
    participant f as emud(SshTunnelFeature)
    participant s as SshTunnelSession
    participant db as dropbear
    participant np as nmproxy

    p->>f: SET_REMOTE_SSH（SetRemoteControl: relayEnable/connectKey/server/ports…）
    f->>f: 解析 + 校验（key / server 为空 → 回执 "-1"）
    alt relayEnable = false
        f->>s: stop()（SIGTERM → 10×100ms → SIGKILL → waitpid）
        f-->>p: cmd_resp SetCommonRsp{"0","ok"}
    else 开启
        f->>s: start(cfg)
        s->>db: fork+execve dropbear -p <relayDestPort> -R -F
        s->>np: fork+execve nmproxy -d <server> -r <port> -s <destAddr> -l <port> -t 0 -k <key>
        f-->>p: cmd_resp SetCommonRsp{"0","ok"}
    end
```

关键实现点（`src/SshTunnel.*`）：

- `TunnelConfig` 默认值：`relay_server_port=8022`、`relay_dest_address="127.0.0.1"`、`relay_dest_port=22`、`nmproxy_path=/system/bin/nmproxy`、`dropbear_path=/system/xbin/dropbear`、`enable_dropbear=true`。
- `start` 顺序：先拉 `dropbear`（`-R` 允许远端反向端口转发、`-F` 前台运行），再 `fork+execve` `nmproxy`；子进程 exec 失败通过 pipe 检测。
- **RAII 生命周期**：`stop()`/析构 = SIGTERM → 每 100ms 重试最多 10 次 → SIGKILL → `waitpid` 回收，无僵尸、无 `pkill -f` 误杀；`isAlive()` 用 `kill(pid,0)`。
- 回执：启用/禁用均回 `Response{"0","ok"}`；`relayEnbable=false` 时先 `tunnel_.stop()` 再回执。

## 7. 业务域：诊断（diagnostics）

### 7.1 命令清单

| cmdType | 入站 proto | 行为 |
|---------|-----------|------|
| `GET_CAPTURE_PACKET_INTERFACE` | —（回执用 `GetCapturePacketInterfaceRsp`） | 枚举 `/sys/class/net` 非 `lo` 接口 → 回执 `interface_list` |
| `GET_CAPTURE_PACKET_FILE` | `GetCapturePacketParam` | 单槽任务：按接口/时长/大小抓包 → tar.gz → HTTP 上传 |
| `GET_CAPTURE_PACKET_FILE_CANCEL` | — | 取消抓包（`cancel_.store(true)` + `capture_.stop()`） |
| `SET_CAPTURE_LOG` | `SetCaptureLog` | 执行 shell → 周期收集日志（≤300s）→ tar.gz → 上传 |
| `GET_LOG_FILE` | `GetLogFile` | 按 `logType`/`filePath` 收集指定文件/目录 → tar.gz → 上传 |

### 7.2 抓包 / 抓日志流程

```mermaid
sequenceDiagram
    participant p as 平台
    participant f as emud(DiagnosticsFeature)
    participant cap as CaptureService
    participant tar as /system/bin/tar
    participant up as FileUpload

    p->>f: GET_CAPTURE_PACKET_FILE{interface, duration, packetSize, port, protocol, ipProtocol, uploadUrl}
    f->>f: tryAcquireTask（互斥，单任务槽）
    f-->>p: cmd_resp{"0","ok"}（后台执行，结果异步上传）
    f->>cap: start(iface(s)) → tcpdump -i <iface> -w <pcap>
    Note over cap: 满足终止条件（duration / packetSize / cancel）
    f->>cap: stop()（SIGTERM → SIGKILL → waitpid）
    f->>tar: tar -czf <name>.tar.gz 采集内容
    f->>up: upload(tar.gz, buildUploadUrl(uploadUrl, true))
    f->>f: cleanup + 释放任务槽
```

关键实现点（`src/trace/DiagnosticsFeature.*` / `src/trace/Capture.*`）：

- **单任务互斥**：`tryAcquireTask` 保证同时只有一个抓包/抓日志任务；完成后释放。
- **后台线程**：命令先即时 ack，抓包/打包/上传都在 background thread 执行。
- **抓包**（`CaptureService`）：每接口一个 `tcpdump -i <iface> -w <pcap>` 子进程；单接口输出 `capture_packet.pcap`，多接口输出 `capture_<iface>.pcap`；过滤表达式由 protocol/port/ipProtocol（`ipv4`→`ip`、`ipv6`→`ip6`）组合。
- **上传 URL 约定**（`buildUploadUrl`）：`uploadUrl` 含 `{eof}` 占位则替换为 `true/false`，否则末尾追加 `/true`、`/false`。
- **打包**：`/system/bin/tar` 子进程，产物落 `/data/system/emud/log/`（`kDiagDir`）。
- **`SET_CAPTURE_LOG`**：先 `system(shell)` 产出日志，再每 2s 采集一次目录内容直至 duration（上限 300s）。
- **`GET_LOG_FILE`**：`logType=="0"` 且给出 `filePath` 时，按 `;` 拆分逐个收集；否则采集整个 `kDiagDir`。

## 8. 构建与配置

### 8.1 构建（AOSP/Soong 单轨）

```bash
source build/envsetup.sh
lunch cmcc_bj-userdebug
m emud
```

`Android.bp` 目标：

| 目标 | 类型 | 内容 |
|------|------|------|
| `emud_config` | `prebuilt_etc` | 安装 `config.json` → `/system/etc/emud/`（只读） |
| `emud_data` | `prebuilt_etc` | 安装 `data.json` → `/system/etc/emud/`（首启 seed 源） |
| `emud_proto` | `cc_library_static` | `proto/*.proto` 经 Soong `proto` 块（type `lite`）生成 C++，供 `libemud` 链接 |
| `libemud` | `cc_library` | `srcs: ["src/*.cpp"]` 排除 `main.cpp`；`cflags: -Wall -Wextra -std=c++17`；静态链接 `emud_proto`，共享链接 `libcrypto_openssl` / `libprotobuf-cpp-lite` / `libjsoncpp` / `libmosquitto` / `libcurl` / `liblog` / `libziparchive` / `libbinder` / `libutils` / `libbase` / `libupdate_engine_stable-V1-cpp` |
| `emud` | `cc_binary` | 仅编译 `src/main.cpp`，链接 `libemud` / `libjsoncpp` / `liblog`，`init_rc: ["emud.rc"]` |

> ⚠️ `libemud` 是 **core（system 分区）模块**：`libupdate_engine_stable-V1-cpp` 只对 core 模块可见，因此 `libemud` **不得**声明 `vendor_available` / `product_available`（否则升级链路编译失败）。

### 8.2 配置与数据目录（完全硬编码，无运行参数）

- **配置目录**（只读）：`config.json` → `/system/etc/emud/config.json`（优先），兜底 `/system/etc/emud.json`；**只读、永不回写、启动不复制到 /data**，OTA 覆盖安全。
- **数据目录**（可读写）：`/data/system/emud/`；`data.json` 首启从 `/system/etc/emud/data.json` seed，之后**绝不覆盖**，保证跨重启保留；CA 证书（`devops_ca_<clientId>.pem`）、诊断日志（`log/`）、升级（`upgrade/`：`tasks/`、`packages/`、`boot_mask`、`pending_task`）均落于此。

`config/config.json`（实际内容）：

```json
{
  "auth": {
    "enable": true,
    "auth_server": "http://211.137.105.224:8090",
    "digest_password": "xxx",
    "ca_cert_path": "/tmp/cert.pem"
  },
  "subscribe_topics": [
    { "topic": "acs/mtv/%s/cmd", "qos": 1 },
    { "topic": "acs/mtv/%s/event_resp", "qos": 1 }
  ],
  "routes": [
    { "cmd_type": "SET_UPGRADE", "ack_status": "1", "ack_msg": "received" },
    { "cmd_type": "SET_REMOTE_SSH", "ack_status": "0", "ack_msg": "ok" },
    { "cmd_type": "GET_CAPTURE_PACKET_INTERFACE", "ack_status": "0", "ack_msg": "ok" },
    { "cmd_type": "GET_CAPTURE_PACKET_FILE", "ack_status": "0", "ack_msg": "ok" },
    { "cmd_type": "GET_CAPTURE_PACKET_FILE_CANCEL", "ack_status": "0", "ack_msg": "ok" },
    { "cmd_type": "SET_CAPTURE_LOG", "ack_status": "0", "ack_msg": "ok" },
    { "cmd_type": "GET_LOG_FILE", "ack_status": "0", "ack_msg": "ok" }
  ],
  "event_routes": [
    { "event_class": "upgradeReport", "mqtt_event": "E_UPGRADE" },
    { "event_class": "heartbeat", "mqtt_event": "H_BEAT" },
    { "event_class": "offline", "mqtt_event": "OFFLINE" }
  ],
  "action_handlers": [
    { "action": "REBOOT", "handler": "terminal", "command": "reboot" },
    { "action": "GET_ROBOT_STATUS", "handler": "local", "command": "" }
  ],
  "get_handlers": {
    "GET_ROBOT_STATUS": { "data_key": "robot_status", "fields": ["online", "version"] }
  }
}
```

> 注：`register` 段及 `routes`/`event_routes`/`action_handlers` 的 `target_module`/`proto`/`message_type`/`json_field`/`data_key` 等旧字段**已移除**（加载器从未读取）；订阅/注册 topic 由代码按设备 id 拼接（`ExpandTopic`/`RegisterService`），不来自 config。

`config/data.json`（运行时数据初始值）：

```json
{
  "robot_status": { "online": true, "version": "1.0.0" }
}
```

`emud.rc`：

```ini
service emud /system/bin/emud
    class late_start
    user root
    group root shell

on early-boot
    mkdir /data/system/emud 0755
    mkdir /data/system/emud/log 0755
    restorecon_recursive /data/system/emud
```

### 8.3 proto 编译约束

`proto/` 下共 66 个 `.proto`，但**仅 13 个编入 `emud_proto`**（`Android.bp` 的 `proto.srcs` 显式列出）：`SetUpgrade` / `SetCommonRsp` / `EventUpgradeRet` / `Heartbeat` / `Disconnect` / `DeviceRegister` / `DeviceRegisterResp` / `SetRemoteControl` / `CommonReq` / `GetCapturePacketInterfaceRsp` / `GetCapturePacketParam` / `SetCaptureLog` / `GetLogFile`。

> 原因：其余文件存在**顶层 message 名冲突**（`Params`×6、`Response`×2、`Record`×1），无法全量编译。新增协议前先检查顶层 message 是否重名；冲突时改名或拆子目录。

## 9. 对外协议契约

wire 契约唯一数据源为 `proto/` 目录下的 `.proto`（`proto2`，`package emu.proto`），字段编号即对外 wire 契约；C++ 侧由 Soong 在构建时用 `aprotoc` 生成 `*.pb.h`。

| 消息 | 用途 | 关键字段（wire 编号） |
|------|------|----------|
| `SetUpgrade` | `SET_UPGRADE` 入站 | task_id=1, upg_url=2, md5=3, has_next=4, traffic=5 |
| `SetCommonRsp` | `cmd_resp` / ack | code=1, msg=2, response=3 |
| `EventUpgradeRet` | 升级结果事件 | sn=1, mac=2, params=3（task_id/status/msg） |
| `Heartbeat` | 心跳 | sn=1, mac=2 |
| `Disconnect` | 离线 | sn=1, status=2, reason=3 |
| `DeviceRegister` | 注册请求 | mac=1, trigger=2, sn=11, device_type=12, …（funcList 能力列表） |
| `DeviceRegisterResp` | 注册响应 | code=1, msg=2, work_mode=3, period=4, has_next=5 |
| `SetRemoteControl` | `SET_REMOTE_SSH` 入站 | relay_enable=1, relay_connect_key=2, relay_server_address=3, relay_server_port=4, relay_dest_address=5, relay_dest_port=6, has_next=7 |
| `GetCapturePacketInterfaceRsp` | `GET_CAPTURE_PACKET_INTERFACE` 回执 | code=1, msg=2, response=3（status/msg/interface_list） |
| `GetCapturePacketParam` | `GET_CAPTURE_PACKET_FILE` 入站 | task_id=1, interface=2, packet_size=3, duration=4, port=5, protocol=6, ip_protocol=7, upload_url=8, has_next=9 |
| `SetCaptureLog` | `SET_CAPTURE_LOG` 入站 | task_id=1, duration=2, upload_url=3, shell=4, has_next=5 |
| `GetLogFile` | `GET_LOG_FILE` 入站 | task_id=1, log_type=2, file_path=3, upload_url=4, has_next=5 |
| `CommonReq` | 诊断无参命令入站 | has_next=1 |

> ⚠️ **aprotoc 访问器坑**：生成的访问器全部**小写**——`taskId`→`taskid()`、`hasNext`→`hasnext()`、`uploadUrl`→`uploadurl()`、`iPProtocol`→`ipprotocol()`、`interfaceList`→`interfacelist()`、`packetSize`→`packetsize()`、`logType`→`logtype()`、`filePath`→`filepath()`、`relayEnbable`→`relayenbable()`。写代码前先查生成头文件。

MQTT v5 header 契约（`src/MqttClient.h` 的 `MqttHeader`）：`cmdType` / `eventType` / `correlation_data` / `response_topic` / `has_next`（均为不定长 `std::string`，经 v5 user properties + correlation data 传输）。

事件时序契约（平台侧依赖，勿破坏）：

- 升级**下载开始不报事件**，`Downloaded` 才首次报 status=2；`PendingReboot` 重启前只报一次 status=0；`Success` 在重启后由 `recover()` 补发 status=0（correlation_data 回显下行 corr）。
- 事件 `mqtt_event` 用 `E_UPGRADE`（不是 `UPGRADE_RET`）。

持久化契约（`src/upgrade/TaskStore.h`）：任务根目录 `/data/system/emud/upgrade`，每任务一个 `tasks/{taskId}.json`；`State` 枚举顺序（`Idle=0 → Accepted → … → Failed`）即持久化数值契约，**不得调整**。

## 10. 测试

`tests/TestMain.cpp` 提供**极简 host 零依赖**单测框架（`Check` / `CheckEq`），覆盖：

- JSON 解析与 round-trip（jsoncpp）
- protobuf wire 打包/解包（`SetUpgrade` / `EventUpgradeRet` 等 round-trip）
- HTTP Digest（`src/Digest.*`）：SHA-256 输出确定性、`ParseWwwAuthParam` 解析
- `Envelope::parse` 信封解析
- `CommandRegistry` 注册与分发（未知 cmdType → `nullopt`）
- `TaskStore` 序列化 / 反序列化（`/tmp/emud_test_upgrade`）

> 测试未接入 Soong 模块（host 侧手工编译）：`g++ -std=c++17 tests/TestMain.cpp src/{Config,Digest,Envelope,CommandRegistry,TaskStore}.cpp -I src -I proto -ljsoncpp -lprotobuf -o /tmp/emud_test && /tmp/emud_test`（以实际源码为准）。

## 11. 新特性适配指导

新增一个业务特性（域）只需 5 步，全部围绕「注册」接入，**核心零改动**：

1. **实现 Feature 类**：在 `src/` 新增 `XxxFeature.{h,cpp}`，仿照现有域写静态自持实例 + `registerSelf(Framework&)`：

   ```cpp
   // src/XxxFeature.h（示意）
   namespace emu::foo {
   class XxxFeature {
    public:
     static void registerSelf(Framework& fw);          // 被 main.cpp 调用一次
     std::optional<Response> onXxxCmd(const InboundCommand& cmd);
    private:
     static XxxFeature* self_;                          // 自持实例（静态生命周期）
     Framework* fw_ = nullptr;
   };
   }
   ```

2. **注册命令**：`registerSelf` 里 `fw.registerCmdHandler("CMD_TYPE", [this](const InboundCommand& c){ return onXxxCmd(c); })`；handler 返回 `std::optional<Response>`（`nullopt` = 无回执）。

3. **接入 main**：`src/main.cpp` 增加一行 `emu::foo::XxxFeature::registerSelf(*fw);`。

4. **协议**：
   - `proto/` 新增 `XxxCmd.proto`（proto2，`package emu.proto`），**先查顶层 message 名是否与已有冲突**（`Params`/`Response`/`Record` 已占用）；
   - `proto/Android.bp` 的 `proto.srcs` 加入新文件；注意 aprotoc 生成的访问器全小写（`taskId`→`taskid()`）；
   - 命令入站 proto 必须含 `has_next` 等必需字段。

5. **配置**：`config/config.json` 的 `routes` 增加 `{ "cmd_type": "CMD_TYPE", "ack_status": "...", "ack_msg": "..." }`；异步结果上报则在 `event_routes` 增加 `{ "event_class": "xxxReport", "mqtt_event": "E_XXX" }`，代码里 `fw.publishEvent("xxxReport", payload, corr)`（corr 用 `fw.correlation().resolve(taskId, cmd.task_id)` 回显对账）。

6. **构建**：`Android.bp` 的 `libemud.srcs` 增加对应源文件（当前平铺于 `src/`），然后 `m emud` 验证。

外部命令（如 `nmproxy`、`tcpdump`）一律经**子进程 + RAII** 托管（见 §6/§7），禁止裸 `system()` + `pkill`。

> 核心不 import 任何域；新增域只需上述改动，保持「域 → 核心」单向依赖。
