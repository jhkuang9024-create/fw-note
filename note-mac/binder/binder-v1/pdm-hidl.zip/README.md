# pdm-hidl —— 绑定式(binderized)HIDL 版本的 unifykey 键值服务

本目录用**绑定式 HIDL**重实现了 [vendor/starnet/pdm](../pdm) 的全部功能:读写 Amlogic
unifykeys(`/sys/class/unifykeys/{name,read,write,lock}`)、键值 → 系统属性同步、
`work_mode` 用户/工厂模式标志文件,对外提供 `set / get / list` 三个操作。

与旧实现的关系:**并存,互不影响**。旧 `pdm-service`(`vendor.starnet.pdm`,私有 binder 协议,
走 `/dev/binder`)与新的 `vendor.starnet.pdm@1.0::IPdm/default`(HIDL,走 `/dev/hwbinder`、
注册到 hwservicemanager)可以同时运行;确认新实现无误后,可按第 10 节停用旧服务。

## 1. 目录结构

```
vendor/starnet/pdm-hidl/
├── pdm-hidl.mk                                 # PRODUCT_PACKAGES 声明，由 ../starnet.mk include 一行引入
│                                               # （sepolicy 目录在 device/amlogic/common/sepolicy.mk 注册，见第 3 节）
├── interfaces/Android.bp                       # hidl_package_root: vendor.starnet -> interfaces/
├── interfaces/pdm/1.0/
│   ├── IPdm.hal                                # interface IPdm: setValue/getValue/getEntries
│   ├── types.hal                               # struct Entry; enum PdmStatus
│   └── Android.bp                              # hidl_interface "vendor.starnet.pdm@1.0"
├── service/
│   ├── main.cpp                                # configureRpcThreadpool + registerAsService + joinRpcThreadpool
│   ├── PdmHal.{h,cpp}                          # 业务实现(移植自 pdm/PdmService.cpp)
│   ├── UnifyKeys.h / Lock.{h,cpp}              # unifykeys 节点路径 / flock 串行化(与 pdm/ 一致)
│   ├── vendor.starnet.pdm@1.0-service.rc       # init: class hal, /vendor/bin/hw/...
│   └── Android.bp
├── cli/
│   ├── main.cpp                                # pdm.hidl.cli:set / get / list
│   └── Android.bp
├── sepolicy/
│   ├── pdm_hidl.te                             # HAL 域 + 业务权限 + shell 客户端权限
│   ├── file_contexts                           # /vendor/bin/hw/vendor.starnet.pdm@1.0-service
│   └── hwservice_contexts                      # vendor.starnet.pdm::IPdm -> pdm_hidl_hwservice
└── manifest/vendor.starnet.pdm@1.0.xml         # VINTF 清单片段(挂载方法见文件内注释)
```

产物:

| 模块 | 安装路径 | 说明 |
|---|---|---|
| `vendor.starnet.pdm@1.0` | `/vendor/lib{,64}/libvendor.starnet.pdm@1.0.so`(+ system 侧同名库) | hidl-gen 生成的接口/收发桩 |
| `vendor.starnet.pdm@1.0-service` | `/vendor/bin/hw/vendor.starnet.pdm@1.0-service` | HAL 服务(init 以 `class hal` 拉起,root) |
| `pdm.hidl.cli` | `/system/bin/pdm.hidl.cli` | 命令行工具(与旧 `pdm.cli` 用法一致) |

## 2. 接口

```hal
package vendor.starnet.pdm@1.0;

interface IPdm {
    setValue(string name, string value) generates (PdmStatus status, bool result);
    getValue(string name)               generates (PdmStatus status, string value);
    getEntries()                        generates (PdmStatus status, vec<Entry> entries);
};
```

`PdmStatus`(types.hal)对应旧实现的 `status_t`——HIDL 的 `Return<T>` 只表达传输层错误,
业务错误必须在回调里显式回传:

| PdmStatus | 旧 status_t | 触发条件 |
|---|---|---|
| `OK` | `NO_ERROR` | 成功 |
| `NAME_NOT_FOUND` | -2 | `name` 为空或不在 `kKeyPropMap` 中 |
| `BAD_VALUE` | -22 | `work_mode` 取值不是 `"0"`/`"1"` |
| `PERMISSION_DENIED` | -1 | 拿不到 `/sys/class/unifykeys/lock` |
| `UNKNOWN_ERROR` | -5 | unifykeys 节点读写失败等 |

服务能力与旧实现逐项一致:属性映射表与 fallback 链(unifykeys → property → 默认值)、
`work_mode` 只看 `/mnt/vendor/param/usermode` 标志文件、写属性前临时打开白名单门
`persist.ro.white_list.enable`(`RoWhiteListGate`)、每个操作期间对 unifykeys 加 `flock`、
服务构造时做一次开机属性同步。

## 3. 构建集成（让编译产物带上本服务）

声明分两处，各管一件事（都**实测验证过**，见第 3.1 节）：

**(1) 模块进镜像** —— 本目录 [pdm-hidl.mk](pdm-hidl.mk) 里 `PRODUCT_PACKAGES +=`，
由 [vendor/starnet/starnet.mk](../starnet.mk) 里旧 pdm 声明之后多了 1 行引入：

```make
include $(LOCAL_PATH)/pdm-hidl/pdm-hidl.mk
```

（`starnet.mk` 在 `p291_iptv.mk` → `device.mk` → `core_amlogic.mk` 链上，属于 product-config
阶段，`PRODUCT_PACKAGES` 在这里声明才会被镜像打包阶段看见——旧 `pdm-service`/`pdm.cli` 同理。）

**(2) SELinux 策略进镜像** —— `device/amlogic/common/sepolicy.mk` 里加了：

```make
BOARD_SEPOLICY_DIRS += \
    vendor/starnet/pdm-hidl/sepolicy
```

> ⚠️ **这两处都不能想当然换地方（都是实测踩出来的）**：
> - 写成 `vendor/starnet/pdm-hidl/Android.mk` 让它被自动包含 → kati 主阶段才扫到该文件，
>   那时 `PRODUCT_PACKAGES` 已 `.KATI_READONLY`，直接报
>   `cannot assign to readonly variable: PRODUCT_PACKAGES`，构建失败。
> - `BOARD_SEPOLICY_DIRS` 追加在 product-config 阶段（`vendor/starnet/starnet.mk`）**不生效**：
>   实测编译出的 `vendor/etc/selinux/vendor_sepolicy.cil` 里只有 `device/amlogic/common/sepolicy.mk`
>   里 board-config 阶段加入的目录（`tvserver`/`system_control` 在），而仓库里旧的
>   `vendor/starnet/pdm/sepolicy`（同样写在 starnet.mk）与我们的新目录**都不在**。
>   只能在 board-config 阶段声明，故放到 `device/amlogic/common/sepolicy.mk`（三个 amlogic
>   产品共用，`p291_iptv/BoardConfig.mk:325` 会 include 它）。
> - 本目录下也不要有 `Android.bp`（Soong 会忽略同目录 Android.mk）；Soong 模块都在
>   `interfaces/`、`service/`、`cli/` 子目录。

其余一切自动完成：

| 需求 | 由谁完成 | 实测落点 |
|---|---|---|
| HAL 服务进镜像 | `PRODUCT_PACKAGES` | `vendor/bin/hw/vendor.starnet.pdm@1.0-service` ✓ |
| CLI 进镜像 | `PRODUCT_PACKAGES` | `system/bin/pdm.hidl.cli` ✓ |
| HIDL 接口库 | 服务/CLI 的 `shared_libs` 依赖，Soong 自动带两侧 | `vendor/lib/libvendor.starnet.pdm@1.0.so`、`system/lib/...` ✓ |
| init 开机拉起 | `service/Android.bp` 的 `init_rc` | `vendor/etc/init/vendor.starnet.pdm@1.0-service.rc` ✓ |
| 服务域/标签/权限 | `BOARD_SEPOLICY_DIRS` 里的 sepolicy 目录 | `vendor_sepolicy.cil`(48 处)、`vendor_file_contexts`、`vendor_hwservice_contexts` ✓ |
| 升级包/线刷包内包含 | 无需改：文件分别落在 system.img / vendor.img | 脚本按分区整包打包 |

### 3.1 已验证（2026-09-10，p291_iptv userdebug）

```
m vendor.starnet.pdm@1.0-service pdm.hidl.cli   → BUILD_EXIT=0，产物全部落到 out/target/product/p291_iptv/
m selinux_policy                                 → POLICY_EXIT=0，neverallow 全量检查通过
```

VINTF 清单片段是可选项（见第 6 节），不并入手册也能正常注册与调用。

## 4. 编译

```bash
source build/envsetup.sh
lunch p291_iptv-userdebug
m vendor.starnet.pdm@1.0-service pdm.hidl.cli     # 也可直接 m otapackage 整包
# 单独验证 SELinux 策略(会做 neverallow 全量检查):
m selinux_policy
```

## 5. 使用

```bash
# 查看服务是否注册(应能看到 vendor.starnet.pdm@1.0::IPdm/default)
lshal | grep pdm

adb shell pdm.hidl.cli get model
adb shell pdm.hidl.cli set model TB712          # 同时写 unifykey + 同步 ro.product.model
adb shell pdm.hidl.cli list
adb shell pdm.hidl.cli set work_mode 1          # 用户模式(创建 /mnt/vendor/param/usermode)
adb shell pdm.hidl.cli set work_mode 0          # 工厂模式(删除该文件)
```

C++ 进程内调用(链接 `vendor.starnet.pdm@1.0` 即可,接口库两侧都有):

```cpp
#include <vendor/starnet/pdm/1.0/IPdm.h>
using namespace ::vendor::starnet::pdm::V1_0;

android::sp<IPdm> pdm = IPdm::getService();          // 取 .../default
if (pdm == nullptr) { /* 服务未起来 */ }
PdmStatus st; std::string model;
pdm->getValue("model", [&](PdmStatus s, const ::android::hardware::hidl_string& v) {
    st = s; model.assign(v.c_str(), v.size());
});
```

## 6. SELinux / VINTF

- 服务域:`u:r:pdm_hidl_default:s0`(标准 Treble HAL 域,`hal_server_domain(pdm_hidl_default, hal_pdm_hidl)`)。
- hwservice 标签:`vendor.starnet.pdm::IPdm → u:object_r:pdm_hidl_hwservice:s0`。
- 客户端 `pdm.hidl.cli` 以 `shell` 域运行,已放行:找 hwservice + 调用 HAL 进程。
- **`.rc` 里不能写 `seclabel`**:HAL 域受 `neverallow * halserverdomain:process dyntransition` 约束,
  域转换靠 `file_contexts` + `init_daemon_domain` 在 exec 时完成。
- **不能照抄旧 `pdm_service.te` 的 `allow ... vendor_file:file execute_no_trans`**:
  `neverallow { halserverdomain ... } { file_type fs_type }:file execute_no_trans`。
- VINTF 清单片段见 [manifest/vendor.starnet.pdm@1.0.xml](manifest/vendor.starnet.pdm@1.0.xml)，
  已并入 device manifest：`device/amlogic/p291_iptv/BoardConfig.mk` 的 `DEVICE_MANIFEST_FILE` 段末
  加了一行

  ```make
  DEVICE_MANIFEST_FILE += vendor/starnet/pdm-hidl/manifest/vendor.starnet.pdm@1.0.xml
  ```

  （`DEVICE_MANIFEST_FILE` 支持多文件，由 `assemble_vintf` 与板级 manifest 合并成
  `/vendor/etc/vintf/manifest.xml`。该行必须放在 `AUTO_PATCH_AB`/`AUTO_PATCH_NPU` 两个
  `$(shell ...)` 之后——它们会 `sed -i` 就地修改 `$(DEVICE_MANIFEST_FILE)` 里的每个文件。
  本产品未开 `PRODUCT_ENFORCE_VINTF_MANIFEST`，删掉这行也不影响服务注册与调用。）

## 7. 与旧 `vendor/starnet/pdm` 的差异(需要注意的点)

| | 旧 pdm | pdm-hidl |
|---|---|---|
| IPC | 私有 binder(`/dev/binder`,servicemanager) | HIDL(`/dev/hwbinder`,hwservicemanager) |
| 服务名 | `vendor.starnet.pdm` | `vendor.starnet.pdm@1.0::IPdm/default` |
| 收发协议 | 手写 `BnPdm::onTransact`/`BpPdm`,还要手工 probe interface token 偏移 | hidl-gen 生成,无需关心 |
| 调用方 | `servicemanager` + `interface_cast<IPdm>` | `IPdm::getService()`(**不能**用 `servicemanager` 查) |
| 服务进程 | `/vendor/bin/pdm-service`(domain `pdm_service`) | `/vendor/bin/hw/vendor.starnet.pdm@1.0-service`(domain `pdm_hidl_default`) |

- **App 不能直接调用本 HAL**:Treble 的 `app_neverallows.te` 对 `all_untrusted_apps` 调用
  `halserverdomain` 有 neverallow,普通 App(以及 Java 侧)拿不到 `find`/`call` 权限。
  需要 App 访问的通道时,保留旧 binder 服务,或另外加一个 system service/manager 转发;
  如确实要让 `system_app`/`platform_app` 走 HIDL,需在 `pdm_hidl.te` 里按类型补
  `hwservice_manager find` 与 binder `call` 权限(注意该类 App 是否属于 neverallow 范围)。
- 两个服务同时开机时都会各做一次属性同步(写的是同样的值,unifykeys 侧有 flock 串行化),
  不会互相破坏;如果只想要一个同步来源,停掉其中一个即可。

## 8. 上板验证与排查

```bash
adb shell getenforce                     # 建议先确认是否 Enforcing
adb shell lshal | grep vendor.starnet    # 应列出 vendor.starnet.pdm@1.0::IPdm/default
adb shell pdm.hidl.cli list
adb shell getprop ro.mac                 # 验证属性同步是否生效
logcat -s pdm-hidl pdm-hidl-cli hwservicemanager
```

- `pdm.hidl.cli` 报 `service ... not found` → 服务没起来或 SELinux 拦截:
  `logcat -s hwservicemanager init pdm-hidl` 看 `add` 是否被拒;
  确认 `/vendor/bin/hw/vendor.starnet.pdm@1.0-service`(init.rc 中服务名 `vendor.pdm-hidl-1-0`)。
- 出现 `avc: denied` → 按 denial 补充 `sepolicy/pdm_hidl.te`(`dmesg | grep avc`)。
- `setprop` 失败/属性没变 → 确认 `/vendor/starnet/whitelist_prop.txt` 含该属性、
  `/vendor/starnet/sepolicy/property_contexts` 里 `persist.ro.white_list.enable` 映射存在
  (旧 pdm 依赖同一套机制)。

## 9. 若要完全替换旧 pdm

1. `vendor/starnet/starnet.mk` 中注释掉 `PRODUCT_PACKAGES += pdm-service pdm.cli`;
2. 删除/停用 `vendor/starnet/pdm/pdm-service.rc`(整目录可保留做参考);
3. 若上层 App 仍在用 `vendor.starnet.pdm` 私有协议,需要先把调用方迁到 HIDL(见第 7 节限制)。
