// Copyright (C) 2026-2026 福建星网锐捷通讯股份有限公司. All rights reserved.
//
// pdm.hidl.cli:旧 pdm.cli 的 HIDL 版本,命令行/输出格式保持一致:
//   pdm.hidl.cli set <name> <value>
//   pdm.hidl.cli get <name>
//   pdm.hidl.cli list
// 客户端侧不再手写 Parcel:IPdm::getService() 从 hwservicemanager 拿服务,
// 收发由 hidl-gen 生成的 BpHwIPdm 负责。

#include <vendor/starnet/pdm/1.0/IPdm.h>

#include <log/log.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <string>
#include <vector>

using ::vendor::starnet::pdm::V1_0::Entry;
using ::vendor::starnet::pdm::V1_0::IPdm;
using ::vendor::starnet::pdm::V1_0::PdmStatus;

static void printUsage(const char* prog) {
    printf("Usage:\n"
           "  %s set <name> <value>   - 设置键值对(烧写 unifykey)\n"
           "  %s get <name>           - 获取指定键的值\n"
           "  %s list                 - 获取所有条目\n",
           prog, prog, prog);
}

static const char* statusName(PdmStatus status) {
    switch (status) {
        case PdmStatus::OK:
            return "OK";
        case PdmStatus::NAME_NOT_FOUND:
            return "NAME_NOT_FOUND";
        case PdmStatus::BAD_VALUE:
            return "BAD_VALUE";
        case PdmStatus::PERMISSION_DENIED:
            return "PERMISSION_DENIED";
        case PdmStatus::UNKNOWN_ERROR:
            return "UNKNOWN_ERROR";
    }
    return "UNRECOGNIZED";
}

// 去掉尾部换行后打印,避免 sysfs 值自带 '\n' 时输出多空行
static std::string stripTail(const std::string& s) {
    size_t end = s.size();
    while (end > 0 && (s[end - 1] == '\n' || s[end - 1] == '\r')) end--;
    return s.substr(0, end);
}

int main(int argc, char* argv[]) {
    ALOGI("pdm.hidl.cli: main() argc=%d, pid=%d uid=%d", argc, getpid(), getuid());
    for (int i = 0; i < argc; i++) {
        ALOGD("pdm.hidl.cli: argv[%d]='%s'", i, argv[i]);
    }

    if (argc < 2) {
        ALOGW("pdm.hidl.cli: no command provided");
        printUsage(argv[0]);
        return 1;
    }

    // 绑定式 HAL:从 hwservicemanager 取 vendor.starnet.pdm@1.0::IPdm/default
    // (内部会短暂重试等待服务就绪)
    ::android::sp<IPdm> pdm = IPdm::getService();
    if (pdm == nullptr) {
        fprintf(stderr,
                "Error: service 'vendor.starnet.pdm@1.0::IPdm/default' not found"
                " (pdm-hidl 服务未运行或 SELinux 拦截?)\n");
        ALOGE("pdm.hidl.cli: IPdm::getService() returned NULL");
        return 1;
    }

    std::string command = argv[1];
    ALOGI("pdm.hidl.cli: executing command='%s'", command.c_str());

    if (command == "set" && argc == 4) {
        ALOGI("pdm.hidl.cli: setValue name='%s' value='%s'", argv[2], argv[3]);
        PdmStatus status = PdmStatus::UNKNOWN_ERROR;
        bool result = false;
        auto ret = pdm->setValue(argv[2], argv[3],
                                 [&](PdmStatus st, bool r) { status = st; result = r; });
        if (!ret.isOk()) {
            fprintf(stderr, "Error: setValue transact failed: %s\n", ret.description().c_str());
            ALOGE("pdm.hidl.cli: setValue transact failed: %s", ret.description().c_str());
            return 1;
        }
        if (status != PdmStatus::OK || !result) {
            fprintf(stderr, "Error: setValue(%s) failed, status=%s(%d)\n",
                    argv[2], statusName(status), (int)status);
            ALOGE("pdm.hidl.cli: setValue failed status=%d", (int)status);
            return 1;
        }
        printf("Success: set %s=%s\n", argv[2], argv[3]);
        ALOGI("pdm.hidl.cli: set %s=%s SUCCESS", argv[2], argv[3]);
    } else if (command == "get" && argc == 3) {
        ALOGI("pdm.hidl.cli: getValue name='%s'", argv[2]);
        PdmStatus status = PdmStatus::UNKNOWN_ERROR;
        std::string value;
        auto ret = pdm->getValue(argv[2], [&](PdmStatus st, const ::android::hardware::hidl_string& v) {
            status = st;
            value.assign(v.c_str(), v.size());
        });
        if (!ret.isOk()) {
            fprintf(stderr, "Error: getValue transact failed: %s\n", ret.description().c_str());
            ALOGE("pdm.hidl.cli: getValue transact failed: %s", ret.description().c_str());
            return 1;
        }
        if (status != PdmStatus::OK) {
            fprintf(stderr, "Error: getValue(%s) failed, status=%s(%d)\n",
                    argv[2], statusName(status), (int)status);
            ALOGE("pdm.hidl.cli: getValue failed status=%d", (int)status);
            return 1;
        }
        printf("%s=%s\n", argv[2], stripTail(value).c_str());
        ALOGI("pdm.hidl.cli: get %s='%s'", argv[2], stripTail(value).c_str());
    } else if (command == "list" && argc == 2) {
        ALOGI("pdm.hidl.cli: getEntries()");
        PdmStatus status = PdmStatus::UNKNOWN_ERROR;
        std::vector<Entry> entries;
        auto ret = pdm->getEntries(
                [&](PdmStatus st, const ::android::hardware::hidl_vec<Entry>& list) {
                    status = st;
                    entries.assign(list.begin(), list.end());
                });
        if (!ret.isOk()) {
            fprintf(stderr, "Error: getEntries transact failed: %s\n", ret.description().c_str());
            ALOGE("pdm.hidl.cli: getEntries transact failed: %s", ret.description().c_str());
            return 1;
        }
        if (status != PdmStatus::OK) {
            fprintf(stderr, "Error: getEntries failed, status=%s(%d)\n",
                    statusName(status), (int)status);
            ALOGE("pdm.hidl.cli: getEntries failed status=%d", (int)status);
            return 1;
        }
        for (const auto& e : entries) {
            printf("%s=%s\n", std::string(e.name.c_str(), e.name.size()).c_str(),
                   stripTail(std::string(e.value.c_str(), e.value.size())).c_str());
        }
        ALOGI("pdm.hidl.cli: listed %zu entries", entries.size());
    } else {
        ALOGW("pdm.hidl.cli: unknown/invalid command='%s' argc=%d", command.c_str(), argc);
        printUsage(argv[0]);
        return 1;
    }

    ALOGI("pdm.hidl.cli: main() done, exit 0");
    return 0;
}
