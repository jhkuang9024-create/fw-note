# pdm-hidl 的构建声明:让编译产物(镜像)带上 HAL 服务与 CLI。
# 由 vendor/starnet/starnet.mk 在 product-config 阶段 include 一行引入。
#
# ⚠️ 不要改回 vendor/starnet/pdm-hidl/Android.mk 的自动包含写法:
#    Android.mk 只会在 kati 主阶段被扫到(subdir_makefiles 那一步),
#    那时 PRODUCT_PACKAGES 已被置为只读,实测报错:
#      vendor/starnet/pdm-hidl/Android.mk: cannot assign to readonly variable: PRODUCT_PACKAGES

PRODUCT_PACKAGES += \
    vendor.starnet.pdm@1.0-service \
    pdm.cli

# SELinux 策略目录不在这里声明:BOARD_SEPOLICY_DIRS 只认 board-config 阶段
# (device/amlogic/common/sepolicy.mk)里的追加——实测本文件所在的 product-config
# 阶段追加不会进策略(见该文件里的注释)。此处若再写一遍,一旦上游修好时序反而
# 会重复包含同一目录导致策略编译报重复定义。
