#pragma once

#include <vendor/starnet/pdm/1.0/IPdm.h>

#include <memory>
#include <string>
#include <vector>

namespace vendor {
namespace starnet {
namespace pdm {
namespace V1_0 {
namespace implementation {

// 绑定式(binderized) HIDL 实现:与 vendor/starnet/pdm 里 PdmService 的功能等价。
// 业务逻辑(unifykeys 读写 / 属性同步 / work_mode 标志文件 / flock 串行化)逐段移植,
// 差异只在 IPC 层:收发 Parcel 由 hidl-gen 生成的 IPdm 桩负责,不再手写
// BnPdm::onTransact / BpPdm(旧实现要手工 probe interface token 偏移)。
class PdmHal : public IPdm {
  public:
    PdmHal();  // 构造时按 unifykeys 做一次开机属性同步(等价 PdmService 构造函数)
    ~PdmHal() = default;

    // Methods from ::vendor::starnet::pdm::V1_0::IPdm follow.
    ::android::hardware::Return<void> setValue(
            const ::android::hardware::hidl_string& name,
            const ::android::hardware::hidl_string& value, setValue_cb _hidl_cb) override;
    ::android::hardware::Return<void> getValue(
            const ::android::hardware::hidl_string& name, getValue_cb _hidl_cb) override;
    ::android::hardware::Return<void> getEntries(getEntries_cb _hidl_cb) override;

  private:
    // 读取全部已知 key(name->value 逐项填充)
    bool readAllEntries(std::vector<Entry>* entries);
    // key -> 系统属性(对应旧 UNIFY_KEY_MAP)
    void syncKeyToProperty(const std::string& name, const std::string& value);
    // 三个接口的业务实现(返回 PdmStatus,由上面三个 HIDL 方法转成回调回传)
    PdmStatus setValueInternal(const std::string& name, const std::string& value, bool* result);
    PdmStatus getValueInternal(const std::string& name, std::string* value);
};

}  // namespace implementation
}  // namespace V1_0
}  // namespace pdm
}  // namespace starnet
}  // namespace vendor
