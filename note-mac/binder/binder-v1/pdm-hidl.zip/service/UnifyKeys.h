#pragma once

// Amlogic unifykeys(kernel: /sys/class/unifykeys)节点。
// 与 vendor/starnet/pdm/UnifyKeys.h 保持一致(设备节点路径固定)。
constexpr const char* kUnifyKeyName  = "/sys/class/unifykeys/name";
constexpr const char* kUnifyKeyWrite = "/sys/class/unifykeys/write";
constexpr const char* kUnifyKeyRead  = "/sys/class/unifykeys/read";
constexpr const char* kUnifyKeyLock  = "/sys/class/unifykeys/lock";
