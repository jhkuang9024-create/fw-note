#include <vendor/starnet/pdm/1.0/IPdm.h>

#include <hidl/HidlTransportSupport.h>
#include <log/log.h>
#include <unistd.h>
#include <utils/Errors.h>  // android::OK / status_t

#include "PdmHal.h"

using ::android::hardware::configureRpcThreadpool;
using ::android::hardware::joinRpcThreadpool;
using ::vendor::starnet::pdm::V1_0::IPdm;
using ::vendor::starnet::pdm::V1_0::implementation::PdmHal;

int main() {
    ALOGI("pdm-hidl: main() pid=%d uid=%d, service starting...", getpid(), getuid());

    // 绑定式 HIDL 服务:注册到 hwservicemanager(走 /dev/hwbinder),
    // 不再是旧实现的 servicemanager(走 /dev/binder)
    configureRpcThreadpool(4, true);

    ::android::sp<IPdm> service = new PdmHal();  // 构造时同步一次属性

    ::android::status_t err = service->registerAsService();
    if (err != ::android::OK) {
        ALOGE("pdm-hidl: main() registerAsService('default') failed, err=%d", err);
        return 1;
    }
    ALOGI("pdm-hidl: service 'vendor.starnet.pdm@1.0::IPdm/default' registered successfully");

    joinRpcThreadpool();
    ALOGE("pdm-hidl: main() unexpectedly returned from joinRpcThreadpool()");
    return 0;
}
