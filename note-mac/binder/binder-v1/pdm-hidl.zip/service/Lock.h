#pragma once

#include <memory>

namespace vendor {
namespace starnet {
namespace pdm {
namespace V1_0 {
namespace implementation {

// 用户态互斥:对 /sys/class/unifykeys/lock 节点 fd 做 flock,
// 仅用于多客户端并发串行化,不会真正写 lock 节点(不锁存储)。
// 逻辑与 vendor/starnet/pdm/Lock.{h,cpp} 一致,仅命名空间/日志前缀不同。
class Lock {
  public:
    static std::unique_ptr<Lock> create();
    ~Lock();

  private:
    Lock();

    int fd = -1;
    bool locked = false;
};

}  // namespace implementation
}  // namespace V1_0
}  // namespace pdm
}  // namespace starnet
}  // namespace vendor
