#include "Lock.h"

#include <errno.h>
#include <fcntl.h>
#include <log/log.h>
#include <string.h>
#include <unistd.h>

#include <memory>

#include "UnifyKeys.h"

namespace vendor {
namespace starnet {
namespace pdm {
namespace V1_0 {
namespace implementation {

std::unique_ptr<Lock> Lock::create() {
    ALOGD("pdm-hidl: Lock::create() enter, lock_path=%s", kUnifyKeyLock);
    auto lock = std::unique_ptr<Lock>(new Lock());

    lock->fd = open(kUnifyKeyLock, O_WRONLY);
    if (lock->fd < 0) {
        ALOGE("pdm-hidl: Lock::create open %s failed: %s", kUnifyKeyLock, strerror(errno));
        return nullptr;
    }

    struct flock flock;
    flock.l_whence = SEEK_SET;
    flock.l_start = 0;
    flock.l_len = 0;
    flock.l_type = F_WRLCK;
    flock.l_pid = -1;

    if (fcntl(lock->fd, F_SETLKW, &flock) < 0) {
        ALOGE("pdm-hidl: Lock::create fcntl(F_SETLKW) failed on %s: %s",
              kUnifyKeyLock, strerror(errno));
        close(lock->fd);
        lock->fd = -1;
        return nullptr;
    }

    lock->locked = true;
    ALOGD("pdm-hidl: Lock::create() success, lock acquired on %s (fd=%d)",
          kUnifyKeyLock, lock->fd);
    return lock;
}

Lock::Lock() {
    ALOGD("pdm-hidl: Lock() constructor, fd=%d locked=%d", fd, locked ? 1 : 0);
}

Lock::~Lock() {
    ALOGD("pdm-hidl: ~Lock() destructor enter, fd=%d locked=%d", fd, locked ? 1 : 0);
    if (fd < 0) {
        return;
    }

    if (locked) {
        struct flock flock;
        flock.l_whence = SEEK_SET;
        flock.l_start = 0;
        flock.l_len = 0;
        flock.l_type = F_UNLCK;
        flock.l_pid = -1;

        int ret = fcntl(fd, F_SETLK, &flock);
        if (ret < 0) {
            ALOGE("pdm-hidl: ~Lock() fcntl(F_SETLK, F_UNLCK) failed: %s", strerror(errno));
        }
        locked = false;
    }

    close(fd);
    fd = -1;
}

}  // namespace implementation
}  // namespace V1_0
}  // namespace pdm
}  // namespace starnet
}  // namespace vendor
