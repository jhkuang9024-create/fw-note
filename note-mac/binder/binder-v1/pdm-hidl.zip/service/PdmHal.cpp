// (unifykeys 读写、属性映射表与 fallback 链、work_mode 标志文件、白名单门、flock),
// 只把"返回值 + 出参"换成 PdmStatus + HIDL 回调。

#include "PdmHal.h"

#include <cutils/properties.h>
#include <errno.h>
#include <fcntl.h>
#include <log/log.h>
#include <string.h>
#include <unistd.h>

#include <string>
#include <vector>

#include "Lock.h"
#include "UnifyKeys.h"

namespace vendor {
namespace starnet {
namespace pdm {
namespace V1_0 {
namespace implementation {

using ::android::hardware::hidl_string;
using ::android::hardware::hidl_vec;
using ::android::hardware::Return;
using ::android::hardware::Void;

// 每个 unifykey 对应的系统属性及默认值(原 UNIFY_KEY_MAP,按你的产品裁剪)
// ⚠️ struct 必须显式命名(避免 decltype 推导出 pointer-to-reference 非法类型)
struct KeyPropItem {
    const char* key;
    const char* prop;
    const char* def;
};
static const KeyPropItem kKeyPropMap[] = {
        // 键名以板级 DTS(keyman_gxlx.dtsi 的 unifykey 节点)为准;
        // ro.product.cmcc_* 默认值由 vendor_prop_sdmobile.mk 烘焙;property
        // service 依据 /vendor/starnet/whitelist_prop.txt 放行这几个 ro.* 的
        // 运行期改写:本服务 set/开机同步因此可成功,串口/adb setprop 亦即时
        // 生效;重启后先装载 mk 默认,再由本服务按 unifykey 值覆盖。
        // persist.sys.cmcc_* 行为 rc 复制段及上层 SDK 提供同值通道
        {"device_id", "ro.product.cmcc_deviceId", ""}, // 设备ID
        {"device_id", "ro.product.cmcc_id", ""}, // 设备ID
        // 移动SDK 鉴权凭证(和家亲 andlink):默认值与
        // device/amlogic/p291_iptv/vendor_prop_sdmobile.mk 保持一致;
        {"product_token", "ro.product.cmcc_productToken", ""},
        {"product_token", "ro.product.cmcc_token", ""},
        {"andlink_token", "ro.product.cmcc_andlinkToken", ""},
        {"andlink_token", "ro.product.cmcc_andlinktoken", ""},

        {"mac", "ro.mac", ""},
        {"mac_wifi", "ro.product.mac_wifi", ""},

        {"stbid", "ro.serialno", ""},
        {"stbid", "ro.product.stbid", ""},
        {"sn", "ro.product.cmcc_sn", ""},
        {"sn", "ro.product.serialno", ""},
        {"sn", "ro.boot.sn", ""},
        {"cmccpwd", "ro.product.cmcc_password", ""},
        {"cmei", "ro.product.cmcc_cmei", ""},
        {"work_mode", "ro.device.work.mode", ""},
        {"cmcc_date", "ro.product.cmcc_date", ""},
        // 整机产品属性(品牌/型号/平台),默认值按产品配置;
        // 需与白名单(whitelist_prop.txt)配套才能运行时改写已装载的 ro.* 属性
        {"manufacturer", "ro.product.manufacturer", ""},
        {"brand", "ro.product.brand", ""},
        {"brand", "ro.product.cmcc_brand", ""},
        {"model", "ro.product.model", ""},
        {"device", "ro.product.device", ""},
        {"cmcc_ims_app_id", "ro.product.cmcc_imsAppId", ""},
        {"cmcc_ims_secret", "ro.product.cmcc_imsSecret", ""},
};

// 内部辅助: name -> kKeyPropMap 第一项(或 nullptr). 用于默认值 fallback / 非法 name 校验.
static const KeyPropItem* findMapItem(const std::string& name) {
    for (const auto& item : kKeyPropMap) {
        if (name == item.key) return &item;
    }
    return NULL;
}

// 内部辅助: 读 property; 读到且非空返回 true, 否则 false.
static bool getPropertyString(const char* prop, std::string* out) {
    char buf[PROPERTY_VALUE_MAX];
    int len = property_get(prop, buf, "");
    if (len > 0 && buf[0] != '\0') {
        *out = std::string(buf, (size_t)len);
        return true;
    }
    return false;
}

// 读/写 sysfs 节点(原 android::base::WriteStringToFile/ReadFileToString)
static bool writeFile(const char* path, const std::string& data) {
    ALOGD("pdm-hidl: writeFile(path=%s, data_len=%zu)", path, data.size());
    int fd = open(path, O_WRONLY);
    if (fd < 0) {
        ALOGE("pdm-hidl: writeFile open %s failed: %s", path, strerror(errno));
        return false;
    }
    size_t off = 0;
    while (off < data.size()) {
        ssize_t n = write(fd, data.data() + off, data.size() - off);
        if (n <= 0) {
            ALOGE("pdm-hidl: writeFile write %s failed at off=%zu: %s",
                  path, off, strerror(errno));
            close(fd);
            return false;
        }
        off += n;
    }
    close(fd);
    ALOGD("pdm-hidl: writeFile(%s) success, wrote %zu bytes", path, off);
    return true;
}

static bool readFile(const char* path, std::string* out) {
    ALOGD("pdm-hidl: readFile(path=%s)", path);
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        ALOGE("pdm-hidl: readFile open %s failed: %s", path, strerror(errno));
        return false;
    }
    char buf[1024];
    ssize_t n;
    out->clear();
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        out->append(buf, n);
    }
    close(fd);
    if (n != 0) {
        ALOGE("pdm-hidl: readFile read %s failed: %s (last n=%zd)",
              path, strerror(errno), n);
        return false;
    }
    ALOGD("pdm-hidl: readFile(%s) success, read %zu bytes", path, out->size());
    return true;
}

// 属性值不宜带 sysfs 尾部换行
static std::string trimTail(const std::string& s) {
    size_t end = s.size();
    while (end > 0 && (s[end - 1] == '\n' || s[end - 1] == '\r')) end--;
    return s.substr(0, end);
}

static constexpr const char* kUserModeFile = "/mnt/vendor/param/usermode";
static constexpr const char* kModeKey = "work_mode";
static constexpr const char* kModeUser = "1";    // 用户模式
static constexpr const char* kModeFactory = "0"; // 工厂模式

// 是否用户模式(标志文件存在性)
static bool isUserMode() {
    if (access(kUserModeFile, F_OK) == 0) return true;
    if (errno != ENOENT) {
        ALOGW("pdm-hidl: isUserMode: access(%s) failed: %s", kUserModeFile, strerror(errno));
    }
    return false;
}

// work_mode 取值校验: 只接受 "0"/"1"。非法值若放行,会改掉 unifykey/属性而文件不动,
// 造成"命令成功但模式没变"的假成功。
static bool isValidModeValue(const std::string& v) {
    return v == kModeUser || v == kModeFactory;
}

// 落盘模式标志文件: "1" -> 写入 "1"(用户模式); "0" -> 删除文件(工厂模式)。
// 与串口 echo 1 > /mnt/vendor/param/usermode 等效;文件内容不参与判定,仅存续性有意义。
static bool applyUserModeFile(const std::string& value) {
    if (value == kModeUser) {
        int fd = open(kUserModeFile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) {
            ALOGE("pdm-hidl: applyUserModeFile: open %s failed: %s",
                  kUserModeFile, strerror(errno));
            return false;
        }
        const char* data = "1\n";
        ssize_t n = write(fd, data, strlen(data));
        int saved_errno = errno;
        close(fd);
        if (n != (ssize_t)strlen(data)) {
            ALOGE("pdm-hidl: applyUserModeFile: write %s failed (n=%zd): %s",
                  kUserModeFile, n, strerror(saved_errno));
            return false;
        }
        ALOGI("pdm-hidl: applyUserModeFile: user work_mode ON, created %s", kUserModeFile);
        return true;
    }
    // 工厂模式: 删除标志文件(本就不存在视为已达成)
    if (unlink(kUserModeFile) != 0 && errno != ENOENT) {
        ALOGE("pdm-hidl: applyUserModeFile: unlink %s failed: %s",
              kUserModeFile, strerror(errno));
        return false;
    }
    ALOGI("pdm-hidl: applyUserModeFile: user work_mode OFF, removed %s", kUserModeFile);
    return true;
}

// init property service 的 IsWhitelistedRoProperty()(system/core/init/
// property_service.cpp)只在该属性 == "1" 时放行 whitelist_prop.txt 白名单内的
// ro.* 属性运行期改写。syncKeyToProperty 期间临时打开这个门,对象析构时(无论
// 成功失败、含提前 return)关回 "0",保证白名单 ro.* 平时只能经 pdm 通道
// (pdm.hidl.cli -> pdm-hidl 服务 -> 本函数)修改。
// 该属性已在 vendor/starnet/sepolicy/property_contexts 映射 vendor_persist_prop
// (pdm_hidl.te 已 allow set);property_set 经 property service socket 由 init
// 串行处理,先置 1 后写 ro.* 的顺序有保证。
class RoWhiteListGate {
  public:
    RoWhiteListGate() {
        int rc = property_set(kRoWhiteListEnableProp, "1");
        if (rc != 0) {
            ALOGW("pdm-hidl: RoWhiteListGate: enable %s failed rc=%d",
                  kRoWhiteListEnableProp, rc);
        }
    }
    ~RoWhiteListGate() {
        int rc = property_set(kRoWhiteListEnableProp, "0");
        if (rc != 0) {
            ALOGW("pdm-hidl: RoWhiteListGate: disable %s failed rc=%d",
                  kRoWhiteListEnableProp, rc);
        }
    }

  private:
    static constexpr const char* kRoWhiteListEnableProp = "persist.ro.white_list.enable";
};

PdmHal::PdmHal() {
    ALOGI("pdm-hidl: PdmHal() constructor start, begin boot-time sync from unifykeys");
    std::vector<Entry> entries;
    if (!readAllEntries(&entries)) {
        ALOGE("pdm-hidl: PdmHal() init sync failed, entries will be left untouched");
        return;
    }
    ALOGI("pdm-hidl: PdmHal() read %zu entries, now syncing to properties", entries.size());
    for (const auto& e : entries) {
        syncKeyToProperty(std::string(e.name.c_str(), e.name.size()),
                          std::string(e.value.c_str(), e.value.size()));
    }
    ALOGI("pdm-hidl: PdmHal() constructor done, boot sync complete");
}

bool PdmHal::readAllEntries(std::vector<Entry>* entries) {
    static const char* kKeys[] = {"mac",   "mac_wifi", "sn",      "stbid",       "cmccpwd",
                                  "cmei",  "device_id", "work_mode",   "cmcc_date",   "product_token",
                                  "andlink_token",
                                  "manufacturer", "brand", "model", "device",
                                  "cmcc_ims_app_id", "cmcc_ims_secret"};
    const int kKeyCount = sizeof(kKeys) / sizeof(kKeys[0]);
    ALOGD("pdm-hidl: readAllEntries() start, total keys=%d", kKeyCount);
    // 整个循环持一把锁,与多客户端并发互斥
    std::unique_ptr<Lock> lock = Lock::create();
    if (!lock) {
        ALOGE("pdm-hidl: readAllEntries: failed to lock %s", kUnifyKeyLock);
        return false;
    }
    entries->clear();
    int fallbackProp = 0, fallbackDef = 0;
    for (const char* key : kKeys) {
        bool ok = true;
        if (!writeFile(kUnifyKeyName, key)) {
            ALOGW("pdm-hidl: readAllEntries: write name '%s' to %s failed, skip unifykey",
                  key, kUnifyKeyName);
            ok = false;
        }
        std::string value;
        if (ok && !readFile(kUnifyKeyRead, &value)) {
            ALOGW("pdm-hidl: readAllEntries: read value of '%s' from %s failed, skip unifykey",
                  key, kUnifyKeyRead);
            ok = false;
        }
        std::string trimmed = trimTail(value);
        // 与 getValue 保持相同 fallback 链: unifykeys 空 → property → default.
        // 避免 list 时所有值全空而 get model 却能取到 TB712 的不一致症状(0905实测)
        if (!ok || trimmed.empty()) {
            const auto* item = findMapItem(key);
            if (item != NULL) {
                std::string pv;
                if (getPropertyString(item->prop, &pv) && !pv.empty()) {
                    trimmed = pv;
                    fallbackProp++;
                } else if (item->def != NULL && item->def[0] != '\0') {
                    trimmed = item->def;
                    fallbackDef++;
                }
            }
        }
        // work_mode 特殊: 与 getValue 保持同一来源(标志文件存在性),避免 list 显示
        // unifykey/property 的旧值而 get work_mode 显示文件真值的"两处不一致"
        if (strcmp(key, kModeKey) == 0) {
            trimmed = isUserMode() ? kModeUser : kModeFactory;
        }
        Entry entry;
        entry.name = key;
        entry.value = trimmed;
        entries->push_back(std::move(entry));
    }
    lock.reset();
    ALOGI("pdm-hidl: readAllEntries() done, total %zu entries (hitUnify=%zu hitProp=%d hitDef=%d)",
          entries->size(), entries->size() - fallbackProp - fallbackDef, fallbackProp, fallbackDef);
    return true;
}

void PdmHal::syncKeyToProperty(const std::string& name, const std::string& value) {
    ALOGD("pdm-hidl: syncKeyToProperty(name='%s', value='%s') start", name.c_str(), value.c_str());
    // 打开白名单改写门,离开本函数(含失败路径)由 RoWhiteListGate 析构自动关闭
    RoWhiteListGate whiteListGate;
    int matched = 0;
    for (const auto& item : kKeyPropMap) {
        if (name != item.key) continue;
        matched++;
        const char* v = value.empty() ? item.def : value.c_str();
        ALOGD("pdm-hidl: syncKeyToProperty: mapping key='%s' -> prop='%s' value='%s'",
              name.c_str(), item.prop, v);
        if (property_set(item.prop, v) != 0) {
            ALOGW("pdm-hidl: syncKeyToProperty: setprop %s=%s failed (ro.* 已被 init 冻结时属正常)",
                  item.prop, v);
        } else {
            ALOGI("pdm-hidl: syncKeyToProperty: setprop %s=%s OK", item.prop, v);
        }
    }
    if (matched == 0) {
        ALOGW("pdm-hidl: syncKeyToProperty: key='%s' has no property mapping, skipped",
              name.c_str());
    }
}

PdmStatus PdmHal::setValueInternal(const std::string& name, const std::string& value,
                                   bool* result) {
    ALOGI("pdm-hidl: setValue(name='%s', value='%s') enter", name.c_str(), value.c_str());
    *result = false;
    // 1. 先做参数合法性校验(避免上一轮 name='' 的假 Success):
    //    name 必须非空 且 存在于 kKeyPropMap; 否则直接返回 NAME_NOT_FOUND,
    //    不会再 writeFile 空字符串到 sysfs, 也不会给上层误报 result=true.
    if (name.empty()) {
        ALOGE("pdm-hidl: setValue: empty name -> NAME_NOT_FOUND");
        return PdmStatus::NAME_NOT_FOUND;
    }
    if (findMapItem(name) == NULL) {
        ALOGE("pdm-hidl: setValue: unknown name='%s' not in kKeyPropMap -> NAME_NOT_FOUND",
              name.c_str());
        return PdmStatus::NAME_NOT_FOUND;
    }
    // work_mode 是模式开关而非普通键值: 取值必须是 "0"(工厂)/"1"(用户)。
    if (name == kModeKey && !isValidModeValue(value)) {
        ALOGE("pdm-hidl: setValue: work_mode value '%s' invalid, expect '0'(factory)/'1'(user)"
              " -> BAD_VALUE", value.c_str());
        return PdmStatus::BAD_VALUE;
    }
    std::unique_ptr<Lock> lock = Lock::create();
    if (!lock) {
        ALOGE("pdm-hidl: setValue: lock failed, return PERMISSION_DENIED");
        return PdmStatus::PERMISSION_DENIED;
    }
    // unifykeys 协议:先写 key 名,再写值
    if (!writeFile(kUnifyKeyName, name)) {
        ALOGE("pdm-hidl: setValue: write name '%s' to %s failed: %s",
              name.c_str(), kUnifyKeyName, strerror(errno));
        return PdmStatus::UNKNOWN_ERROR;
    }
    if (!writeFile(kUnifyKeyWrite, value)) {
        ALOGE("pdm-hidl: setValue: write value '%s' to %s failed: %s",
              value.c_str(), kUnifyKeyWrite, strerror(errno));
        return PdmStatus::UNKNOWN_ERROR;
    }
    lock.reset();  // 解锁后再同步属性,缩短持锁时间

    syncKeyToProperty(name, trimTail(value));

    if (name == kModeKey) {
        if (!applyUserModeFile(trimTail(value))) {
            ALOGE("pdm-hidl: setValue: apply user work_mode flag for work_mode='%s' failed"
                  " -> UNKNOWN_ERROR", value.c_str());
            return PdmStatus::UNKNOWN_ERROR;
        }
    }

    *result = true;
    ALOGI("pdm-hidl: setValue(name='%s') success, result=true", name.c_str());
    return PdmStatus::OK;
}

PdmStatus PdmHal::getValueInternal(const std::string& name, std::string* value) {
    ALOGI("pdm-hidl: getValue(name='%s') enter", name.c_str());
    *value = "";
    if (name.empty()) {
        ALOGE("pdm-hidl: getValue: empty name -> NAME_NOT_FOUND");
        return PdmStatus::NAME_NOT_FOUND;
    }
    const auto* item = findMapItem(name);
    if (item == NULL) {
        ALOGE("pdm-hidl: getValue: unknown name='%s' not in kKeyPropMap -> NAME_NOT_FOUND",
              name.c_str());
        return PdmStatus::NAME_NOT_FOUND;
    }
    // work_mode 特殊: 模式真值在标志文件里(系统其余部分也只看文件),直接据此返回,
    if (name == kModeKey) {
        *value = isUserMode() ? kModeUser : kModeFactory;
        ALOGI("pdm-hidl: getValue(name='work_mode') from user work_mode flag file '%s', value='%s'",
              kUserModeFile, value->c_str());
        return PdmStatus::OK;
    }

    std::unique_ptr<Lock> lock = Lock::create();
    if (!lock) {
        ALOGE("pdm-hidl: getValue: lock failed, return PERMISSION_DENIED");
        return PdmStatus::PERMISSION_DENIED;
    }
    // 1. 先查 unifykeys 驱动
    bool unifyOk = true;
    if (!writeFile(kUnifyKeyName, name)) {
        ALOGW("pdm-hidl: getValue: write name '%s' to %s failed, skip unifykeys",
              name.c_str(), kUnifyKeyName);
        unifyOk = false;
    }
    std::string v;
    if (unifyOk && !readFile(kUnifyKeyRead, &v)) {
        ALOGW("pdm-hidl: getValue: read '%s' from %s failed, skip unifykeys",
              name.c_str(), kUnifyKeyRead);
        unifyOk = false;
    }
    v = trimTail(v);
    lock.reset();

    // 2. Fallback 链: unifykeys 空 → 读系统 property → 用 kKeyPropMap 默认值.
    //    因为板上首次开机或 unifykeys 未烧录时, readFile 会空, 但 getprop
    //    ro.product.model 已存在(0905实测=TB712)
    if (unifyOk && !v.empty()) {
        ALOGD("pdm-hidl: getValue(name='%s') hit unifykeys len=%zu", name.c_str(), v.size());
    } else {
        // 读 key 映射的第一个 property(ro.product.model 等), 若有值直接用
        if (getPropertyString(item->prop, &v) && !v.empty()) {
            ALOGD("pdm-hidl: getValue(name='%s') fallback prop '%s'='%s'",
                  name.c_str(), item->prop, v.c_str());
        } else if (item->def != NULL && item->def[0] != '\0') {
            v = item->def;
            ALOGD("pdm-hidl: getValue(name='%s') fallback default='%s'", name.c_str(), v.c_str());
        } else {
            v.clear();
            ALOGD("pdm-hidl: getValue(name='%s') no default, return empty", name.c_str());
        }
    }
    *value = v;
    ALOGI("pdm-hidl: getValue(name='%s') done, value_len=%zu value='%s'",
          name.c_str(), value->size(), value->c_str());
    return PdmStatus::OK;
}

// ---------------- HIDL 方法:业务实现 + 回调 -------------------------------
// HIDL 的 Return<T> 只反映传输层错误,业务结果一律经 _hidl_cb 回传
// (与旧实现的 status_t 返回 + 出参一一对应)。

Return<void> PdmHal::setValue(const hidl_string& name, const hidl_string& value,
                              setValue_cb _hidl_cb) {
    bool result = false;
    PdmStatus status = setValueInternal(std::string(name.c_str(), name.size()),
                                        std::string(value.c_str(), value.size()), &result);
    ALOGD("pdm-hidl: IPdm::setValue returned status=%d result=%d",
          (int)status, result ? 1 : 0);
    _hidl_cb(status, result);
    return Void();
}

Return<void> PdmHal::getValue(const hidl_string& name, getValue_cb _hidl_cb) {
    std::string value;
    PdmStatus status = getValueInternal(std::string(name.c_str(), name.size()), &value);
    ALOGD("pdm-hidl: IPdm::getValue returned status=%d value_len=%zu",
          (int)status, value.size());
    _hidl_cb(status, value);
    return Void();
}

Return<void> PdmHal::getEntries(getEntries_cb _hidl_cb) {
    ALOGI("pdm-hidl: IPdm::getEntries() enter");
    std::vector<Entry> entries;
    if (!readAllEntries(&entries)) {
        ALOGE("pdm-hidl: IPdm::getEntries() failed");
        _hidl_cb(PdmStatus::UNKNOWN_ERROR, hidl_vec<Entry>());
        return Void();
    }
    ALOGI("pdm-hidl: IPdm::getEntries() success, %zu entries returned", entries.size());
    _hidl_cb(PdmStatus::OK, hidl_vec<Entry>(entries));
    return Void();
}

}  // namespace implementation
}  // namespace V1_0
}  // namespace pdm
}  // namespace starnet
}  // namespace vendor
