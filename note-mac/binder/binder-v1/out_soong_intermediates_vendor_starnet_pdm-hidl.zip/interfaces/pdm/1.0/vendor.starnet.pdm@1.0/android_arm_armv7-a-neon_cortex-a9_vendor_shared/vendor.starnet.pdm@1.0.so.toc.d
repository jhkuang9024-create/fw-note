out/soong/.intermediates/vendor/starnet/pdm-hidl/interfaces/pdm/1.0/vendor.starnet.pdm@1.0/android_arm_armv7-a-neon_cortex-a9_vendor_shared/vendor.starnet.pdm@1.0.so.toc: \
  prebuilts/gcc/linux-x86/arm/arm-linux-androideabi-4.9/bin/arm-linux-androideabi-readelf \
