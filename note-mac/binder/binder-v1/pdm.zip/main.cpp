#include <binder/IPCThreadState.h>
#include <binder/IServiceManager.h>
#include <binder/ProcessState.h>
#include <log/log.h>
#include <unistd.h>

#include "PdmService.h"

using namespace android;

int main() {
    sp<IServiceManager> sm = defaultServiceManager();
    if (sm == NULL) {
        ALOGE("pdm: main() defaultServiceManager returned NULL, aborting");
        return 1;
    }

    sp<PdmService> service = new PdmService();  // 构造时同步一次属性

    // servicemanager 可能还没起来,重试几次(它和本服务同属 core class)
    const char* kServiceName = "vendor.starnet.pdm";
    status_t err = NO_ERROR;
    for (int i = 0; i < 10; i++) {
        err = sm->addService(String16(kServiceName), service);
        if (err == NO_ERROR) break;
        ALOGW("pdm: addService(%s) failed(%d), retry %d after 200ms...",
              kServiceName, err, i + 1);
        usleep(200 * 1000);
    }
    if (err != NO_ERROR) {
        ALOGE("pdm: addService(%s) exhausted all retries, final err=%d", kServiceName, err);
        return 1;
    }
    ProcessState::self()->startThreadPool();
    IPCThreadState::self()->joinThreadPool();
    ALOGE("pdm: main() unexpectedly returned from joinThreadPool()");
    return 0;  // 不应到达
}
