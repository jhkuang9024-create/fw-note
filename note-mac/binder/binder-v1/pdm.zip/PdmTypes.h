#pragma once

#include <string>

namespace android {

struct PdmEntry {
    std::string name;
    std::string value;
    PdmEntry() {}
    PdmEntry(const std::string& n, const std::string& v) : name(n), value(v) {}
};

}  // namespace android
