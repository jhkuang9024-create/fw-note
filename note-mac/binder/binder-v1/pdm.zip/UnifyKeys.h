#pragma once

// Amlogic unifykeys(kernel: /sys/class/unifykeys)节点 —— 需确认目标 A9 内核已带该驱动
constexpr const char* kUnifyKeyName   = "/sys/class/unifykeys/name";
constexpr const char* kUnifyKeyWrite  = "/sys/class/unifykeys/write";
constexpr const char* kUnifyKeyRead   = "/sys/class/unifykeys/read";
constexpr const char* kUnifyKeyLock   = "/sys/class/unifykeys/lock";
