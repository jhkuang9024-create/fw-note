// Copyright (C) 2026-2026 福建星网锐捷通讯股份有限公司. All rights reserved.
#pragma once

#include <memory>

// 与 PdmService/IPdm 同命名空间(本模块均为传统 libbinder,android 命名空间)
namespace android {

// 用户态互斥:对 /sys/class/unifykeys/lock 节点 fd 做 flock,
// 仅用于多客户端并发串行化,不会真正写 lock 节点(不锁存储)
class Lock {
  public:
    static std::unique_ptr<Lock> create();
    ~Lock();

  private:
    Lock();

    int fd = -1;
    bool locked = false;
};

}  // namespace android
