#pragma once

#include <binder/IInterface.h>
#include <binder/IBinder.h>

#include <string>
#include <vector>

#include "PdmTypes.h"

namespace android {

// 对应原 AIDL 文件里 IPdm 的 setValue/getValue/getEntries
// (getSchemas 在原服务里是空实现,这里不再保留)
class IPdm : public IInterface {
public:
    DECLARE_META_INTERFACE(Pdm)

    enum {
        TRANSACTION_setValue   = IBinder::FIRST_CALL_TRANSACTION,
        TRANSACTION_getValue   = IBinder::FIRST_CALL_TRANSACTION + 1,
        TRANSACTION_getEntries = IBinder::FIRST_CALL_TRANSACTION + 2,
    };

    virtual status_t setValue(const std::string& name, const std::string& value,
                              bool* result) = 0;
    virtual status_t getValue(const std::string& name, std::string* value) = 0;
    virtual status_t getEntries(std::vector<PdmEntry>* entries) = 0;
};

class BnPdm : public BnInterface<IPdm> {
public:
    status_t onTransact(uint32_t code, const Parcel& data, Parcel* reply,
                        uint32_t flags = 0) override;
};

class BpPdm : public BpInterface<IPdm> {
public:
    explicit BpPdm(const sp<IBinder>& impl) : BpInterface<IPdm>(impl) {}

    status_t setValue(const std::string& name, const std::string& value,
                      bool* result) override;
    status_t getValue(const std::string& name, std::string* value) override;
    status_t getEntries(std::vector<PdmEntry>* entries) override;
};

}  // namespace android
