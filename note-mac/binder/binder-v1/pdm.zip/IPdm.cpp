#include "IPdm.h"

#include <binder/Parcel.h>
#include <log/log.h>
#include <utils/String8.h>

namespace android {

// 第二个参数是全局唯一的 descriptor,服务名与之解耦
IMPLEMENT_META_INTERFACE(Pdm, "vendor.starnet.pdm.IPdm")

static String16 toString16(const std::string& s) { return String16(s.c_str()); }

static std::string toString(const String16& s16) {
    String8 s8(s16);
    return std::string(s8.string(), s8.size());
}

// ---------- 服务端:解析请求、调用本地实现、回填 reply ----------
// ⚠️ 协议兼容核心: 不用 libbinder 的 Parcel::enforceInterface().
//
// 根因(pdm_test_0906.log L546-L554): libbinder enforceInterface() 内部 *硬编码*:
//   readInt32(strict_mask 4B) → readInt32(work_src 4B) → readString16(token)
// 而我们动态探测 Format A/B 时, Parcel 头里前置 0/4/8B 额外字节的组合在
// Android 9 不同 caller 进程里其实不止 2 种;一旦我们 probe 出来的 tokenOffset 跟
// enforceInterface() 预期对不上, 它就会: ① 读错 token len → 内部报 "Reading NULL string"
// ② 返回值却可能是 NO_ERROR(因为它跳过了一些 0) → ③ 后面 payload(name/value) 位置
// 错位 → 读到空串, 触发 getValue: empty name → NAME_NOT_FOUND (-2).
//
// 解决方案: 手工实现 token 校验 + payload seek 三步:
//   1) probeTokenLenOffset(): 在 0/4/8 三个候选位置找 expectedLen(23), 找到即 token
//      的 String16 头 int32 所在字节偏移.
//   2) 从该 offset 调 readString16Inplace(): 它内部自行 readInt32 读 len 并读内容,
//      ⚠️ 绝不能在其前再手动 readInt32(len), 否则位置落在 token 字符上必返回 NULL;
//      读到的 token compare(server_desc);
//   3) 算 String16 结尾的 4B 对齐偏移, setDataPosition() 到那里 → 之后直接
//      readString16(name/value) 就是业务 payload, 永不错位.
static inline int probeTokenLenOffset(const Parcel& data, size_t expectedLen, size_t size) {
    const int candidates[] = {0, 4, 8};
    for (int off : candidates) {
        if (size < (size_t)(off + 4)) continue;
        status_t save = data.dataPosition();
        const_cast<Parcel&>(data).setDataPosition(off);
        int32_t v = const_cast<Parcel&>(data).readInt32();
        const_cast<Parcel&>(data).setDataPosition(save);
        if ((size_t)v == expectedLen) return off;
    }
    return 0;
}
// String16 4B 对齐用: n*2 char bytes + 4B head → roundUp4(4 + 2*n)
static inline size_t roundUp4(size_t x) { return (x + 3) & ~size_t(3); }

status_t BnPdm::onTransact(uint32_t code, const Parcel& data, Parcel* reply,
                           uint32_t /*flags*/) {
    String16 svr_desc = IPdm::getInterfaceDescriptor();
    String8 svr_desc8(svr_desc);
    const size_t expectedLen = svr_desc.size();
    const size_t size = data.dataSize();
    // 1. 找 token String16 的 len int32 所在字节偏移 (tokenLenOffset)
    int tokenLenOffset = probeTokenLenOffset(data, expectedLen, size);
    ALOGD("pdm: BnPdm::onTransact(code=%u) enter, detected tokenLenOffset=%d, "
          "size=%ld cap=%ld, svr_desc.len=%zu",
          code, tokenLenOffset, (long)size, (long)data.dataCapacity(), expectedLen);
    ALOGD("pdm: BnPdm::onTransact server-side descriptor='%s' (len=%zu)",
          svr_desc8.string(), svr_desc8.size());

    // 2. 从 tokenLenOffset 开始, 读 + 比对 descriptor, 算出 payload 起始
    status_t tokenErr = NO_ERROR;
    size_t payloadPos = 0;
    {
        status_t save = data.dataPosition();
        Parcel& d = const_cast<Parcel&>(data);
        // ⚠️ readString16Inplace() 内部会先 readInt32() 读 String16 的 len
        // (frameworks/native/libs/binder/Parcel.cpp readString16Inplace), 这里
        // 不能再先手动 readInt32(len) —— 否则位置会落到 token 字符内容上, 二次读
        // 出的"长度"是字符数据 → 必返回 NULL → BAD_VALUE(-22), 即 0907 日志
        // "BnPdm::onTransact readString16Inplace returned NULL"、pdm.cli 全挂的根因。
        d.setDataPosition(tokenLenOffset);
        size_t actual_len = 0;
        const char16_t* ptr = d.readString16Inplace(&actual_len);
        String16 client_token;
        if (ptr == NULL) {
            ALOGE("pdm: BnPdm::onTransact(code=%u) readString16Inplace returned NULL", code);
            tokenErr = BAD_VALUE;
        } else if (actual_len != expectedLen) {
            String8 client8;
            client8 = String8(String16(ptr, actual_len));
            ALOGE("pdm: BnPdm::onTransact(code=%u) token actual_len=%zu != expected=%zu, client='%s'",
                  code, actual_len, expectedLen, client8.string());
            tokenErr = BAD_VALUE;
        } else {
            client_token = String16(ptr, actual_len);
            if (client_token != svr_desc) {
                String8 client8(client_token);
                ALOGE("pdm: BnPdm::onTransact(code=%u) token mismatch: client='%s' expected='%s'",
                      code, client8.string(), svr_desc8.string());
                tokenErr = BAD_TYPE;
            } else {
                payloadPos = (size_t)d.dataPosition();
                ALOGD("pdm: BnPdm::onTransact(code=%u) token OK, payloadPos=%zu",
                      code, payloadPos);
            }
        }
        d.setDataPosition(save);
    }

    if (tokenErr != NO_ERROR) {
        if (reply != NULL) reply->writeInt32(tokenErr);
        return tokenErr;
    }

    switch (code) {
        case IPdm::TRANSACTION_setValue: {
            ALOGD("pdm: BnPdm::onTransact -> TRANSACTION_setValue");
            Parcel& d = const_cast<Parcel&>(data);
            d.setDataPosition(payloadPos);
            std::string name = toString(d.readString16());
            std::string value = toString(d.readString16());
            ALOGD("pdm: BnPdm::onTransact(setValue) name='%s' value_len=%zu",
                  name.c_str(), value.size());
            bool result = false;
            status_t err = setValue(name, value, &result);
            ALOGD("pdm: BnPdm::onTransact(setValue) service returned err=%d result=%d",
                  err, result ? 1 : 0);
            if (reply != NULL) {
                reply->writeInt32(err);
                if (err == NO_ERROR) reply->writeInt32(result ? 1 : 0);
            }
            return NO_ERROR;
        }
        case IPdm::TRANSACTION_getValue: {
            ALOGD("pdm: BnPdm::onTransact -> TRANSACTION_getValue");
            Parcel& d = const_cast<Parcel&>(data);
            d.setDataPosition(payloadPos);
            std::string name = toString(d.readString16());
            ALOGD("pdm: BnPdm::onTransact(getValue) name='%s'", name.c_str());
            std::string value;
            status_t err = getValue(name, &value);
            ALOGD("pdm: BnPdm::onTransact(getValue) service returned err=%d value_len=%zu",
                  err, value.size());
            if (reply != NULL) {
                reply->writeInt32(err);
                if (err == NO_ERROR) reply->writeString16(toString16(value));
            }
            return NO_ERROR;
        }
        case IPdm::TRANSACTION_getEntries: {
            ALOGD("pdm: BnPdm::onTransact -> TRANSACTION_getEntries");
            (void)payloadPos; // getEntries 无入参,不需要读
            std::vector<PdmEntry> entries;
            status_t err = getEntries(&entries);
            ALOGD("pdm: BnPdm::onTransact(getEntries) service returned err=%d entries=%zu",
                  err, entries.size());
            if (reply != NULL) {
                reply->writeInt32(err);
                if (err == NO_ERROR) {
                    reply->writeInt32(entries.size());
                    for (const auto& e : entries) {
                        reply->writeString16(toString16(e.name));
                        reply->writeString16(toString16(e.value));
                    }
                }
            }
            return NO_ERROR;
        }
        default:
            // BBinder 自己处理 FIRST_CALL_TRANSACTION / PING 等,要从 pos 0 开始读 token,
            // 先 rollback 到 0.
            const_cast<Parcel&>(data).setDataPosition(0);
            ALOGD("pdm: BnPdm::onTransact(code=%u) -> fallthrough to BBinder (rollback pos 0)", code);
            return BBinder::onTransact(code, data, reply, 0);
    }
}

// ---------- 客户端:打包请求、解析 reply ----------
status_t BpPdm::setValue(const std::string& name, const std::string& value, bool* result) {
    ALOGD("pdm: BpPdm::setValue(name='%s', value='%s') enter", name.c_str(), value.c_str());
    // 调试: 打印客户端写入的 descriptor(与服务端对照)
    String16 cli_desc = IPdm::getInterfaceDescriptor();
    String8 cli_desc8(cli_desc);
    ALOGD("pdm: BpPdm::setValue client-side writeInterfaceToken descriptor='%s' (len=%zu)",
          cli_desc8.string(), cli_desc8.size());
    Parcel data, reply;
    data.writeInterfaceToken(IPdm::getInterfaceDescriptor());
    data.writeString16(toString16(name));
    data.writeString16(toString16(value));
    // ⚠️ 协议修复: transact 返回的是 binder 层传输错误,不是业务错误!
    //   transact=0 只代表"包送到了并收到回复",业务错误在 reply.readInt32() 里
    status_t transact_err = remote()->transact(IPdm::TRANSACTION_setValue, data, &reply);
    if (transact_err != NO_ERROR) {
        ALOGE("pdm: BpPdm::setValue transact failed: %d", transact_err);
        return transact_err;
    }
    status_t err = reply.readInt32();
    if (err == NO_ERROR && result != NULL) {
        *result = reply.readInt32() != 0;
        ALOGD("pdm: BpPdm::setValue done, err=%d result=%d", err, *result ? 1 : 0);
    } else {
        ALOGD("pdm: BpPdm::setValue done, err=%d", err);
    }
    return err;
}

status_t BpPdm::getValue(const std::string& name, std::string* value) {
    ALOGD("pdm: BpPdm::getValue(name='%s') enter", name.c_str());
    String16 cli_desc = IPdm::getInterfaceDescriptor();
    String8 cli_desc8(cli_desc);
    ALOGD("pdm: BpPdm::getValue client-side writeInterfaceToken descriptor='%s' (len=%zu)",
          cli_desc8.string(), cli_desc8.size());
    Parcel data, reply;
    data.writeInterfaceToken(IPdm::getInterfaceDescriptor());
    data.writeString16(toString16(name));
    status_t transact_err = remote()->transact(IPdm::TRANSACTION_getValue, data, &reply);
    if (transact_err != NO_ERROR) {
        ALOGE("pdm: BpPdm::getValue transact failed: %d", transact_err);
        return transact_err;
    }
    status_t err = reply.readInt32();
    if (err == NO_ERROR && value != NULL) {
        *value = toString(reply.readString16());
        ALOGD("pdm: BpPdm::getValue done, err=%d value_len=%zu", err, value->size());
    } else {
        ALOGD("pdm: BpPdm::getValue done, err=%d", err);
    }
    return err;
}

status_t BpPdm::getEntries(std::vector<PdmEntry>* entries) {
    ALOGD("pdm: BpPdm::getEntries() enter");
    String16 cli_desc = IPdm::getInterfaceDescriptor();
    String8 cli_desc8(cli_desc);
    ALOGD("pdm: BpPdm::getEntries client-side writeInterfaceToken descriptor='%s' (len=%zu)",
          cli_desc8.string(), cli_desc8.size());
    Parcel data, reply;
    data.writeInterfaceToken(IPdm::getInterfaceDescriptor());
    status_t transact_err = remote()->transact(IPdm::TRANSACTION_getEntries, data, &reply);
    if (transact_err != NO_ERROR) {
        ALOGE("pdm: BpPdm::getEntries transact failed: %d", transact_err);
        return transact_err;
    }
    status_t err = reply.readInt32();
    if (err == NO_ERROR && entries != NULL) {
        entries->clear();
        int32_t n = reply.readInt32();
        entries->reserve(n);
        ALOGD("pdm: BpPdm::getEntries reading %d entries", n);
        for (int32_t i = 0; i < n; i++) {
            entries->push_back(
                    PdmEntry(toString(reply.readString16()), toString(reply.readString16())));
        }
        ALOGD("pdm: BpPdm::getEntries done, err=%d entries=%zu", err, entries->size());
    } else {
        ALOGD("pdm: BpPdm::getEntries done, err=%d", err);
    }
    return err;
}

}  // namespace android
