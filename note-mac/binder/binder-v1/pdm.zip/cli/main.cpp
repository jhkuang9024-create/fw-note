#include <binder/IServiceManager.h>
#include <binder/ProcessState.h>
#include <log/log.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <string>
#include <vector>

#include "../IPdm.h"

using namespace android;

static void printUsage(const char* prog) {
    printf("Usage:\n"
           "  %s set <name> <value>   - 设置键值对(烧写 unifykey)\n"
           "  %s get <name>           - 获取指定键的值\n"
           "  %s list                 - 获取所有条目\n",
           prog, prog, prog);
}

// 去掉尾部换行后打印,避免 sysfs 值自带 '\n' 时输出多空行
static std::string stripTail(const std::string& s) {
    size_t end = s.size();
    while (end > 0 && (s[end - 1] == '\n' || s[end - 1] == '\r')) end--;
    if (end != s.size()) {
        ALOGD("pdm-cli: stripTail trimmed %zu chars", s.size() - end);
    }
    return s.substr(0, end);
}

int main(int argc, char* argv[]) {
    ALOGI("pdm-cli: main() argc=%d, pid=%d uid=%d", argc, getpid(), getuid());

    if (argc < 2) {
        ALOGW("pdm-cli: no command provided");
        printUsage(argv[0]);
        return 1;
    }

    ALOGD("pdm-cli: starting binder thread pool");
    // 客户端也需要初始化 binder 上下文
    ProcessState::self()->startThreadPool();

    ALOGD("pdm-cli: getting ServiceManager");
    sp<IServiceManager> sm = defaultServiceManager();
    if (sm == NULL) {
        fprintf(stderr, "Error: failed to get ServiceManager\n");
        ALOGE("pdm-cli: defaultServiceManager() returned NULL");
        return 1;
    }

    ALOGI("pdm-cli: looking up service 'vendor.starnet.pdm'");
    sp<IBinder> binder = sm->getService(String16("vendor.starnet.pdm"));  // 内部会短暂重试
    if (binder == NULL) {
        fprintf(stderr, "Error: service 'vendor.starnet.pdm' not found"
                        " (pdm-service 未运行或 SELinux 拦截?)\n");
        ALOGE("pdm-cli: service 'vendor.starnet.pdm' not found");
        return 1;
    }
    ALOGI("pdm-cli: found service binder=%p, casting to IPdm", binder.get());
    sp<IPdm> pdm = interface_cast<IPdm>(binder);
    if (pdm == NULL) {
        ALOGE("pdm-cli: interface_cast<IPdm> failed");
        fprintf(stderr, "Error: interface cast failed\n");
        return 1;
    }
    ALOGD("pdm-cli: interface cast OK, pdm=%p", pdm.get());

    std::string command = argv[1];
    ALOGI("pdm-cli: executing command='%s'", command.c_str());

    if (command == "set" && argc == 4) {
        ALOGI("pdm-cli: setValue name='%s' value='%s'", argv[2], argv[3]);
        bool ok = false;
        status_t st = pdm->setValue(argv[2], argv[3], &ok);
        ALOGI("pdm-cli: setValue returned st=%d ok=%d", st, ok ? 1 : 0);
        if (st != NO_ERROR || !ok) {
            fprintf(stderr, "Error: setValue(%s) failed, st=%d\n", argv[2], st);
            ALOGE("pdm-cli: setValue failed st=%d ok=%d", st, ok ? 1 : 0);
            return 1;
        }
        printf("Success: set %s=%s\n", argv[2], argv[3]);
        ALOGI("pdm-cli: set %s=%s SUCCESS", argv[2], argv[3]);
    } else if (command == "get" && argc == 3) {
        ALOGI("pdm-cli: getValue name='%s'", argv[2]);
        std::string value;
        status_t st = pdm->getValue(argv[2], &value);
        ALOGI("pdm-cli: getValue returned st=%d value_len=%zu", st, value.size());
        if (st != NO_ERROR) {
            fprintf(stderr, "Error: getValue(%s) failed, st=%d\n", argv[2], st);
            ALOGE("pdm-cli: getValue failed st=%d", st);
            return 1;
        }
        std::string trimmed = stripTail(value);
        printf("%s=%s\n", argv[2], trimmed.c_str());
        ALOGI("pdm-cli: get %s='%s'", argv[2], trimmed.c_str());
    } else if (command == "list" && argc == 2) {
        ALOGI("pdm-cli: getEntries()");
        std::vector<PdmEntry> entries;
        status_t st = pdm->getEntries(&entries);
        ALOGI("pdm-cli: getEntries returned st=%d count=%zu", st, entries.size());
        if (st != NO_ERROR) {
            fprintf(stderr, "Error: getEntries failed, st=%d\n", st);
            ALOGE("pdm-cli: getEntries failed st=%d", st);
            return 1;
        }
        for (const auto& e : entries) {
            std::string trimmed = stripTail(e.value);
            printf("%s=%s\n", e.name.c_str(), trimmed.c_str());
            ALOGD("pdm-cli:   %s='%s'", e.name.c_str(), trimmed.c_str());
        }
        ALOGI("pdm-cli: listed %zu entries", entries.size());
    } else {
        ALOGW("pdm-cli: unknown/invalid command='%s' argc=%d", command.c_str(), argc);
        printUsage(argv[0]);
        return 1;
    }
    ALOGI("pdm-cli: main() done, exit 0");
    return 0;
}
