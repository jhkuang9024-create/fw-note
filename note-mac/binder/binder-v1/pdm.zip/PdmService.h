#pragma once

#include "IPdm.h"

namespace android {

class PdmService : public BnPdm {
public:
    PdmService();

    status_t setValue(const std::string& name, const std::string& value, bool* result) override;
    status_t getValue(const std::string& name, std::string* value) override;
    status_t getEntries(std::vector<PdmEntry>* entries) override;

private:
    // 读取全部已知 key(name->value 逐项填充)
    bool readAllEntries(std::vector<PdmEntry>* entries);
    // key -> 系统属性(对应原 UNIFY_KEY_MAP)
    void syncKeyToProperty(const std::string& name, const std::string& value);
};

}  // namespace android