// Copyright (C) 2026-2026 福建星网锐捷通讯股份有限公司. All rights reserved.

#include "Lock.h"

#include <errno.h>
#include <fcntl.h>
#include <log/log.h>
#include <string.h>
#include <unistd.h>

#include <memory>

#include "UnifyKeys.h"

namespace android {

std::unique_ptr<Lock> Lock::create() {
    ALOGD("pdm: Lock::create() enter, lock_path=%s", kUnifyKeyLock);
    auto lock = std::unique_ptr<Lock>(new Lock());

    lock->fd = open(kUnifyKeyLock, O_WRONLY);
    if (lock->fd < 0) {
        ALOGE("pdm: Lock::create open %s failed: %s", kUnifyKeyLock, strerror(errno));
        return nullptr;
    }
    ALOGD("pdm: Lock::create open %s success, fd=%d", kUnifyKeyLock, lock->fd);

    struct flock flock;
    flock.l_whence = SEEK_SET;
    flock.l_start = 0;
    flock.l_len = 0;
    flock.l_type = F_WRLCK;
    flock.l_pid = -1;

    ALOGD("pdm: Lock::create acquiring F_WRLCK (blocking) on fd=%d", lock->fd);
    if (fcntl(lock->fd, F_SETLKW, &flock) < 0) {
        ALOGE("pdm: Lock::create fcntl(F_SETLKW) failed on %s: %s",
              kUnifyKeyLock, strerror(errno));
        close(lock->fd);
        lock->fd = -1;
        return nullptr;
    }

    lock->locked = true;
    ALOGD("pdm: Lock::create() success, lock acquired on %s (fd=%d)", kUnifyKeyLock, lock->fd);
    return lock;
}

Lock::Lock() {
    ALOGD("pdm: Lock() constructor, fd=%d locked=%d", fd, locked ? 1 : 0);
}

Lock::~Lock() {
    ALOGD("pdm: ~Lock() destructor enter, fd=%d locked=%d", fd, locked ? 1 : 0);
    if (fd < 0) {
        ALOGD("pdm: ~Lock() fd invalid, nothing to do");
        return;
    }

    if (locked) {
        struct flock flock;
        flock.l_whence = SEEK_SET;
        flock.l_start = 0;
        flock.l_len = 0;
        flock.l_type = F_UNLCK;
        flock.l_pid = -1;

        ALOGD("pdm: ~Lock() releasing F_UNLCK on fd=%d", fd);
        int ret = fcntl(fd, F_SETLK, &flock);
        if (ret < 0) {
            ALOGE("pdm: ~Lock() fcntl(F_SETLK, F_UNLCK) failed: %s", strerror(errno));
        }
        locked = false;
    }

    close(fd);
    ALOGD("pdm: ~Lock() closed fd=%d, done", fd);
    fd = -1;
}

}  // namespace android
