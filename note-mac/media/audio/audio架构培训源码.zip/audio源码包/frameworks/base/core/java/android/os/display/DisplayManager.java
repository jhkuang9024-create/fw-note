/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.os.display;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.RemoteException;
import android.os.display.IDisplayService;
import android.util.SparseArray;
import android.util.Log;
import android.util.Slog;
import android.view.Display;
import android.annotation.Nullable;
import android.annotation.SuppressLint;
import android.annotation.NonNull;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import android.annotation.SystemApi;
import android.annotation.SystemService;
import android.content.ContentResolver;

import android.media.AudioManager;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.audiofx.AudioEffect;
import android.provider.Settings;
import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.os.IBinder;
import android.content.IntentFilter;
import android.os.PowerManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.io.FileOutputStream;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.text.TextUtils;
import android.os.SystemProperties;


/**
 * Manages the properties of attached displays.
 * <p>
 * Get an instance of this class by calling
 * {@link android.content.Context#getSystemService(java.lang.String)
 * Context.getSystemService()} with the argument
 * {@link android.content.Context#DISPLAY_MANAGER_SERVICE}.
 * </p>
 */
@SystemService(Context.DISPLAY_MANAGER_SERVICE)
public class DisplayManager {
    private static final String TAG = "DisplayManager";
    private static final boolean DEBUG = true;

    public final static int DISPLAY_STANDARD_1080P_60 = 0;
    public final static int DISPLAY_STANDARD_1080P_50 = 1;
    public final static int DISPLAY_STANDARD_1080P_30 = 2;
    public final static int DISPLAY_STANDARD_1080P_25 = 3;
    public final static int DISPLAY_STANDARD_1080P_24 = 4;
    public final static int DISPLAY_STANDARD_1080I_60 = 5;
    public final static int DISPLAY_STANDARD_1080I_50 = 6;
    public final static int DISPLAY_STANDARD_720P_60 = 7;
    public final static int DISPLAY_STANDARD_720P_50 = 8;
    public final static int DISPLAY_STANDARD_576P_50 = 9;
    public final static int DISPLAY_STANDARD_480P_60 = 10;
    public final static int DISPLAY_STANDARD_PAL = 11;
    public final static int DISPLAY_STANDARD_NTSC = 12;
    public final static int DISPLAY_STANDARD_1080P_120 = 13;
    public final static int DISPLAY_STANDARD_3840_2160P_24 = 0x100;
    public final static int DISPLAY_STANDARD_3840_2160P_25 = 0x101;
    public final static int DISPLAY_STANDARD_3840_2160P_30 = 0x102;
    public final static int DISPLAY_STANDARD_3840_2160P_60 = 0x103;
    public final static int DISPLAY_STANDARD_3840_2160P_50 = 0x104;
    public final static int DISPLAY_STANDARD_4096_2160P_24 = 0x200;
    public final static int DISPLAY_STANDARD_4096_2160P_25 = 0x201;
    public final static int DISPLAY_STANDARD_4096_2160P_30 = 0x202;
    public final static int DISPLAY_STANDARD_4096_2160P_60 = 0x203;
    public final static int DISPLAY_STANDARD_4096_2160P_50 = 0x204;

    public final static int DISPLAY_STANDARD_7680X4320_23_976 = 0x60;
    public final static int DISPLAY_STANDARD_7680X4320_24     = 0x61;
    public final static int DISPLAY_STANDARD_7680X4320_25     = 0x62;
    public final static int DISPLAY_STANDARD_7680X4320_29_97  = 0x63;
    public final static int DISPLAY_STANDARD_7680X4320_30     = 0x64;
    public final static int DISPLAY_STANDARD_7680X4320_50     = 0x65;
    public final static int DISPLAY_STANDARD_7680X4320_59_94  = 0x66;
    public final static int DISPLAY_STANDARD_7680X4320_60     = 0x67;
    public final static int DISPLAY_STANDARD_7680X4320_100    = 0x68;
    public final static int DISPLAY_STANDARD_7680X4320_119_88 = 0x69;
    public final static int DISPLAY_STANDARD_7680X4320P_120   = 0x6A;

    /** @hide */
    public final static int DISPLAY_HDMI_MODE_PCM = 0;
    /** @hide */
    public final static int DISPLAY_HDMI_MODE_RAW = 1;
    /** @hide */
    public final static int DISPLAY_HDMI_MODE_AUTO = 2;
    /** @hide */
    public final static int DISPLAY_SPDIF_MODE_PCM = 0;
    /** @hide */
    public final static int DISPLAY_SPDIF_MODE_RAW = 1;


    public final static int DISPLAY_TV_SUPPORT_HDR_STANDARD_SDR = 0;
    public final static int DISPLAY_TV_SUPPORT_HDR_STANDARD_HDR = 1;
    public final static int DISPLAY_TV_SUPPORT_HDR_STANDARD_CUVA = 2;

    public final static int DISPLAY_HDR_MODE_SDR = 0;
    public final static int DISPLAY_HDR_MODE_HDR_10 = 1;
    public final static int DISPLAY_HDR_MODE_AUTO = 2;

    public final static int DISPLAY_SDR_BRIGHTNESS_0_NIT = 0;
    public final static int DISPLAY_SDR_BRIGHTNESS_100_NIT = 100;
    public final static int DISPLAY_SDR_BRIGHTNESS_200_NIT = 200;
    public final static int DISPLAY_SDR_BRIGHTNESS_300_NIT = 300;
    public final static int DISPLAY_SDR_BRIGHTNESS_400_NIT = 400;

    public final static int DISPLAY_HDR_BRIGHTNESS_0_NIT = 0;
    public final static int DISPLAY_HDR_BRIGHTNESS_500_NIT =500;
    public final static int DISPLAY_HDR_BRIGHTNESS_800_NIT = 800;
    public final static int DISPLAY_HDR_BRIGHTNESS_1000_NIT = 1000;
    public final static int DISPLAY_HDR_BRIGHTNESS_1200_NIT = 1200;

    public final static int DISPLAY_COLOR_DEPTH_SPACE_AUTO = 0;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_444_12BIT = 1;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_444_10BIT= 2;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_444_8BIT = 3;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_422_12BIT = 4;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_422_10BIT = 5;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_422_8BIT = 6;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_420_12BIT = 7;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_420_10BIT = 8;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_YUV_420_8BIT = 9;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_RGB_12BIT = 10;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_RGB_10BIT = 11;
    public final static int DISPLAY_COLOR_DEPTH_SPACE_RGB_8BIT = 12;

    private static final String[] HDMI_COLOR_LIST = {
        "444,12bit",
        "444,10bit",
        "444,8bit",
        "422,12bit",
        "422,10bit",
        "422,8bit",
        "420,12bit",
        "420,10bit",
        "420,8bit",
    };

    // audio_policy_forced_cfg_t (system\media\audio\include\system\audio_policy.h)
    public static final int DROID_AUDIO_FORCE_USE_NONE                              = 0; // AUDIO_POLICY_FORCE_NONE
    public static final int DROID_AUDIO_FORCE_USE_SPEAKER                           = 1; // AUDIO_POLICY_FORCE_SPEAKER
    public static final int DROID_AUDIO_FORCE_USE_SPDIF                             = 8; // AUDIO_POLICY_FORCE_ANALOG_DOCK
    public static final int DROID_AUDIO_FORCE_USE_HDMI                              = 9; // AUDIO_POLICY_FORCE_DIGITAL_DOCK
    public static final int DROID_AUDIO_FORCE_USE_HEADPHONES                        = 2; // AUDIO_POLICY_FORCE_HEADPHONES
    public static final int DROID_AUDIO_FORCE_USE_USB                               = 5; // AUDIO_POLICY_FORCE_WIRED_ACCESSORY
    public static final int DROID_AUDIO_FORCE_USE_BT_A2DP                           = 4; // AUDIO_POLICY_FORCE_BT_A2DP

    public static final String CURRENT_DEVICE_AUTO                              = "11"; // AUDIO_POLICY_FORCE_NONE
    public static final String CURRENT_DEVICE_SPEAKER                           = "0"; // AUDIO_POLICY_FORCE_SPEAKER
    public static final String CURRENT_DEVICE_HDMI                              = "1"; // AUDIO_POLICY_FORCE_DIGITAL_DOCK
    public static final String CURRENT_DEVICE_HEADPHONES                        = "2"; // AUDIO_POLICY_FORCE_HEADPHONES
    public static final String CURRENT_DEVICE_USB                               = "4"; // AUDIO_POLICY_FORCE_WIRED_ACCESSORY
    public static final String CURRENT_DEVICE_BT_A2DP                           = "3"; // AUDIO_POLICY_FORCE_BT_A2DP

    private final Context mContext;
    private IDisplayService mService;

    private static final String WAKEALARM_NODE = "/sys/class/rtc/rtc0/wakealarm";
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private String StrpowerOffTime = "";
    private String StrpowerOnTime = "";
    private boolean autoPowerEnabled = false;
    private String StrscreenOffTime = "";
    private String StrscreenOnTime = "";
    private boolean autoScreenEnabled = false;

    /** @hide */
    public DisplayManager (Context ctx,IDisplayService service) {
        mContext = ctx;
        mService = service;

        IntentFilter shutDownFilter = new IntentFilter();
        shutDownFilter.addAction("com.android.tv.settings.action.SCHEDULED_SHUTDOWN");
        shutDownFilter.addAction("com.android.tv.settings.action.SCHEDULED_SCREENON");
        shutDownFilter.addAction("com.android.tv.settings.action.SCHEDULED_SCREENOFF");
        mContext.registerReceiver(mShutdownReceiver, shutDownFilter);
        Log.d(TAG, "registerReceiver mShutdownReceiver");
    }

    /**
     * Create a dummy instance for testing.  All methods will fail unless
     * overridden with an appropriate mock implementation.  To obtain a
     * functional instance, use {@link android.content.Context#getSystemService}.
     */
    @SuppressLint("ManagerConstructor")
    protected DisplayManager() {
        mContext = null;
        mService = null;
    }

    /**
    *判断是否支持制式
    */
    public boolean isSupportStandard(int standard){
        try {
            boolean isSupport = mService.isSupportStandard(standard);
            return isSupport;
        } catch (RemoteException e) {
            Slog.e(TAG,"isSupportStandard error!!");
            return false;
        }
    }

    /**
    *判断是否支持色深
    */
    public boolean isSupportColor(int standard){
        try {
            boolean isSupport = mService.isSupportColor(standard);
            return isSupport;
        } catch (RemoteException e) {
            Slog.e(TAG,"isSupportColor error!!");
            return false;
        }
    }

    /**
    *获取支持制式列表
    */
    @Nullable
    public int[] getAllSupportStandards(){
        try {
            int[] standards = mService.getAllSupportStandards();
            if (standards != null) {
                Slog.e(TAG,"");
            }else{
                Slog.e(TAG,"getAllSupportStandards standard null");
            }
            Log.d(TAG,"getAllSupportStandards starts! ["+standards+"]");
            return standards;
        } catch (RemoteException e) {
            Slog.e(TAG,"getAllSupportStandards ERRER!!!");
            return null;
        }
    }

    /**
    *获取支持色深列表
    */
    @Nullable
    public int[] getAllSupportColor(){
        try {
            int[] standards = mService.getAllSupportColor();
            if (standards != null) {
                Slog.e(TAG,"");
            }else{
                Slog.e(TAG,"getAllSupportColor standard null");
            }
            Log.d(TAG,"getAllSupportColor starts! ["+standards+"]");
            return standards;
        } catch (RemoteException e) {
            Slog.e(TAG,"getAllSupportColor ERRER!!!");
            return null;
        }
    }

    /**
    *设置制式
    */
    public void setDisplayStandard(int standard){
            try {
                mService.setDisplayStandard(standard);
            } catch (RemoteException ex) {
                Slog.e(TAG,"setDisplayStandard error!");
            }
    }

    /**
    *获取当前制式
    */
    public int getCurrentStandard(){
         try{
            int curStandard = mService.getCurrentStandard();
            Slog.e(TAG,"getCurrentStandard curStandard:"+curStandard);
            return curStandard;
        } catch (RemoteException ex) {
            Slog.e(TAG,"getCurrentStandard error!");
            return -1;
            }
    }

    public int getDisplayMode(){
        return DISPLAY_STANDARD_1080P_60;
    }

    /**
    *设置色深
    */
    public void setDisplayColorDepthAndSpace(int colorDepthAndSpace){
            try {
                mService.setDisplayColorDepthAndSpace(colorDepthAndSpace);
            } catch (RemoteException ex) {
                Slog.e(TAG,"setDisplayColorDepthAndSpace error!");
            }
    }

    /**
    *获取当前色深
    */
    public int getCurrentColor(){
         try{
            int curStandard = mService.getCurrentColor();
            Slog.e(TAG,"getCurrentColor curStandard:"+curStandard);
            return curStandard;
        } catch (RemoteException ex) {
            Slog.e(TAG,"getCurrentColor error!");
            return -1;
            }
    }

    /**
    *设置屏幕边距
    */
    public void setScreenMargin(int left,int top,int right,int bottom){
        try {
            mService.setScreenMargin(left,top,right,bottom);
            Slog.d(TAG,"setScreenMargin----> left:"+left+",top:"+top+",right:"+right+",bottom"+bottom);
        } catch (RemoteException e) {
            Slog.e(TAG,"setScreenMargin error");
        }
    }

    /**
    *获取边距
    */
    @Nullable
    public int[] getScreenMargin(){
        try {
            int[] margin = mService.getScreenMargin();
            return margin;
        } catch (RemoteException e) {
            Slog.e(TAG,"getScreenMargin error");
            return null;
        }
    }

    /**
    *保存参数
    */
    public void saveParams(){
        try {
            mService.saveParams();
        } catch (RemoteException e) {
            Slog.e(TAG,"saveParams error");
        }
    }

    /**
    *判断是否支持3D
    */
    @SuppressLint("AcronymName")
    public boolean isTVSupport3D(){
        try {
            Slog.i("Andy_Test","isTVSupport3D");
            boolean isTVSupport3D = mService.isTVSupport3D();
            return isTVSupport3D;
        } catch (Exception e) {
            Slog.e(TAG,"isTVSupport3D error!");
            return false;
        }
    }

    /**
    *设置HDMI透传模式
    */
    @SuppressLint("AcronymName")
    public void setHDMIPassThrough(int mode){
        try {
            Slog.i("Andy_Test","setHDMIPassThrough: " + mode);
            mService.setHDMIPassThrough(mode);
        } catch (RemoteException ex) {
            Slog.e(TAG,"setHDMIPassThrough error!");
        }
    }

    /**
    *设置SPDF透传模式
    *注：实现看系统是否支持
    *@param mode
    */
    @SuppressLint("AcronymName")
    public void setSPDFPassThrough(int mode){
        try {
            Slog.i("Andy_Test","setSPDFPassThrough x: " + mode);
            mService.setSPDFPassThrough(mode);
        } catch (RemoteException ex) {
            Slog.e(TAG,"setSPDFPassThrough error!");
        }
    }

    /**
    *得到SPDF透传模式
    *注：实现看系统是否支持
    *返回当前SPDF透传模式
    */
    @SuppressLint("AcronymName")
    public int getSPDFPassThrough(){
        try {
            Slog.i(TAG, "getSPDFPassThrough()");
            return mService.getSPDFPassThrough();
        } catch (RemoteException ex) {
            Slog.e(TAG,"getSPDFPassThrough error!");
            return -1;
        }

    }






    /**
    *通过HDMI读取电视状况
    *@return
    *-99 电视不支持CEC or HotPlug
    *-1  未连接HDMI
    *0   待机
    *1   开机
    */
    @SuppressLint("AcronymName")
    public int getTVState(){
        try {
            Slog.i("Andy_Test","getTVEDID");
            int tVState = mService.getTVState();
            return tVState;
        } catch (RemoteException ex) {
            Slog.e(TAG,"getTVState error!");
            return 1;
        }
    }

    /**
    *获取EDID信息
    *@return
    *连接返回电视256长度信息，未连接返回null
    */
    @Nullable
    @SuppressLint("AcronymName")
    public byte[] getTVEDID(){
        byte[] edid = null;
        try {
            Slog.i("Andy_Test","getTVEDID");
            edid = mService.getTVEDID();
            return edid;
        } catch (RemoteException ex) {
            Slog.e(TAG,"getTVState error!");
            return edid;
        }
    }

    /**
     * 使用SettingStart设置显示标准
     * @return
     *
     */
    public void setDisplayStandardWithSettingRestart(int standard){
        try{
            mService.setDisplayStandardWithSettingRestart(standard);
        } catch (RemoteException ex){
            Slog.e(TAG,"SetDisplayStandard error!");
        }
    }

   /**
    * Get the current HDR mode
    * 0:Always HDR : Follow sink
    * 1:Adaptive HDR : Follow source
    */
    public int getHdrMode (){
        int mode = 0;
        try {
             mode = mService.getHdrMode();
            } catch (RemoteException ex) {
                Slog.e(TAG,"getHdrMode error!");
        }
        return mode;
    }

   /**
    * Set the current HDR mode
    * 0:Always HDR : Follow sink
    * 1:Adaptive HDR : Follow source
    */
    public void setHdrMode (int mode){
        try {
              mService.setHdrMode(mode);
             } catch (RemoteException ex) {
                Slog.e(TAG,"setHdrMode error!");
        }
    }


    public void setSdrBrightness(int sdrBrightness){
        setSdrNit(sdrBrightness);
    }
    public int getSdrBrightness(){
        return getSdrNit();
    }

    public void setHdrBrightness(int HdrBrightness){
        setHdrNit(HdrBrightness);
    }

    public int getHdrBrightness(){
        return getHdrNit();
    }

    /**
       * update boot logo
       */
    public int updateLogo(@Nullable String path){
        int result = -1;
        try {
            result = mService.updateLogo(path);
        } catch (RemoteException ex) {
            Slog.e(TAG, "updateLogo error");
        }
        return result;
    }

    @SuppressLint("MethodNameUnits")
    public int getDisplayColorDepthAndSpace(){
         try{
            int Standard = mService.getDisplayColorDepthAndSpace();
            Slog.e(TAG,"getDisplayColorDepthAndSpace Standard:"+Standard);
            return Standard;
        } catch (RemoteException ex) {
            Slog.e(TAG,"getDisplayColorDepthAndSpace error!");
            return -1;
            }
    }

    @SuppressLint("MissingNullability")
    public List<Integer> getSupportColorDepthAndSpaceList() {
        List<Integer> resultList = new ArrayList<>();
        try {
            int[] array = mService.getSupportColorDepthAndSpaceList();
            if (array != null) {
                for (int val : array) {
                    resultList.add(val);
                }
            }
        } catch (RemoteException e) {
            Slog.e(TAG, "getSupportColorDepthAndSpaceList RemoteException", e);
        }
        return resultList;
    }

     /*
     * Gets whether the resolution is adaptive
     */
    @SuppressLint("MethodNameTense")
    public boolean isOptimalFormatEnable() {
        boolean result = false;
        try {
            result = mService.isOptimalFormatEnable();
        } catch (RemoteException ex) {
            Slog.e(TAG, "isOptimalFormatEnable error");
        }
        return result;
    }

     /*
     * Sets whether resolution adaptation is enabled
     */
    @SuppressLint("MethodNameTense")
    public void setOptimalFormatEnable(boolean toggle) {
        try {
            mService.setOptimalFormatEnable(toggle);
        } catch (RemoteException ex) {
            Slog.e(TAG, "setOptimalFormatEnable error");
        }
    }

     /*
     * Get the interface with the best resolution
     */
    @Nullable
    public String getOptimalResolution() {
        String optimalResolution = null;
        try {
            optimalResolution = mService.getOptimalResolution();
        } catch (RemoteException ex) {
            Slog.e(TAG, "getOptimalResolution error");
        }
        return optimalResolution;
    }

    public void setOptimalResolution() {
        try {
            mService.setOptimalResolution();
        } catch (RemoteException ex) {
            Slog.e(TAG, "setOptimalResolution error");
        }
    }


    /**
    *判断cec功能是否打开
    */
    @SuppressLint({"AcronymName" , "MethodNameTense"})
    public boolean isCECStandbyEnable(){
        try {
            boolean isSupport = mService.isCECStandbyEnable();
            return isSupport;
        } catch (RemoteException e) {
            Slog.e(TAG,"isCECStandbyEnable error!!");
            return false;
        }
    }

    /**
    *设置cec功能打开/关闭
    */
    @SuppressLint({"AcronymName","MethodNameTense"})
    public void setCECStandbyEnable(boolean value){
        try {
            Slog.i(TAG,"setCECStandbyEnable-->:  " + value);
            mService.setCECStandbyEnable(value);
        } catch (RemoteException ex) {
            Slog.e(TAG,"setCECStandbyEnable error!");
        }
    }

    /**
    *获取HDMI透传模式
    *注：实现看系统是否支持
    *返回DHMI透传模式
    */
    @SuppressLint("AcronymName")
    public int getHDMIPassThrough(){
        try {
            Slog.i(TAG, "getHDMIPassThrough()");
            return mService.getHDMIPassThrough();
        } catch (RemoteException ex) {
            Slog.e(TAG,"getHDMIPassThrough error!");
            return -1;
        }
    }

    /**
     * 设置待机时是否显示led灯.
     *
     * @param showLed 0 显示led, 1不显示
     */
    public void setShowLedWhenStandby(int showLed) {
        try {
            Slog.i(TAG, "setShowLedWhenStandby: " + showLed);
            mService.setShowLedWhenStandby(showLed);
        } catch (RemoteException ex) {
            Slog.e(TAG, "setShowLedWhenStandby error!");
        }
    }

    /**
     * 获取待机时是否显示led灯.
     *
     * @return 0 显示led, 1不显示, -1异常
     */
    public int getShowLedWhenStandby() {
        try {
            int ret = mService.getShowLedWhenStandby();
            Slog.i(TAG, "getShowLedWhenStandby: " + ret);
            return ret;
        } catch (RemoteException ex) {
            Slog.e(TAG, "getShowLedWhenStandby error!");
            return -1;
        }
    }

    /**
     * Get the HDR type supported by the TV
     *
     * @return 0 - SDR TV, 1 - HDR TV, 2 - CUVA TV
     * @hide
     */
    public int getTvHdrType() {
        int mode = 0;
        try {
            mode = mService.getTvHdrType();
        } catch (RemoteException ex) {
            Slog.w(TAG, "getTvHdrType error: " + ex);
        }
        return mode;
    }

    /**
     * Get Sdr brightness in nits, the interface is only called when HDR TV or CUVA TV is currently connected
     *
     * @return 0/100/200/300/400
     * @hide
     */
    public int getSdrNit() {
        int nit = 0;
        try {
            nit = mService.getSdrNit();
        } catch (RemoteException ex) {
            Slog.w(TAG, "getSdrNit error: " + ex);
        }
        return nit;
    }

    /**
     * Set Sdr brightness in nits, the interface is only called when HDR TV or CUVA TV is currently connected
     *
     * @param nit brightness
     * @hide
     */
    public void setSdrNit(int nit) {
        try {
            mService.setSdrNit(nit);
        } catch (RemoteException ex) {
            Slog.w(TAG, "setSdrNit error: " + ex);
        }
    }

    /**
     * Get HDR brightness, in nits, the interface is only called when HDR TV or CUVA TV is currently connected
     *
     * @return 0/500/800/1000/1200
     * @hide
     */
    public int getHdrNit() {
        int nit = 0;
        try {
            nit = mService.getHdrNit();
        } catch (RemoteException ex) {
            Slog.w(TAG, "getHdrNit error: " + ex);
        }
        return nit;
    }

    /**
     * Set HDR brightness in nits, the interface is only called when HDR TV or CUVA TV is currently connected
     *
     * @param nit brightness
     * @hide
     */
    public void setHdrNit(int nit) {
        try {
            mService.setHdrNit(nit);
        } catch (RemoteException ex) {
            Slog.w(TAG, "setHdrNit error: " + ex);
        }
    }

    @Nullable
    public String getCurAudioDevice() {
        if (0 == android.os.SystemProperties.getInt("persist.vendor.media.audio.output.strategy", 0)) {
            return CURRENT_DEVICE_AUTO;
        }
        String outputDevice = "";
        try {
            outputDevice = droidDevToCurDev(mService.getCurAudioDevice());
            Slog.w(TAG, "getCurAudioDevice, outputDevice: " + outputDevice);
        } catch (RemoteException ex) {
            Slog.w(TAG, "getCurAudioDevice error: " + ex);
        }
        return outputDevice;
    }

    @Nullable
    public String setCurAudioDevice(@Nullable String device) {
        String ret = "fail";
        try {
            mService.setCurAudioDevice(curDevToDroidDev(device));
            ret = "success";
        } catch (RemoteException ex) {
            Slog.w(TAG, "setCurAudioDevice error: " + ex);
        }
        return ret;
    }

    private String droidDevToCurDev(int device) {
        switch (device) {
            case DROID_AUDIO_FORCE_USE_NONE:
                return CURRENT_DEVICE_AUTO;
            case DROID_AUDIO_FORCE_USE_SPEAKER:
                return CURRENT_DEVICE_SPEAKER;
            case DROID_AUDIO_FORCE_USE_HDMI:
                return CURRENT_DEVICE_HDMI;
            case DROID_AUDIO_FORCE_USE_HEADPHONES:
                return CURRENT_DEVICE_HEADPHONES;
            case DROID_AUDIO_FORCE_USE_USB:
                return CURRENT_DEVICE_USB;
            case DROID_AUDIO_FORCE_USE_BT_A2DP:
                return CURRENT_DEVICE_BT_A2DP;
            default:
                Slog.w(TAG, "droidDevToCurDev not supported device:" + device);
                return CURRENT_DEVICE_AUTO;
        }
    }

    private int curDevToDroidDev(String device) {
        switch (device) {
            case CURRENT_DEVICE_AUTO:
                return DROID_AUDIO_FORCE_USE_NONE;
            case CURRENT_DEVICE_SPEAKER:
                return DROID_AUDIO_FORCE_USE_SPEAKER;
            case CURRENT_DEVICE_HEADPHONES:
                return DROID_AUDIO_FORCE_USE_HEADPHONES;
            case CURRENT_DEVICE_HDMI:
                return DROID_AUDIO_FORCE_USE_HDMI;
            case CURRENT_DEVICE_USB:
                return DROID_AUDIO_FORCE_USE_USB;
            case CURRENT_DEVICE_BT_A2DP:
                return DROID_AUDIO_FORCE_USE_BT_A2DP;
            default:
                Slog.w(TAG, "curDevToDroidDev not supported device:" + device);
                return DROID_AUDIO_FORCE_USE_NONE;
        }
    }

private final BroadcastReceiver mShutdownReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("com.android.tv.settings.action.SCHEDULED_SHUTDOWN".equals(intent.getAction())) {
            Log.d(TAG, "perform timer shutdown");

            try {
                PowerManager mPowerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                mPowerManager.shutdown(false, "shutdown", false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("com.android.tv.settings.action.SCHEDULED_SCREENON".equals(intent.getAction())){
            Log.d(TAG, "perform timer screen on");
            try {
                android.os.SystemProperties.set("vendor.backlight", "on");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("com.android.tv.settings.action.SCHEDULED_SCREENOFF".equals(intent.getAction())){
            Log.d(TAG, "perform timer screen off");
            try {
                android.os.SystemProperties.set("vendor.backlight", "off");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
};

private String schedulePowerOffAndOn(String powerOffTimeStr, String powerOnTimeStr) {
    String ret = "failed";
    try {
        // parse powerOffTime
        Date powerOffTime = TIME_FORMAT.parse(powerOffTimeStr);
        Date powerOnTime = TIME_FORMAT.parse(powerOnTimeStr);

        if (powerOffTime == null || powerOnTime == null) {
            Log.e(TAG, "time parse fail");
            return ret;
        }

        Calendar now = Calendar.getInstance();
        Calendar powerOffCal = Calendar.getInstance();
        Calendar powerOnCal = Calendar.getInstance();

        // set powerOffTime
        powerOffCal.setTime(powerOffTime);
        powerOffCal.set(Calendar.YEAR, now.get(Calendar.YEAR));
        powerOffCal.set(Calendar.MONTH, now.get(Calendar.MONTH));
        powerOffCal.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));

        // set powerOnTime
        powerOnCal.setTime(powerOnTime);
        powerOnCal.set(Calendar.YEAR, now.get(Calendar.YEAR));
        powerOnCal.set(Calendar.MONTH, now.get(Calendar.MONTH));
        powerOnCal.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));

        // If the shutdown time is less than the current time, set it to tomorrow
        if (powerOffCal.before(now)) {
            powerOffCal.add(Calendar.DAY_OF_MONTH, 1);
        }

        // If the shutdown time is greater than the startup time, the startup time
        // will be delayed by 24 hours
        if (powerOffCal.after(powerOnCal)) {
            powerOnCal.add(Calendar.DAY_OF_MONTH, 1);
        }

        cancelScheduledPowerOff();
        long wakeAlarmSeconds = (powerOnCal.getTimeInMillis() - now.getTimeInMillis()) / 1000;
        // set wakealarm node
        setWakeAlarmNode(wakeAlarmSeconds);

        // Calculate shutdown countdown
        long delay = System.currentTimeMillis() + powerOffCal.getTimeInMillis() - now.getTimeInMillis();
        Log.d(TAG, "delay shutdown: " + delay);

        // Set shutdown timer
        AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
        Intent shutdownIntent = new Intent("com.android.tv.settings.action.SCHEDULED_SHUTDOWN");
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            mContext,
            0,
            shutdownIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            delay, // powerOffCal.getTimeInMillis(),
            pendingIntent
        );

        Log.d(TAG, "alarmtimer set success：powerOfftime=" + powerOffCal.getTime() +
              ", powerOntime=" + powerOnCal.getTime() +
              ", wakealarm Seconds=" + wakeAlarmSeconds);
        return ret = "success";

    } catch (ParseException e) {
        Log.e(TAG, "time parse Exception ", e);
        return ret;
    }
}

private void setWakeAlarmNode(long seconds) {
    try {
        FileOutputStream fos = new FileOutputStream(WAKEALARM_NODE);
        String str = "+" + String.valueOf(seconds);
        fos.write("0".getBytes());
        fos.write(str.getBytes());
        fos.close();
        Log.d(TAG, "set wakealarm node: " + seconds + " str: " + str);
    } catch (Exception e) {
        Log.e(TAG, "set wakealarm node fail", e);
    }
}

private String cancelScheduledPowerOff() {
    AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
    Intent shutdownIntent = new Intent("com.android.tv.settings.action.SCHEDULED_SHUTDOWN");
    PendingIntent pendingIntent = PendingIntent.getBroadcast(
        mContext,
        0,
        shutdownIntent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
    );

    alarmManager.cancel(pendingIntent);
    setWakeAlarmNode(0);
    Log.d(TAG, "canceled Scheduled PowerOff ");
    return "success";
}

private boolean isValidTimeFormat(String time) {
    if (TextUtils.isEmpty(time)) {
        return false;
    }
    try {
        TIME_FORMAT.parse(time);
        return time.matches("^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$");
    } catch (ParseException e) {
        return false;
    }
}

private String do_AutoPowerCtrl(String value) {
    Log.d(TAG, "do_AutoPowerCtrl value: " + value);
    String ret = "failed";
    if (value.equals("1") || value.equals("0")) {
        autoPowerEnabled = value.equals("1") ? true : false;
        ret = "success";
    } else {
        Log.d(TAG, "do_AutoPowerCtrl value invalid");
        return ret;
    }

    // Verify time format
    if (autoPowerEnabled) {
        if (isValidTimeFormat(StrpowerOffTime) && isValidTimeFormat(StrpowerOnTime)) {
            // Set a timer
            return schedulePowerOffAndOn(StrpowerOffTime, StrpowerOnTime);
        } else if (isValidTimeFormat(StrpowerOffTime) || isValidTimeFormat(StrpowerOnTime)) {
            return "success";
        } else {
            Log.d(TAG, "time format error");
            return ret;
        }
    } else {
        // Turn off the timer switch
        return cancelScheduledPowerOff();
    }
}
    @Nullable
    public String autoPowerCtrl(@Nullable String value) {
        Log.d(TAG, "AutoPowerCtrl value: " + value);
        String ret = "failed";
        if (TextUtils.isEmpty(value)) {
            Log.d(TAG, "AutoPowerCtrl value is invalid");
            return ret;
        }
        return do_AutoPowerCtrl(value);
    }

    @Nullable
    public String power_off_timer(@Nullable String value) {
        return handleTimerSetting(value, "PowerOffTimer");
    }

    @Nullable
    public String power_on_timer(@Nullable String value) {
        return  handleTimerSetting(value, "PowerOnTimer");
    }

    private String handleTimerSetting(String value, String timeType) {
        String ret = "failed";
        if (TextUtils.isEmpty(value)) {
            Log.d(TAG, timeType + " value is invalid");
            return ret;
        }
        Log.d(TAG, "do_" + timeType + " value: " + value);

        if (timeType.equals("PowerOffTimer")) {
            StrpowerOffTime = value;
        } else {
            if (timeType.equals("PowerOnTimer")) {
                StrpowerOnTime = value;
            }
        }

        // Verify two time formats
        if (isValidTimeFormat(StrpowerOffTime) && isValidTimeFormat(StrpowerOnTime)) {
            return schedulePowerOffAndOn(StrpowerOffTime, StrpowerOnTime);
        } else if (isValidTimeFormat(StrpowerOffTime) || isValidTimeFormat(StrpowerOnTime)) {
            return "success";
        } else {
            Log.d(TAG, "ValidTimeForma error");
            return ret;
        }
    }

    @Nullable
    public String autoScreenCtrl(@Nullable String value) {
        Log.d(TAG, "do_autoScreenCtrl value: " + value);
        String ret = "failed";
        if (value.equals("1") || value.equals("0")) {
            autoScreenEnabled = value.equals("1") ? true : false;
            ret = "success";
        } else {
            Log.d(TAG, "autoScreenCtrl value invalid");
            return ret;
        }

        // Verify time format
        if (autoScreenEnabled) {
            if (!isValidTimeFormat(StrscreenOffTime) || !isValidTimeFormat(StrscreenOnTime)) {
                Log.d(TAG, "time format error");
                return ret;
            }
            // Set screen timer
            return scheduleScreenOffAndOn(StrscreenOffTime, StrscreenOnTime);
        } else {
            // Turn off the timer switch
            return cancelScheduledScreenOffOn();
        }
    }

    @Nullable
    public String screen_off_timer(@Nullable String value) {
        return handleTimerSettingScreen(value, "ScreenOffTimer");
    }

    @Nullable
    public String screen_on_timer(@Nullable String value) {
        return  handleTimerSettingScreen(value, "ScreenOnTimer");
    }

    private String scheduleScreenOffAndOn(String screenOffTimeStr, String screenOnTimeStr) {
        String ret = "failed";
        try {
            // parse screenOffTime
            Date screenOffTime = TIME_FORMAT.parse(screenOffTimeStr);
            Date screenOnTime = TIME_FORMAT.parse(screenOnTimeStr);
            if (screenOffTime == null || screenOnTime == null) {
                Log.e(TAG, "time parse fail");
                return ret;
            }

            Calendar now = Calendar.getInstance();
            Calendar screenOffCal = Calendar.getInstance();
            Calendar screenOnCal = Calendar.getInstance();

            // set screenOffTime
            screenOffCal.setTime(screenOffTime);
            screenOffCal.set(Calendar.YEAR, now.get(Calendar.YEAR));
            screenOffCal.set(Calendar.MONTH, now.get(Calendar.MONTH));
            screenOffCal.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));

            // set screenOnTime
            screenOnCal.setTime(screenOnTime);
            screenOnCal.set(Calendar.YEAR, now.get(Calendar.YEAR));
            screenOnCal.set(Calendar.MONTH, now.get(Calendar.MONTH));
            screenOnCal.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));

            // If the shutdown time is less than the current time, set it to tomorrow
            if (screenOffCal.before(now)) {
                screenOffCal.add(Calendar.DAY_OF_MONTH, 1);
            }

            // If the shutdown time is greater than the startup time, the startup time
            // will be delayed by 24 hours
            if (screenOnCal.after(screenOnCal)) {
                screenOnCal.add(Calendar.DAY_OF_MONTH, 1);
            }

            cancelScheduledScreenOffOn();
            // Calculate screen off countdown
            long delay_screenOff = System.currentTimeMillis() + screenOffCal.getTimeInMillis() - now.getTimeInMillis();
            Log.d(TAG, "delay screenOff: " + delay_screenOff);

            // Set screen off timer
            AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
            Intent screenIntent = new Intent("com.android.tv.settings.action.SCHEDULED_SCREENOFF");
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                mContext,
                0,
                screenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                delay_screenOff, //screenOffCal.getTimeInMillis(),
                pendingIntent
            );

              // Calculate screen on countdown
              long delay_screenOn = System.currentTimeMillis() + screenOnCal.getTimeInMillis() - now.getTimeInMillis();
              Log.d(TAG, "delay screenOn: " + delay_screenOn);

              // Set screen on timer
            //   alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
              screenIntent = new Intent("com.android.tv.settings.action.SCHEDULED_SCREENON");
              pendingIntent = PendingIntent.getBroadcast(
                  mContext,
                  0,
                  screenIntent,
                  PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
              );

              alarmManager.setExactAndAllowWhileIdle(
                  AlarmManager.RTC_WAKEUP,
                  delay_screenOn, // screenOnCal.getTimeInMillis(),
                  pendingIntent
              );

            Log.d(TAG, "alarmtimer set success：screenOfftime=" + screenOffCal.getTime() +
                  ", screenOntime=" + screenOnCal.getTime());
            return ret = "success";

        } catch (ParseException e) {
            Log.e(TAG, "time parse Exception ", e);
            return ret;
        }
    }

    private String cancelScheduledScreenOffOn() {
        AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
        Intent screenIntent = new Intent("com.android.tv.settings.action.SCHEDULED_SCREENOFF");
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            mContext,
            0,
            screenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);

        screenIntent = new Intent("com.android.tv.settings.action.SCHEDULED_SCREENON");
        pendingIntent = PendingIntent.getBroadcast(
            mContext,
            0,
            screenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
        Log.d(TAG, "canceled Scheduled ScreenOff/On ");
        return "success";
    }

    private String handleTimerSettingScreen(String value, String timeType) {
        String ret = "failed";
        if (TextUtils.isEmpty(value)) {
            Log.d(TAG, timeType + " value is invalid");
            return ret;
        }
        Log.d(TAG, "do_" + timeType + " value: " + value);
        if (!autoScreenEnabled) {
            Log.d(TAG, "do_" + timeType + " value: " + value + " autoScreenEnabled: " + autoScreenEnabled);
            return ret;
        }
        // Verify input time format
        if (!isValidTimeFormat(value)) {
            Log.d(TAG, "ValidTimeForma error");
            return ret;
        }
        if (timeType.equals("ScreenOffTimer")) {
            StrscreenOffTime = value;
            ret = "success";
        } else {
            if (timeType.equals("ScreenOnTimer")) {
            StrscreenOnTime = value;
            ret = "success";
        }
        }

        // Verify two time formats
        if (!isValidTimeFormat(StrscreenOffTime) || !isValidTimeFormat(StrscreenOnTime)) {
            Log.d(TAG, "screenOffTime or screenOnTime: ValidTimeForma error");
            return ret;
        }

        return scheduleScreenOffAndOn(StrscreenOffTime, StrscreenOnTime);
    }
}
