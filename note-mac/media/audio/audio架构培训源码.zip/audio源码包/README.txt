Amlogic s905d5 Android 音频架构培训 - 配套源码包
=================================================

本压缩包是《培训文档-音频架构与调试.md》的配套源码。
所有文件均按原 Android 工程目录结构存放，解压后目录前缀
与工程根目录一一对应，可直接对照培训文档中的路径跳转阅读。

一、内容说明
------------
1. frameworks/            AOSP Java/C++ 框架层
   - base/core/java/android/os/display/   DisplayManager + IDisplayService
   - base/services/core/java/com/android/server/   DisplayService / DroidAudioManager / audio/ 目录
   - base/media/java/android/media/       AudioManager / AudioTrack (应用层 API)
   - av/media/libaudioclient/             AudioSystem / AudioTrack 客户端
   - av/services/audioflinger/            AudioFlinger (混音引擎)
   - av/services/audiopolicy/             AudioPolicyService + AudioPolicyManager + 引擎

2. vendor/amlogic/common/   Amlogic 厂商定制
   - frameworks/native/libaudiopolicymanagercustom/   AmlAudioPolicyManager
   - frameworks/native/libaudiopolicyengine_amlogic/  amlogic 定制路由引擎
   - frameworks/core/java/com/droidlogic/app/          DroidAudioManager 等厂商 API
   - interfaces/droidaudio/                 droidaudio AIDL 服务 (default 实现 + aidl 定义)

3. hardware/amlogic/audio/   Audio HAL
   - audio_hal/    audio.primary HAL (audio_hw.c / MS12 / alsa_manager 等)
   - aml_aq_hw/    Dolby EQ/DRC 参数库 (仅保留头文件与 Makefile, 已剔除 .a 二进制)

4. common/common14-5.15/common/common_drivers/sound/soc/   内核音频驱动
   - amlogic/      AUGE 音频子系统平台驱动 (auge/ + common/)
   - codecs/amlogic/  codec / 功放驱动

5. device/amlogic/common/products/mbox/init.amlogic.system.rc  输出/静音属性触发脚本

二、各层快速定位提示
--------------------
输出设备切换主链路:
  DisplayManager(APK) -> IDisplayService -> DisplayService
    -> DroidAudioManager -> droidaudio(DroidAudioConfigSetting)
    -> AudioSystem::setForceUse -> AudioPolicyService
    -> AmlAudioPolicyManager -> engine 选设备 -> installPatch -> HAL -> 内核

三、注意事项
------------
- 本包仅用于阅读与培训，不含编译所需的 Android.bp/Android.mk 全量配置
- 部分源码文件很大(如 audio_hw.c 约 1 万行), 建议用带语法高亮的编辑器打开
- Windows 下建议用 WinRAR 7 / 7-Zip 23+ / Windows 10+ 资源管理器解压，
  可正确显示中文文件名; macOS 用自带归档工具即可

生成日期: 2026-09-04
