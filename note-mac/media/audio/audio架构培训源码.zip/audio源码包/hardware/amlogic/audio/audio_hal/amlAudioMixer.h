/*
 * Copyright (C) 2018 Amlogic Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef _AML_AUDIO_MIXER_H_
#define _AML_AUDIO_MIXER_H_

#include <tinyalsa/asoundlib.h>
#include <semaphore.h>
#include "aml_ringbuffer.h"
#include "audio_port.h"
#include "karaoke_manager.h"
#include "aml_audio_timer.h"

#define MIXER_OUT_FRAME_SIZE                (8)
#define MIXER_FRAME_COUNT                   (384)
#define MIXER_SAMPLE_RATE_HZ                (48000)
#define MIXER_WRITE_PERIOD_TIME_NANO        (MIXER_FRAME_COUNT * NSEC_PER_SEC / MIXER_SAMPLE_RATE_HZ)


__BEGIN_DECLS
/**
 * Audio mixer:
 * mixing two pcm streams with same configs(16-bits, 2-channels).
 * only support mixing two steams, one main stream and one aux stream.
 * And the output streams configs must be same as input streams.
 * TODO: add formats adaptions.
 */
struct amlAudioMixer;
typedef enum {
    MIXER_IDLE,             // no active tracks
    MIXER_INPORTS_ENABLED,  // at least one active track, but no track has any data ready
    MIXER_INPORTS_READY,    // at least one active track, and at least one track has data
    MIXER_DRAIN_TRACK,      // drain currently playing track
    MIXER_DRAIN_ALL,        // fully drain the hardware
} aml_mixer_state;

typedef enum SUBMIX_SCHEDULER_STATE {
    SUBMIX_SCHEDULER_NONE = -1,
    SUBMIX_SCHEDULER_RUNNING =  0,
    SUBMIX_SCHEDULER_STANDBY =  1,

    SUBMIX_SCHEDULER_MAX,
} submix_scheduler_state_t;

//simple mixer support: 2 in , 1 out
struct amlAudioMixer {
    input_port *in_ports[NR_INPORTS];
    uint32_t inportsMasks; // records of inport IDs
    uint32_t inportsAvailMasks; // 1<< NR_INPORTS - 1
    MIXER_OUTPUT_PORT cur_output_port_type;
    output_port *out_ports[MIXER_OUTPUT_PORT_NUM];
    pthread_mutex_t outport_locks[MIXER_OUTPUT_PORT_NUM];
    pthread_mutex_t inport_lock;
    ssize_t (*write)(struct amlAudioMixer *mixer, void *buffer, int bytes);

    aml_pcm_mixing_st ch_mux_mixer;
    aml_pcm_mixing_st stereo_mixer;
    aml_pcm_mixing_st multich_mixer;
    aml_pcm_downmix_st pcm_downmix;

    struct audioCfg cfg; //mixing output config
    uint32_t hwsync_frame_size;
    pthread_t out_mixer_tid;
    pthread_mutex_t lock;
    unsigned int exit_thread : 1;
    unsigned int mixing_enable : 1;
    aml_mixer_state state;
    struct timespec tval_last_write;
    struct aml_audio_device *adev;
    bool continuous_output;
    //int init_ok : 1;
    int submix_standby;
    //aml_audio_mixer_run_state_type_e run_state;
    bool reset_virtual_buf;  /* when audio port restart, need to reset */

    //multich pcm output
    bool mc_out_enable;
    port_state mc_out_status;
    bool aaudio_low_latency;
    uint64_t run_count; // use for reduce debug info

    // alsa delay info
    struct timespec outport_delay_ts[MIXER_OUTPUT_PORT_NUM];
    uint32_t outport_delay_ms[MIXER_OUTPUT_PORT_NUM];
    pthread_mutex_t outport_delay_locks[MIXER_OUTPUT_PORT_NUM];
    int multi_aaudio_port_index;

    //using which one of aml_pcm_mixing_st
    int type;
    int submix_scheduler_state;
    int last_scheduler_state;
    sem_t submix_standby_sem;
    uint32_t submix_timer_id;
};

enum aml_sub_mixer_type {
    SUB_MIXER_NORMAL = 0,
    SUB_MIXER_CH_MUX = 1,
};
/**
 * constructor with mixer output pcm configs
 * return NULL if no enough memory.
 */
struct amlAudioMixer *newAmlAudioMixer(struct aml_audio_device *adev, struct audioCfg mixer_cfg, struct audioCfg out_cfg, int type);

/**
 * destructor to free the mixer
 */
void freeAmlAudioMixer(struct amlAudioMixer *audio_mixer);
void mixer_set_hwsync_input_port(struct amlAudioMixer *audio_mixer, uint8_t port_index);
void set_mixer_hwsync_frame_size(struct amlAudioMixer *audio_mixer, uint32_t frame_size);
uint32_t get_mixer_hwsync_frame_size(struct amlAudioMixer *audio_mixer);
uint32_t get_mixer_inport_consumed_frames(struct amlAudioMixer *audio_mixer, uint8_t port_index);
int set_mixer_inport_volume(struct amlAudioMixer *audio_mixer, uint8_t port_index, float vol);
int init_mixer_input_port(struct amlAudioMixer *audio_mixer,
        struct audio_config *config,
        audio_output_flags_t flags,
        int (*on_notify_cbk)(void *data),
        void *notify_data,
        int (*on_input_avail_cbk)(void *data),
        void *input_avail_data,
        meta_data_cbk_t on_meta_data_cbk,
        void *meta_data,
        float volume);

int add_new_input_port_on_mixer(struct amlAudioMixer *audio_mixer, input_port *in_port);

int mixer_change_config_format(struct audioCfg *cfg, audio_format_t format);
int mixer_get_default_config(struct audioCfg *cfg, bool is_tv);
uint32_t get_mixer_inport_count(struct amlAudioMixer *audio_mixer);
int delete_mixer_input_port(struct amlAudioMixer *audio_mixer, uint8_t port_index);
int send_mixer_inport_message(struct amlAudioMixer *audio_mixer, uint8_t port_index, PORT_MSG msg);
int send_mixer_outport_message(struct amlAudioMixer *audio_mixer, uint8_t port_index,
        PORT_MSG msg, void *info, int info_len);
int mixer_write_inport(struct amlAudioMixer *audio_mixer, uint8_t port_index, const void *buffer, int bytes);
int mixer_read_inport(struct amlAudioMixer *audio_mixer, uint8_t port_index, void *buffer, int bytes);
int mixer_set_inport_state(struct amlAudioMixer *audio_mixer, uint8_t port_index, port_state state);
int mixer_flush_inport(struct amlAudioMixer *audio_mixer, uint8_t port_index);
int pcm_mixer_thread_run(struct amlAudioMixer *audio_mixer);
int pcm_mixer_thread_exit(struct amlAudioMixer *audio_mixer);
struct pcm *pcm_mixer_get_pcm_handle(struct amlAudioMixer *audio_mixer);
uint32_t mixer_get_inport_latency_frames(struct amlAudioMixer *audio_mixer, uint8_t port_index);
uint32_t mixer_get_outport_latency_frames(struct amlAudioMixer *audio_mixer);
int mixer_get_presentation_position(
        struct amlAudioMixer *audio_mixer,
        uint8_t port_index,
        uint64_t *frames,
        int64_t *s64_negative_frames,
        struct timespec *timestamp);
int mixer_set_padding_size(
        struct amlAudioMixer *audio_mixer,
        uint8_t port_index,
        int padding_bytes);
int mixer_set_continuous_output(struct amlAudioMixer *audio_mixer, bool continuous_output);
int mixer_outport_pcm_restart(struct amlAudioMixer *audio_mixer);
void mixer_dump(int s32Fd, const struct aml_audio_device *pstAmlDev);
void mixer_using_alsa_device_dump(int s32Fd, const struct aml_audio_device *pstAmlDev);
bool has_hwsync_stream_running(struct audio_stream_out *stream);
/* usb karaoke for hal mixer */
int mixer_set_karaoke(struct amlAudioMixer *audio_mixer, struct kara_manager *kara);

void mixer_enable_multich_output(struct amlAudioMixer *audio_mixer, bool enable);
int mixer_get_mc_outport_latency_frames(struct amlAudioMixer *audio_mixer);
int mixer_reset_virtual_buf(void *audio_mixer, bool reset);
int mixer_get_inport_start_threshold(struct aml_stream_out *out, struct amlAudioMixer *audio_mixer);

input_port *mixer_get_inport(struct amlAudioMixer *audio_mixer, uint32_t *pMasks);
int aml_audiohal_sch_state_2_submix(struct amlAudioMixer *audio_mixer, int sch_state);
int aml_set_submix_scheduler_state(struct amlAudioMixer *audio_mixer, int sch_state);
void set_submix_continuous_state(struct amlAudioMixer *audio_mixer, int state);
int aml_send_submix_standby_state_2_submix(void);
void submix_timer_callback_handler(union sigval sigv);


__END_DECLS

#endif
