/*
* Copyright (C) 2024 Amlogic Corporation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#define LOG_TAG "audio_hw_hal_multi_recorder"
//#define LOG_NDEBUG 0

#include <cutils/log.h>
#include <pthread.h>
#include <sys/time.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <cutils/log.h>
#include <sys/prctl.h>
#include <errno.h>
#include <inttypes.h>
#include <cutils/list.h>
#include <audio_utils/primitives.h>
#include <audio_utils/channels.h>
#include "audio_hw_utils.h"
#include "aml_audio_timer.h"
#include "aml_ringbuffer.h"
#include "aml_multi_recorder.h"
#include "alsa_device_parser.h"
#include "aml_malloc_debug.h"
#include "aml_ringbuffer.h"

#ifndef UNUSED
#define UNUSED(x) (void)(x)
#endif

pthread_t thread_id;
pthread_mutex_t  recorder_list_mutex;

#define SAMPLE_RATE_DEFAULT     16000
#define CHANNEL_DEFAULT         4    // 2 mic + 2 ref
#define FORMAT_DEFAULT          PCM_FORMAT_S16_LE
#define PERIOD_SIZE_DEFAULT     64
#define PERIOD_COUNT_DEFAULT    4

#define READ_SIZE_SINGLE_TIME   128

struct multi_recorder_node *node_head = NULL;
int key_current = 0;
void* read_buff = NULL;
void* mic_buff = NULL;
void* ref_buff = NULL;
bool exit_thread = false;

/* add node to multi recorder list at tail */
int add_multi_recorder_node(struct multi_recorder_node *node)
{
    AM_LOGD("enter");

    if (!node) {
        AM_LOGE("parameter invalid");
        return -1;
    }

    /* init ring buffer for save original mic data */
    int ret = ring_buffer_init(&node->buf, READ_SIZE_SINGLE_TIME * 64);
    if (ret < 0) {
        AM_LOGE("malloc ring buffer error");
        return -1;
    }

    pthread_mutex_lock(&recorder_list_mutex);

    /* set node as head */
    if (NULL == node_head) {
        node_head = node;
        goto exit;
    }
    /* set node to tail */
    struct multi_recorder_node *temp = node_head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = node;

exit:
    node->next = NULL;
    node->key_value = key_current;
    node->is_active = 1;
    pthread_mutex_init(&node->node_mutex, NULL);
    AM_LOGD("success and key_value=%d audio_device=0x%x audio_source=%d", node->key_value, node->audio_device, node->audio_source);
    key_current++;
    pthread_mutex_unlock(&recorder_list_mutex);
    return 0;
}

/* remove node from multi recorder list */
int remove_multi_recorder_node(struct multi_recorder_node *node)
{
    AM_LOGD("enter");

    if (!node) {
        AM_LOGE("parameter invalid");
        return -1;
    }
    struct multi_recorder_node *prev = NULL;
    struct multi_recorder_node *temp = node_head;

    pthread_mutex_lock(&recorder_list_mutex);

    /* if node is the header */
    if (NULL != temp && temp->key_value == node->key_value) {
        node_head = temp->next;
        goto exit;
    }

    /* search node in list */
    while (NULL != temp && temp->key_value != node->key_value) {
        prev = temp;
        temp = temp->next;
    }

    /* have not found node in list */
    if (NULL == temp) {
        pthread_mutex_unlock(&recorder_list_mutex);
        return 0;
    }

    /* remove the node */
    prev->next = temp->next;

exit:
    /* release resource */
    temp->is_active = 0;
    ring_buffer_release(&temp->buf);
    pthread_mutex_destroy(&temp->node_mutex);

    pthread_mutex_unlock(&recorder_list_mutex);

    AM_LOGD("success and key_value=%d", node->key_value);
    return 0;
}

unsigned int get_avail_from_multi_recorder(struct multi_recorder_node *node)
{
    if (!node ) {
        return 0;
    }
    pthread_mutex_lock(&node->node_mutex);
    unsigned int avail = node->dma_avail;
    pthread_mutex_unlock(&node->node_mutex);

    return avail;
}

/* read data by recorder */
ssize_t read_data_from_multi_recorder(struct multi_recorder_node *node, void* buffer, size_t bytes)
{
    if (!node || !buffer || 0 == bytes) {
        return -EINVAL;
    }

    // AM_LOGD("multi_recorder_node key_value = %d", node->key_value);

    uint32_t read_bytes = 0;
    int nodata_count = 0;
    int retry_max_count = 20;
    int sleep_us = 5000;
    size_t ret = 0;
    while (read_bytes < bytes) {
        ret = ring_buffer_read(&node->buf, (uint8_t *)buffer + read_bytes, bytes - read_bytes);
        read_bytes += ret;
        if (read_bytes == bytes) {
            return bytes;
        }
        nodata_count++;
        if (nodata_count >= retry_max_count) {
            AM_LOGW("read data timeout, need:%zu, read_bytes:%d, key_value = %d", bytes, read_bytes, node->key_value);
            memset(buffer, 0, bytes);
            return bytes;
        }
        usleep(sleep_us);
    }
    return bytes;
}

/* split mic with reference data */
int split_mic_with_reference(void* original_buff, void* mic_buff,
                                              void* ref_buff, unsigned int data_size,
                                              unsigned int frame_size)
{
    if (!original_buff || !mic_buff || !ref_buff || !data_size || !frame_size) {
        AM_LOGE("parameter invalid");
        return -1;
    }
    int i = 0;
    int frame_count = data_size / frame_size;
    //AM_LOGD("frame_size = %d, frame_count = %d", frame_size, frame_count);

    unsigned char *temp_original = (unsigned char *)original_buff;
    unsigned char *temp_mic = (unsigned char *)mic_buff;
    unsigned char *temp_ref = (unsigned char *)ref_buff;

    /* 1 frame data include mic and reference */
    for (i = 0; i < frame_count ; i++) {
        memcpy(temp_mic, temp_original, frame_size/2); // mic data
        memcpy(temp_ref, temp_original + frame_size/2 , frame_size/2); // ref data
        temp_original += frame_size;
        temp_mic += frame_size/2;
        temp_ref += frame_size/2;
    }

    AM_LOGV("exit");
    return 0;
}

/* provide data according to device type for all recorder node in list */
static int provide_data_for_recorder(void* buffer, unsigned int data_size, unsigned int frame_size)
{
    if (!buffer || !data_size || !frame_size) {
        AM_LOGE("parameter invalid");
        return -1;
    }
    int i = 0;

    /* split mic with reference */
    split_mic_with_reference(buffer, mic_buff, ref_buff, READ_SIZE_SINGLE_TIME, frame_size);

    if (getprop_bool("vendor.media.audiohal.indump")) {
        aml_dump_audio_bitstreams("/data/audio/loopback_original.raw", buffer, data_size);
        // aml_dump_audio_bitstreams("/data/audio/built_in_mic_original.raw", mic_buff, data_size/2);
        // aml_dump_audio_bitstreams("/data/audio/echo_reference_original.raw", ref_buff, data_size/2);
    }

    pthread_mutex_lock(&recorder_list_mutex);

    struct multi_recorder_node *temp = node_head;
    while (NULL != temp) {
        if (temp->is_active) {
            //AM_LOGD("audio_device = 0x%x key_value = %d", temp->audio_device, temp->key_value);
            if (temp->audio_source == AUDIO_SOURCE_MIC) {
                ring_buffer_write(&temp->buf, (unsigned char *)mic_buff, data_size/2 , UNCOVER_WRITE);
            }
            if (temp->audio_source == AUDIO_SOURCE_VOICE_RECOGNITION) {
                ring_buffer_write(&temp->buf, (unsigned char *)buffer, data_size, UNCOVER_WRITE);
            }
            if (temp->audio_device & AUDIO_DEVICE_IN_FM_TUNER) {
                ring_buffer_write(&temp->buf, (unsigned char *)buffer, data_size, UNCOVER_WRITE);
            }
        }
        temp = temp->next;
    }

    pthread_mutex_unlock(&recorder_list_mutex);

    return 0;
}

/* recorder timestamp for all recorder node in list */
static int update_hw_info_for_recorder(int64_t time, unsigned int avail)
{
    struct multi_recorder_node *temp = node_head;

    pthread_mutex_lock(&recorder_list_mutex);
    while (NULL != temp) {
        if (temp->is_active) {
            pthread_mutex_lock(&temp->node_mutex);
            temp->time_stamp = time;
            temp->dma_avail = avail / 2; // split mic with speaker reference when 2+2
            pthread_mutex_unlock(&temp->node_mutex);
            //AM_LOGD("time = %lld avail = %d", temp->time_stamp, temp->dma_avail);
        }
        temp = temp->next;
    }
    pthread_mutex_unlock(&recorder_list_mutex);

    return 0;
}

/* main work thread */
static void *multi_recorder_threadloop(void *data)
{
    UNUSED(data);
    int ret = 0;
    int64_t frames = 0, time = 0;
    struct timespec timestamp;
    unsigned int avail;
    unsigned int frame_size = 0;
    struct pcm *pcmIn = NULL;
    struct pcm_config pcmConfig;
    memset(&pcmConfig, 0, sizeof(pcmConfig));
    /* the record parameter depends on pcm in config */
    pcmConfig.channels = CHANNEL_DEFAULT;
    pcmConfig.rate = SAMPLE_RATE_DEFAULT;
    pcmConfig.format = FORMAT_DEFAULT;
    pcmConfig.period_size = PERIOD_SIZE_DEFAULT;
    pcmConfig.period_count = PERIOD_COUNT_DEFAULT;
    frame_size = pcmConfig.channels * pcm_format_to_bits(pcmConfig.format) / 8;
    AM_LOGD("pcmConfig: channels %d, format %d, rate %d, frame_size %d",
             pcmConfig.channels, pcmConfig.format, pcmConfig.rate, frame_size);

    /* open alsa capture handle */
    int card = alsa_device_get_card_index();
    int device = alsa_device_update_pcm_index(PORT_LOOPBACK, CAPTURE);

    if (getprop_bool("vendor.media.audiohal.pdmdemo")) {
		device = 3;
	}

    AM_LOGD("card: %d, device %d", card, device);

    /* init buffer */
    read_buff = aml_audio_malloc(READ_SIZE_SINGLE_TIME);
    mic_buff = aml_audio_malloc(READ_SIZE_SINGLE_TIME/2);
    ref_buff = aml_audio_malloc(READ_SIZE_SINGLE_TIME/2);
    if (!read_buff || !mic_buff || !ref_buff) {
        AM_LOGE("aml_audio_malloc buffer error");
        goto err;
    }

    while (!exit_thread) {
        /* close pcm when no recorder node exist */
        if (!node_head) {
            if (pcmIn) {
                pcm_close(pcmIn);
                pcmIn = NULL;
            }
            // AM_LOGD("no recoder exist!");
            usleep(2000);
            continue;
        }

        /* open pcm when recorder node exist */
        if (!pcmIn) {
            pcmIn = pcm_open(card, device, PCM_IN, &pcmConfig);
            if (!pcm_is_ready(pcmIn)) {
                AM_LOGE("pcm_is_ready error!");
                if (pcmIn) {
                    pcm_close(pcmIn);
                    pcmIn = NULL;
                }
                goto err;
            }
        }

        /* read data and get htimestamp */
        if (pcmIn) {
            /* read data */
            ret = pcm_read(pcmIn, read_buff, READ_SIZE_SINGLE_TIME);
            if (0 != ret) {
                /* abandon data when pcm read error */
                AM_LOGE("pcm_read error");
                usleep(2000);
                continue;
            }
            /* pcm_get_htimestamp */
            if (pcm_get_htimestamp(pcmIn, &avail, &timestamp) == 0) {
                time = timestamp.tv_sec * 1000000000LL + timestamp.tv_nsec;
            }
        }

        /* provide data by device type for recorder */
        provide_data_for_recorder(read_buff, READ_SIZE_SINGLE_TIME, frame_size);

        /* recorder the latest timestamp */
        update_hw_info_for_recorder(time, avail);
    }

err:
    AM_LOGE("exit");
    return (void *)0;
}

int create_multi_recorder_thread(void)
{
    AM_LOGD("enter");
    int ret = 0;
    ret = pthread_mutex_init(&recorder_list_mutex, NULL);
    if (ret != 0) {
        AM_LOGE("pthread_mutex_init recoder_mutex fail, errno:%s", strerror(errno));
        return -1;
    }
    exit_thread = false;
    ret = pthread_create(&thread_id, NULL, &multi_recorder_threadloop, NULL);
    if (ret != 0) {
        AM_LOGE("create multi recoder thread failed, errno:%s", strerror(errno));
        return ret;
    }

    //pthread_detach(thread_id);

    AM_LOGD("exit");
    return ret;
}

int exit_multi_recorder_thread(void)
{
    AM_LOGD("enter");
    if (read_buff) {
        aml_audio_free(read_buff);
        read_buff = NULL;
    }
    if (mic_buff) {
        aml_audio_free(mic_buff);
        mic_buff = NULL;
    }
    if (ref_buff) {
        aml_audio_free(ref_buff);
        ref_buff = NULL;
    }
    node_head = NULL;
    key_current = 0;
    exit_thread = true;
    pthread_mutex_destroy(&recorder_list_mutex);
    pthread_join(thread_id, NULL);

    AM_LOGD("exit");
    return 0;
}
