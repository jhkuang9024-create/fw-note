/*
* Copyright (C) 2024 Amlogic Corporation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#ifndef _AML_MULTI_RECORDER_H_
#define _AML_MULTI_RECORDER_H_

#include <pthread.h>
#include <aml_ringbuffer.h>

struct multi_recorder_node {
    bool is_active;
    int key_value;
    int audio_device;
    int audio_source;
    ring_buffer_t buf;
    unsigned int cache_size;
    unsigned int dma_avail;
    int64_t time_stamp;
    pthread_mutex_t node_mutex;
    struct multi_recorder_node *next;
};

int create_multi_recorder_thread(void);
int exit_multi_recorder_thread(void);
int add_multi_recorder_node(struct multi_recorder_node *node);
int remove_multi_recorder_node(struct multi_recorder_node *node);
ssize_t read_data_from_multi_recorder(struct multi_recorder_node *node, void* buffer, size_t bytes);
unsigned int get_avail_from_multi_recorder(struct multi_recorder_node *node);
int split_mic_with_reference(void* original_buff, void* mic_buff,
                                              void* ref_buff, unsigned int data_size,
                                              unsigned int frame_size);

#endif
